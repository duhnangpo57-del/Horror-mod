package com.observer.dimension;

import com.observer.boss.arena.BossArenaController;
import com.observer.memory.ObserverMemoryData;
import com.observer.memory.PlayerProfile;
import com.observer.story.Dialogue;
import com.observer.story.StoryData;
import com.observer.story.StoryManager;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;

import javax.annotation.Nullable;

/** Entering and leaving observer:the_domain, safely and with a remembered way back. */
public final class DomainManager {
    private static final double ENTER_X = 0.5D;

    private DomainManager() {
    }

    public static void enter(ServerPlayer player) {
        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }
        ServerLevel domain = server.getLevel(ModDimensions.DOMAIN);
        if (domain == null) {
            player.sendSystemMessage(Component.translatable("story.observer.domain_missing"));
            return;
        }
        StoryData story = StoryData.get(server);
        if (player.level().dimension() != ModDimensions.DOMAIN) {
            story.setReturn(player.getUUID(), player.level().dimension().location().toString(), player.blockPosition());
        }
        if (!story.isArenaBuilt()) {
            PlayerProfile profile = ObserverMemoryData.get(server).peek(player.getUUID());
            ArenaGenerator.generate(domain, profile);
            story.setArenaBuilt(true);
        }
        player.teleportTo(domain, ENTER_X, ArenaGenerator.FLOOR_Y + 1.0D, BossArenaController.PLAYER_SPAWN_Z, 180.0F, 0.0F);
        player.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40, 0, false, false));
        if (story.getChapter() < 4) {
            story.setChapter(4);
        }
        Dialogue.say(player, "story.observer.domain.enter");
        StoryManager.scheduleBoss(server, player.getUUID(), 100);
    }

    public static void leave(ServerPlayer player) {
        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }
        StoryData story = StoryData.get(server);
        StoryData.ReturnPoint point = story.getReturn(player.getUUID());

        ServerLevel destination = null;
        BlockPos pos = null;
        if (point != null) {
            ResourceLocation id = ResourceLocation.tryParse(point.dim());
            if (id != null) {
                destination = server.getLevel(ResourceKey.create(Registries.DIMENSION, id));
            }
            pos = point.pos();
        }
        if (destination == null || destination.dimension() == ModDimensions.DOMAIN || pos == null) {
            destination = server.overworld();
            pos = destination.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, destination.getSharedSpawnPos());
        }
        player.teleportTo(destination, pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, player.getYRot(), player.getXRot());
        player.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 30, 0, false, false));
    }

    /** The exit gate only works once the fight is over. */
    public static void leaveIfAllowed(ServerPlayer player) {
        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }
        if (StoryData.get(server).getChapter() >= 5) {
            leave(player);
        } else {
            player.sendSystemMessage(Component.translatable("story.observer.domain.locked"));
        }
    }

    public static boolean isDomain(@Nullable Level level) {
        return level != null && level.dimension() == ModDimensions.DOMAIN;
    }
}
