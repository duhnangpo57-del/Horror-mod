package com.observer.dimension;

import com.observer.building.Blueprint;
import com.observer.building.BlueprintAnalyzer;
import com.observer.building.BlueprintBlock;
import com.observer.memory.PlayerProfile;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.registries.ForgeRegistries;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Builds the boss arena once: a 51 x 51 black platform floating over the void, four pillars made from
 * the blocks the player mined most, a raised central dais, and ruins of the player's own builds drifting
 * around it. This is generated structure, so it uses setBlock directly.
 */
public final class ArenaGenerator {
    public static final int FLOOR_Y = 63;
    public static final int HALF = 25;

    private ArenaGenerator() {
    }

    /** The original floor block at x,z. Used to restore the floor after temporary changes. */
    public static BlockState floorState(int x, int z) {
        int ax = Math.abs(x);
        int az = Math.abs(z);
        if (ax <= 5 && az <= 5) {
            return ax <= 1 && az <= 1 ? Blocks.GILDED_BLACKSTONE.defaultBlockState()
                    : Blocks.CHISELED_POLISHED_BLACKSTONE.defaultBlockState();
        }
        if (Math.max(ax, az) >= HALF) {
            return Blocks.CRYING_OBSIDIAN.defaultBlockState();
        }
        return ((x + z) & 1) == 0 ? Blocks.POLISHED_BLACKSTONE.defaultBlockState()
                : Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState();
    }

    public static void generate(ServerLevel level, @Nullable PlayerProfile profile) {
        for (int cx = -4; cx <= 4; cx++) {
            for (int cz = -4; cz <= 4; cz++) {
                level.getChunk(cx, cz);
            }
        }

        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int x = -HALF; x <= HALF; x++) {
            for (int z = -HALF; z <= HALF; z++) {
                level.setBlock(pos.set(x, FLOOR_Y, z), floorState(x, z), 2);
                // a second layer so a broken floor never exposes the void
                level.setBlock(pos.set(x, FLOOR_Y - 1, z), Blocks.BLACKSTONE.defaultBlockState(), 2);
            }
        }
        // raised central dais
        for (int x = -3; x <= 3; x++) {
            for (int z = -3; z <= 3; z++) {
                level.setBlock(pos.set(x, FLOOR_Y + 1, z), Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState(), 2);
            }
        }

        List<BlockState> materials = pillarMaterials(level, profile);
        int[][] corners = {{-17, -17}, {17, -17}, {-17, 17}, {17, 17}};
        for (int i = 0; i < 4; i++) {
            int px = corners[i][0];
            int pz = corners[i][1];
            BlockState material = materials.get(i % materials.size());
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    for (int y = 1; y <= 14; y++) {
                        level.setBlock(pos.set(px + dx, FLOOR_Y + y, pz + dz), material, 2);
                    }
                }
            }
            level.setBlock(pos.set(px, FLOOR_Y + 15, pz), Blocks.END_ROD.defaultBlockState(), 2);
            level.setBlock(pos.set(px, FLOOR_Y + 16, pz), Blocks.END_ROD.defaultBlockState(), 2);
        }

        if (profile != null) {
            Blueprint blueprint = BlueprintAnalyzer.analyze(profile, 250);
            if (blueprint != null) {
                for (int i = 0; i < 3; i++) {
                    double angle = Math.PI * 2.0D * i / 3.0D + 0.5D;
                    int ox = (int) Math.round(Math.cos(angle) * 55.0D) - blueprint.sizeX() / 2;
                    int oz = (int) Math.round(Math.sin(angle) * 55.0D) - blueprint.sizeZ() / 2;
                    placeRuin(level, blueprint, new BlockPos(ox, FLOOR_Y + 18, oz));
                }
            }
        }
    }

    private static void placeRuin(ServerLevel level, Blueprint blueprint, BlockPos origin) {
        for (BlueprintBlock b : blueprint.blocks()) {
            Block block = ForgeRegistries.BLOCKS.getValue(new ResourceLocation(b.blockId()));
            if (block == null || block == Blocks.AIR) {
                continue;
            }
            level.setBlock(origin.offset(b.x(), b.y(), b.z()), block.defaultBlockState(), 2);
        }
    }

    private static List<BlockState> pillarMaterials(ServerLevel level, @Nullable PlayerProfile profile) {
        List<BlockState> materials = new ArrayList<>();
        if (profile != null) {
            List<Map.Entry<String, Integer>> mined = new ArrayList<>(profile.getMinedBlocks().entrySet());
            mined.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));
            for (Map.Entry<String, Integer> e : mined) {
                if (materials.size() >= 4) {
                    break;
                }
                Block block = ForgeRegistries.BLOCKS.getValue(new ResourceLocation(e.getKey()));
                if (block != null && block != Blocks.AIR
                        && block.defaultBlockState().isCollisionShapeFullBlock(level, BlockPos.ZERO)) {
                    materials.add(block.defaultBlockState());
                }
            }
        }
        while (materials.size() < 4) {
            materials.add(Blocks.DEEPSLATE_BRICKS.defaultBlockState());
        }
        return materials;
    }
}
