package com.observer.events;

import com.observer.ObserverMod;
import com.observer.boss.entity.PerfectCopyCloneEntity;
import com.observer.boss.entity.PerfectCopyEntity;
import com.observer.entity.ObserverEntity;
import com.observer.registry.ModEntities;
import com.observer.registry.ModItems;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ObserverMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModBusEvents {
    private ModBusEvents() {
    }

    @SubscribeEvent
    public static void onEntityAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.THE_OBSERVER.get(), ObserverEntity.createAttributes().build());
        event.put(ModEntities.PERFECT_COPY.get(), PerfectCopyEntity.createAttributes().build());
        event.put(ModEntities.PERFECT_COPY_CLONE.get(), PerfectCopyCloneEntity.createAttributes().build());
    }

    @SubscribeEvent
    public static void onBuildCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            event.accept(ModItems.THE_OBSERVER_SPAWN_EGG);
            event.accept(ModItems.PERFECT_COPY_SPAWN_EGG);
        }
        if (event.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
            event.accept(ModItems.DOMAIN_GATE);
        }
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            event.accept(ModItems.MEMORY_SHARD);
        }
    }
}
