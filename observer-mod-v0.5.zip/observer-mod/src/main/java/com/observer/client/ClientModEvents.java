package com.observer.client;

import com.observer.ObserverMod;
import com.observer.boss.model.PerfectCopyModel;
import com.observer.boss.renderer.PerfectCopyCloneRenderer;
import com.observer.boss.renderer.PerfectCopyRenderer;
import com.observer.registry.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ObserverMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    private ClientModEvents() {
    }

    @SubscribeEvent
    public static void onRegisterLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(PerfectCopyModel.LAYER, PerfectCopyModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.THE_OBSERVER.get(), ObserverRenderer::new);
        event.registerEntityRenderer(ModEntities.PERFECT_COPY.get(), PerfectCopyRenderer::new);
        event.registerEntityRenderer(ModEntities.PERFECT_COPY_CLONE.get(), PerfectCopyCloneRenderer::new);
    }
}
