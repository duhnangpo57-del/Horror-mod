package com.observer.registry;

import com.observer.ObserverMod;
import com.observer.boss.entity.PerfectCopyCloneEntity;
import com.observer.boss.entity.PerfectCopyEntity;
import com.observer.entity.ObserverEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ObserverMod.MODID);

    public static final RegistryObject<EntityType<ObserverEntity>> THE_OBSERVER =
            ENTITY_TYPES.register("the_observer", () ->
                    EntityType.Builder.of(ObserverEntity::new, MobCategory.MISC)
                            .sized(0.6F, 2.0F)
                            .clientTrackingRange(10)
                            .updateInterval(3)
                            .build(new ResourceLocation(ObserverMod.MODID, "the_observer").toString()));

    /** Visual height 10 blocks; the standing hitbox is 2.2 x 6.0 and shrinks when it kneels. */
    public static final RegistryObject<EntityType<PerfectCopyEntity>> PERFECT_COPY =
            ENTITY_TYPES.register("perfect_copy", () ->
                    EntityType.Builder.of(PerfectCopyEntity::new, MobCategory.MONSTER)
                            .sized(2.2F, 6.0F)
                            .clientTrackingRange(24)
                            .updateInterval(2)
                            .fireImmune()
                            .build(new ResourceLocation(ObserverMod.MODID, "perfect_copy").toString()));

    public static final RegistryObject<EntityType<PerfectCopyCloneEntity>> PERFECT_COPY_CLONE =
            ENTITY_TYPES.register("perfect_copy_clone", () ->
                    EntityType.Builder.of(PerfectCopyCloneEntity::new, MobCategory.MONSTER)
                            .sized(0.9F, 2.5F)
                            .clientTrackingRange(16)
                            .fireImmune()
                            .build(new ResourceLocation(ObserverMod.MODID, "perfect_copy_clone").toString()));

    private ModEntities() {
    }
}
