package com.observer.registry;

import com.observer.ObserverMod;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, ObserverMod.MODID);

    public static final RegistryObject<Item> THE_OBSERVER_SPAWN_EGG =
            ITEMS.register("the_observer_spawn_egg", () ->
                    new ForgeSpawnEggItem(ModEntities.THE_OBSERVER, 0x0B0B0B, 0x7A0000, new Item.Properties()));

    public static final RegistryObject<Item> PERFECT_COPY_SPAWN_EGG =
            ITEMS.register("perfect_copy_spawn_egg", () ->
                    new ForgeSpawnEggItem(ModEntities.PERFECT_COPY, 0x2A0A3A, 0xB0B0B0, new Item.Properties()));

    public static final RegistryObject<Item> MEMORY_SHARD =
            ITEMS.register("memory_shard", () ->
                    new Item(new Item.Properties().stacksTo(16).rarity(Rarity.EPIC)));

    public static final RegistryObject<Item> DOMAIN_GATE =
            ITEMS.register("domain_gate", () ->
                    new BlockItem(ModBlocks.DOMAIN_GATE.get(), new Item.Properties().rarity(Rarity.EPIC)));

    private ModItems() {
    }
}
