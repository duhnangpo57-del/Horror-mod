package com.observer.registry;

import com.observer.ObserverMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Custom sound events; the actual audio is mapped in assets/observer/sounds.json. */
public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, ObserverMod.MODID);

    public static final RegistryObject<SoundEvent> DOMAIN_AMBIENT = register("ambient.domain");
    public static final RegistryObject<SoundEvent> HEARTBEAT = register("ambient.heartbeat");

    public static final RegistryObject<SoundEvent> BOSS_AMBIENT = register("boss.ambient");
    public static final RegistryObject<SoundEvent> BOSS_DETECT = register("boss.detect");
    public static final RegistryObject<SoundEvent> BOSS_STEP = register("boss.step");
    public static final RegistryObject<SoundEvent> BOSS_IDLE = register("boss.idle");
    public static final RegistryObject<SoundEvent> BOSS_ATTACK = register("boss.attack");
    public static final RegistryObject<SoundEvent> BOSS_DASH = register("boss.dash");
    public static final RegistryObject<SoundEvent> BOSS_CLONE = register("boss.clone");
    public static final RegistryObject<SoundEvent> BOSS_PULSE = register("boss.pulse");
    public static final RegistryObject<SoundEvent> BOSS_DODGE = register("boss.dodge");
    public static final RegistryObject<SoundEvent> BOSS_TRAP = register("boss.trap");
    public static final RegistryObject<SoundEvent> BOSS_PHASE = register("boss.phase");
    public static final RegistryObject<SoundEvent> BOSS_CORE_EXPOSED = register("boss.core_exposed");
    public static final RegistryObject<SoundEvent> BOSS_CORE_HIT = register("boss.core_hit");
    public static final RegistryObject<SoundEvent> BOSS_FINAL = register("boss.final_copy");
    public static final RegistryObject<SoundEvent> BOSS_DEFEAT = register("boss.defeat");

    private ModSounds() {
    }

    private static RegistryObject<SoundEvent> register(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(ObserverMod.MODID, name)));
    }
}
