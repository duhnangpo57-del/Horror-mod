package com.observer.config;

import net.minecraftforge.common.ForgeConfigSpec;

/** Every number that shapes the boss fight. Stored in observer-boss.toml. */
public final class BossConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.DoubleValue MAX_HEALTH;
    public static final ForgeConfigSpec.DoubleValue HEALTH_PER_EXTRA_PLAYER;
    public static final ForgeConfigSpec.DoubleValue DIFFICULTY;
    public static final ForgeConfigSpec.DoubleValue NORMAL_DAMAGE;
    public static final ForgeConfigSpec.DoubleValue DASH_DAMAGE;
    public static final ForgeConfigSpec.DoubleValue PULSE_DAMAGE;
    public static final ForgeConfigSpec.DoubleValue FINAL_DAMAGE;
    public static final ForgeConfigSpec.DoubleValue COOLDOWN_SCALE;
    public static final ForgeConfigSpec.DoubleValue SOUND_VOLUME;
    public static final ForgeConfigSpec.DoubleValue PARTICLE_SCALE;
    public static final ForgeConfigSpec.IntValue CLONE_COUNT;
    public static final ForgeConfigSpec.IntValue CORE_HITS_REQUIRED;
    public static final ForgeConfigSpec.IntValue CORE_WINDOW_TICKS;
    public static final ForgeConfigSpec.IntValue CORE_CLOSED_TICKS;
    public static final ForgeConfigSpec.BooleanValue ENABLE_DODGE;
    public static final ForgeConfigSpec.BooleanValue ENABLE_ARENA_BLOCK_SKILLS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.comment("Health and damage").push("stats");
        MAX_HEALTH = b.comment("Boss health before multipliers.")
                .defineInRange("maxHealth", 1000.0D, 50.0D, 100000.0D);
        HEALTH_PER_EXTRA_PLAYER = b.comment("Extra health (fraction) for each additional player in the arena.")
                .defineInRange("healthPerExtraPlayer", 0.5D, 0.0D, 5.0D);
        DIFFICULTY = b.comment("Multiplier on health and every damage value.")
                .defineInRange("difficulty", 1.0D, 0.1D, 10.0D);
        NORMAL_DAMAGE = b.defineInRange("normalAttackDamage", 8.0D, 0.5D, 200.0D);
        DASH_DAMAGE = b.defineInRange("shadowDashDamage", 12.0D, 0.5D, 200.0D);
        PULSE_DAMAGE = b.defineInRange("voidPulseDamage", 10.0D, 0.5D, 200.0D);
        FINAL_DAMAGE = b.defineInRange("finalCopyDamage", 24.0D, 0.5D, 400.0D);
        b.pop();

        b.comment("Skills").push("skills");
        COOLDOWN_SCALE = b.comment("Multiplier on every skill cooldown. Lower = more aggressive.")
                .defineInRange("cooldownScale", 1.0D, 0.2D, 5.0D);
        CLONE_COUNT = b.comment("How many Mirror Clones may exist at once.")
                .defineInRange("mirrorClones", 2, 0, 6);
        ENABLE_DODGE = b.comment("Allow the boss to sidestep some attacks in later phases.")
                .define("enablePerfectDodge", true);
        ENABLE_ARENA_BLOCK_SKILLS = b.comment("Allow Block Control and Terrain Break (temporary, restored automatically).")
                .define("enableArenaBlockSkills", true);
        b.pop();

        b.comment("Core weak point").push("core");
        CORE_HITS_REQUIRED = b.defineInRange("hitsRequired", 5, 1, 50);
        CORE_WINDOW_TICKS = b.comment("How long the core stays exposed.")
                .defineInRange("exposedTicks", 200, 40, 2000);
        CORE_CLOSED_TICKS = b.comment("Time in phase 4 between exposures, before the Final Copy.")
                .defineInRange("closedTicks", 400, 100, 6000);
        b.pop();

        b.comment("Presentation").push("presentation");
        SOUND_VOLUME = b.defineInRange("soundVolume", 1.0D, 0.0D, 2.0D);
        PARTICLE_SCALE = b.comment("0 disables boss particles, 1 is normal.")
                .defineInRange("particleScale", 1.0D, 0.0D, 2.0D);
        b.pop();

        SPEC = b.build();
    }

    private BossConfig() {
    }

    public static float scaledDamage(ForgeConfigSpec.DoubleValue base) {
        return (float) (base.get() * DIFFICULTY.get());
    }
}
