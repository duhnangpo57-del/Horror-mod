package com.observer.config;

import net.minecraftforge.common.ForgeConfigSpec;

import java.util.List;

public final class ObserverConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.BooleanValue MEMORY_ENABLED;
    public static final ForgeConfigSpec.IntValue MAX_EVENT_HISTORY;

    public static final ForgeConfigSpec.IntValue HORROR_INTENSITY;

    public static final ForgeConfigSpec.IntValue WATCH_RANGE;
    public static final ForgeConfigSpec.IntValue STARE_TOLERANCE_TICKS;
    public static final ForgeConfigSpec.IntValue BRAIN_INTERVAL_TICKS;
    public static final ForgeConfigSpec.IntValue SCAN_RADIUS;

    public static final ForgeConfigSpec.BooleanValue ALLOW_BLOCK_BREAKING;
    public static final ForgeConfigSpec.BooleanValue ALLOW_BLOCK_PLACING;
    public static final ForgeConfigSpec.BooleanValue RESPECT_MOB_GRIEFING;
    public static final ForgeConfigSpec.BooleanValue PROTECT_PLAYER_BUILDS;
    public static final ForgeConfigSpec.BooleanValue ALLOW_CONTAINER_LOOTING;
    public static final ForgeConfigSpec.IntValue MAX_BREAKS_PER_HOUR;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> BLOCK_BLACKLIST;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> BLOCK_WHITELIST;

    public static final ForgeConfigSpec.BooleanValue STORY_ENABLED;
    public static final ForgeConfigSpec.DoubleValue STORY_PACE;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.comment("Player memory").push("memory");
        MEMORY_ENABLED = b.comment("Record player behaviour (mining, building, combat, routines).")
                .define("enabled", true);
        MAX_EVENT_HISTORY = b.comment("Recent events kept per player.")
                .defineInRange("maxEventHistory", 512, 64, 4096);
        b.pop();

        b.comment("Atmosphere").push("horror");
        HORROR_INTENSITY = b.comment("0 = off, 1 = rare, 2 = normal, 3 = frequent ambient scares.")
                .defineInRange("intensity", 2, 0, 3);
        b.pop();

        b.comment("Observer AI").push("ai");
        WATCH_RANGE = b.comment("How far (blocks) the Observer notices players.")
                .defineInRange("watchRange", 64, 16, 128);
        STARE_TOLERANCE_TICKS = b.comment("How long a player may stare at the Observer before it retreats.")
                .defineInRange("stareToleranceTicks", 30, 5, 200);
        BRAIN_INTERVAL_TICKS = b.comment("Ticks between brain updates. Higher = cheaper, less reactive.")
                .defineInRange("brainIntervalTicks", 5, 2, 20);
        SCAN_RADIUS = b.comment("Horizontal radius (blocks) for resource scans.")
                .defineInRange("scanRadius", 12, 6, 24);
        b.pop();

        b.comment("World interaction safety").push("interaction");
        ALLOW_BLOCK_BREAKING = b.comment("Allow the Observer to break blocks.")
                .define("allowBlockBreaking", true);
        ALLOW_BLOCK_PLACING = b.comment("Allow the Observer to place blocks.")
                .define("allowBlockPlacing", true);
        RESPECT_MOB_GRIEFING = b.comment("Obey the mobGriefing game rule.")
                .define("respectMobGriefing", true);
        PROTECT_PLAYER_BUILDS = b.comment("Never break blocks that a player placed (Overworld).")
                .define("protectPlayerBuilds", true);
        ALLOW_CONTAINER_LOOTING = b.comment("Allow taking useful items from containers no player has touched.")
                .define("allowContainerLooting", true);
        MAX_BREAKS_PER_HOUR = b.comment("Maximum blocks the Observer may break per hour of game time.")
                .defineInRange("maxBreaksPerHour", 600, 0, 100000);
        BLOCK_BLACKLIST = b.comment("Blocks the Observer must never break.")
                .defineListAllowEmpty("blockBlacklist", List.<String>of(
                        "minecraft:bedrock", "minecraft:barrier", "minecraft:command_block",
                        "minecraft:chain_command_block", "minecraft:repeating_command_block",
                        "minecraft:structure_block", "minecraft:jigsaw", "minecraft:spawner",
                        "minecraft:end_portal_frame", "minecraft:end_portal", "minecraft:nether_portal",
                        "minecraft:obsidian", "minecraft:crying_obsidian", "minecraft:respawn_anchor",
                        "minecraft:beacon", "minecraft:white_bed", "minecraft:red_bed", "observer:domain_gate"),
                        o -> o instanceof String);
        BLOCK_WHITELIST = b.comment("If not empty, the Observer may ONLY break these blocks.")
                .defineListAllowEmpty("blockWhitelist", new java.util.ArrayList<String>(), o -> o instanceof String);
        b.pop();

        b.comment("Story").push("story");
        STORY_ENABLED = b.comment("Enable chapter progression.")
                .define("enabled", true);
        STORY_PACE = b.comment("Multiplier on the time needed for each chapter. Lower = faster.")
                .defineInRange("pace", 1.0D, 0.01D, 20.0D);
        b.pop();

        SPEC = b.build();
    }

    private ObserverConfig() {
    }
}
