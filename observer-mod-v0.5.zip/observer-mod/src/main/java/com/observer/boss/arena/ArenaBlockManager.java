package com.observer.boss.arena;

import com.observer.config.BossConfig;
import com.observer.dimension.ArenaGenerator;
import it.unimi.dsi.fastutil.longs.Long2LongMap;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/**
 * Every temporary block the boss places goes through here. Rules: only inside the arena,
 * never on top of a player, walls only replace air, floor changes only replace the arena floor,
 * and everything is restored automatically.
 */
public final class ArenaBlockManager {
    private static final int MAX_TEMP_BLOCKS = 2048;

    private ArenaBlockManager() {
    }

    public static boolean placeTemp(ServerLevel level, BlockPos pos, BlockState state, int ttlTicks) {
        if (!allowed(level, pos) || !level.getBlockState(pos).isAir() || playerNear(level, pos)) {
            return false;
        }
        BossFightData data = BossFightData.get(level.getServer());
        if (data.expiry().size() >= MAX_TEMP_BLOCKS) {
            return false;
        }
        level.setBlock(pos, state, 3);
        data.put(pos.asLong(), level.getGameTime() + ttlTicks);
        return true;
    }

    /** Replaces one arena floor block (y = FLOOR_Y) for a while. */
    public static boolean floorTemp(ServerLevel level, BlockPos pos, BlockState state, int ttlTicks) {
        if (!allowed(level, pos) || pos.getY() != ArenaGenerator.FLOOR_Y) {
            return false;
        }
        BlockState current = level.getBlockState(pos);
        if (current.isAir() || current.is(state.getBlock())) {
            return false;
        }
        BossFightData data = BossFightData.get(level.getServer());
        if (data.expiry().size() >= MAX_TEMP_BLOCKS) {
            return false;
        }
        level.setBlock(pos, state, 3);
        data.put(pos.asLong(), level.getGameTime() + ttlTicks);
        return true;
    }

    private static boolean allowed(ServerLevel level, BlockPos pos) {
        return BossConfig.ENABLE_ARENA_BLOCK_SKILLS.get() && ArenaBoundary.inDomain(level) && ArenaBoundary.contains(pos);
    }

    private static boolean playerNear(ServerLevel level, BlockPos pos) {
        AABB zone = new AABB(pos).inflate(1.5D);
        for (Player p : level.players()) {
            if (p.getBoundingBox().intersects(zone)) {
                return true;
            }
        }
        return false;
    }

    /** Restores everything whose time is up. */
    public static void tick(ServerLevel level) {
        BossFightData data = BossFightData.get(level.getServer());
        if (data.expiry().isEmpty()) {
            return;
        }
        long now = level.getGameTime();
        LongArrayList due = new LongArrayList();
        for (Long2LongMap.Entry e : data.expiry().long2LongEntrySet()) {
            if (e.getLongValue() <= now) {
                due.add(e.getLongKey());
            }
        }
        restore(level, data, due);
    }

    public static void restoreAll(ServerLevel level) {
        BossFightData data = BossFightData.get(level.getServer());
        if (data.expiry().isEmpty()) {
            return;
        }
        restore(level, data, new LongArrayList(data.expiry().keySet()));
    }

    private static void restore(ServerLevel level, BossFightData data, LongArrayList positions) {
        for (int i = 0; i < positions.size(); i++) {
            long packed = positions.getLong(i);
            BlockPos pos = BlockPos.of(packed);
            BlockState original = pos.getY() == ArenaGenerator.FLOOR_Y
                    ? ArenaGenerator.floorState(pos.getX(), pos.getZ())
                    : Blocks.AIR.defaultBlockState();
            level.setBlock(pos, original, 3);
            data.expiry().remove(packed);
        }
        data.setDirty();
    }
}
