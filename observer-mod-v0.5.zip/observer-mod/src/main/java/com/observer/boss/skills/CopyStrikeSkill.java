package com.observer.boss.skills;

import com.observer.boss.BossFx;
import com.observer.boss.animation.BossAnimationState;
import com.observer.boss.combat.BossAttackController;
import com.observer.boss.combat.BossCombatController;
import com.observer.boss.entity.PerfectCopyEntity;
import com.observer.config.BossConfig;
import com.observer.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** Melee that copies the player's own way of fighting: sweep for swords, heavy cleave for axes, thrust otherwise. */
public final class CopyStrikeSkill extends BossSkill {
    private boolean struck;
    private int variant;

    public CopyStrikeSkill() {
        super("copy_strike", 40, 14, 6, 14, 0.0D, 9.0D, 1);
    }

    @Override
    protected void onBegin(SkillContext c) {
        PerfectCopyEntity boss = c.boss();
        struck = false;
        String weapon = boss.getStyle().weaponId();
        variant = weapon.contains("axe") ? 1 : (weapon.isEmpty() || weapon.contains("sword") || weapon.equals("fist")) ? 0 : 2;
        boss.getNavigation().stop();
        boss.animation().play(BossAnimationState.WINDUP);
        BossFx.sound(c.level(), boss.position(), ModSounds.BOSS_ATTACK.get(), 1.0F, 0.7F);
    }

    private double reach() {
        return variant == 2 ? 10.0D : variant == 1 ? 8.5D : 8.0D;
    }

    private double halfAngle() {
        return variant == 0 ? 65.0D : 30.0D;
    }

    @Override
    protected void onTelegraph(SkillContext c, int t) {
        PerfectCopyEntity boss = c.boss();
        if (c.target() != null) {
            BossCombatController.face(boss, c.target().position(), 18.0F);
        }
        if (boss.getStance() == BossStance.BOW) {
            return;
        }
        if (t % 3 == 0) {
            Vec3 forward = BossAttackController.forward(boss);
            double half = Math.toRadians(halfAngle());
            for (double d = 2.0D; d <= reach(); d += 2.0D) {
                for (int side = -1; side <= 1; side += 2) {
                    Vec3 dir = forward.yRot((float) (half * side));
                    BossFx.particles(c.level(), ParticleTypes.DRAGON_BREATH, boss.getX() + dir.x * d, boss.getY() + 0.3D,
                            boss.getZ() + dir.z * d, 1, 0.0D, 0.0D, 0.0D, 0.0D);
                }
            }
        }
    }

    @Override
    protected void onActive(SkillContext c, int t) {
        if (t != 1 || struck) {
            return;
        }
        struck = true;
        PerfectCopyEntity boss = c.boss();
        boss.animation().play(BossAnimationState.ATTACK);

        if (boss.getStance() == BossStance.BOW && c.target() != null) {
            for (int i = -1; i <= 1; i++) {
                boss.shootSoulArrow(c.target(), i * 12.0D);
            }
            return;
        }

        Vec3 forward = BossAttackController.forward(boss);
        float damage = BossConfig.scaledDamage(BossConfig.NORMAL_DAMAGE) * (variant == 1 ? 1.3F : 1.0F);
        for (Player p : BossAttackController.playersInCone(boss, c.level(), forward, reach(), halfAngle())) {
            BossAttackController.damage(boss, p, damage);
            BossAttackController.knock(boss, p, variant == 1 ? 1.2D : 0.8D, 0.35D);
        }
        Vec3 impact = boss.position().add(forward.scale(reach() * 0.6D));
        BossFx.particles(c.level(), ParticleTypes.SWEEP_ATTACK, impact.x, boss.getY() + 2.5D, impact.z, 4, 1.5D, 0.5D, 1.5D, 0.0D);
        BossFx.particles(c.level(), ParticleTypes.DRAGON_BREATH, impact.x, boss.getY() + 1.5D, impact.z, 25, 1.5D, 0.8D, 1.5D, 0.05D);
        BossFx.sound(c.level(), impact, ModSounds.BOSS_ATTACK.get(), 1.4F, 0.6F);
    }

    @Override
    protected void onRecovery(SkillContext c, int t) {
        if (t == 1) {
            c.boss().animation().play(BossAnimationState.IDLE);
        }
    }
}
