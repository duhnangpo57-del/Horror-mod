package com.observer.boss.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.observer.ObserverMod;
import com.observer.boss.entity.PerfectCopyEntity;
import com.observer.boss.model.PerfectCopyModel;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Ten blocks tall: the model is five blocks, drawn at double size. */
public class PerfectCopyRenderer extends MobRenderer<PerfectCopyEntity, PerfectCopyModel<PerfectCopyEntity>> {
    public static final float SCALE = 2.0F;
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(ObserverMod.MODID, "textures/entity/perfect_copy.png");

    public PerfectCopyRenderer(EntityRendererProvider.Context context) {
        super(context, new PerfectCopyModel<>(context.bakeLayer(PerfectCopyModel.LAYER)), 2.4F);
        this.addLayer(new PerfectCopyGlowLayer<>(this));
    }

    @Override
    protected void scale(PerfectCopyEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(SCALE, SCALE, SCALE);
    }

    @Override
    protected float getFlipDegrees(PerfectCopyEntity entity) {
        return 0.0F; // the model plays its own collapse
    }

    @Override
    public ResourceLocation getTextureLocation(PerfectCopyEntity entity) {
        return TEXTURE;
    }
}
