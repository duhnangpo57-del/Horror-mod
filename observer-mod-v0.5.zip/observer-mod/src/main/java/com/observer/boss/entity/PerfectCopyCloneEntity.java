package com.observer.boss.entity;

import com.observer.boss.BossFx;
import com.observer.boss.animation.BossAnimated;
import com.observer.boss.animation.BossAnimationState;
import com.observer.config.BossConfig;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.UUID;

/** A weaker, shorter-lived echo of the boss. Separate entity, hard-capped by the boss, gone after twenty seconds. */
public class PerfectCopyCloneEntity extends Monster implements BossAnimated {
    private static final int LIFETIME_TICKS = 400;

    @Nullable
    private UUID ownerId;
    private int lifeTicks;

    public PerfectCopyCloneEntity(EntityType<? extends PerfectCopyCloneEntity> type, Level level) {
        super(type, level);
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 60.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.34D)
                .add(Attributes.ATTACK_DAMAGE, 4.0D)
                .add(Attributes.FOLLOW_RANGE, 50.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.5D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.1D, true));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    public void setOwnerBoss(PerfectCopyEntity boss) {
        this.ownerId = boss.getUUID();
        AttributeInstance damage = getAttribute(Attributes.ATTACK_DAMAGE);
        if (damage != null) {
            damage.setBaseValue(BossConfig.scaledDamage(BossConfig.NORMAL_DAMAGE) * 0.5D);
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (!(this.level() instanceof ServerLevel level)) {
            return;
        }
        lifeTicks++;
        boolean ownerGone = ownerId != null && level.getEntity(ownerId) == null;
        if (lifeTicks > LIFETIME_TICKS || ownerGone) {
            BossFx.particles(level, ParticleTypes.SOUL, this.getX(), this.getY() + 1.2D, this.getZ(), 20, 0.4D, 0.8D, 0.4D, 0.05D);
            this.discard();
        } else if (lifeTicks % 10 == 0) {
            BossFx.particles(level, ParticleTypes.REVERSE_PORTAL, this.getX(), this.getY() + 1.2D, this.getZ(), 3, 0.3D, 0.8D, 0.3D, 0.03D);
        }
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENDERMAN_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENDERMAN_DEATH;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return true;
    }

    // --- BossAnimated: clones only walk and idle, which the model drives from the limb swing ---

    @Override
    public BossAnimationState getAnimState() {
        return BossAnimationState.IDLE;
    }

    @Override
    public float getAnimTime(float ageInTicks) {
        return ageInTicks;
    }

    @Override
    public boolean isKneeling() {
        return false;
    }

    @Override
    public int getPhaseNumber() {
        return 3;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Life", lifeTicks);
        if (ownerId != null) {
            tag.putUUID("Owner", ownerId);
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        lifeTicks = tag.getInt("Life");
        if (tag.hasUUID("Owner")) {
            ownerId = tag.getUUID("Owner");
        }
    }
}
