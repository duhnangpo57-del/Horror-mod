package com.observer.boss.weakpoint;

import com.observer.boss.BossFx;
import com.observer.boss.animation.BossAnimationState;
import com.observer.boss.entity.PerfectCopyEntity;
import com.observer.config.BossConfig;
import com.observer.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetActionBarTextPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Phase 4 weak point. The boss kneels and the core opens for a limited time. Five core hits
 * (configurable) destabilise it. Hits to the body never count, and never kill it.
 */
public final class CoreExposureController {
    public static final int STATE_CLOSED = 0;
    public static final int STATE_EXPOSED = 1;
    public static final int STATE_DESTABILIZED = 2;

    private static final int HIT_COOLDOWN_TICKS = 12;

    private final PerfectCopyEntity boss;
    private int state = STATE_CLOSED;
    private int windowTicks;
    private int closedCountdown = 200;
    private int hits;
    private int hitCooldown;

    public CoreExposureController(PerfectCopyEntity boss) {
        this.boss = boss;
    }

    public boolean isExposed() {
        return state == STATE_EXPOSED;
    }

    public boolean isDestabilized() {
        return state == STATE_DESTABILIZED;
    }

    public int hits() {
        return hits;
    }

    public int state() {
        return state;
    }

    public void restore(int savedHits, int savedState) {
        hits = Math.max(0, savedHits);
        state = savedState == STATE_DESTABILIZED ? STATE_DESTABILIZED : STATE_CLOSED;
        boss.setCoreHits(hits);
        boss.setCoreState(state);
    }

    /** Called when phase 4 begins. */
    public void onPhase4Start() {
        closedCountdown = Math.max(100, BossConfig.CORE_CLOSED_TICKS.get() / 2);
    }

    public boolean wantsFinalCopy() {
        return boss.getPhaseNumber() == 4 && state == STATE_CLOSED && closedCountdown <= 0;
    }

    public void tick(ServerLevel level) {
        if (boss.getPhaseNumber() < 4) {
            return;
        }
        if (hitCooldown > 0) {
            hitCooldown--;
        }
        if (state == STATE_EXPOSED) {
            windowTicks--;
            if (level.getGameTime() % 10L == 0L) {
                Vec3 core = CoreWeakPoint.worldPos(boss);
                BossFx.particles(level, ParticleTypes.END_ROD, core.x, core.y, core.z, 4, 0.5D, 0.5D, 0.5D, 0.03D);
            }
            if (windowTicks <= 0) {
                close(level);
            }
        } else if (state == STATE_CLOSED && closedCountdown > 0) {
            closedCountdown--;
        }
    }

    public void expose(ServerLevel level) {
        if (state != STATE_CLOSED) {
            return;
        }
        state = STATE_EXPOSED;
        windowTicks = BossConfig.CORE_WINDOW_TICKS.get();
        boss.skills().cancel();
        boss.getNavigation().stop();
        boss.setKneeling(true);
        boss.animation().play(BossAnimationState.KNEEL);
        boss.setCoreState(state);
        BossFx.sound(level, boss.position(), ModSounds.BOSS_CORE_EXPOSED.get(), 1.5F, 0.9F);
        broadcast(level, Component.translatable("boss.observer.core_exposed")
                .append("  ").append(Component.translatable("boss.observer.core_hits", hits, required())));
        boss.refreshHud();
    }

    public void close(ServerLevel level) {
        if (state != STATE_EXPOSED) {
            return;
        }
        state = STATE_CLOSED;
        closedCountdown = BossConfig.CORE_CLOSED_TICKS.get();
        boss.setKneeling(false);
        boss.animation().play(BossAnimationState.IDLE);
        boss.setCoreState(state);
        BossFx.particles(level, ParticleTypes.SOUL, boss.getX(), boss.getY() + 4.0D, boss.getZ(), 20, 1.0D, 1.5D, 1.0D, 0.05D);
        boss.refreshHud();
    }

    /** @return true if this hit counted. */
    public boolean registerHit(ServerLevel level, ServerPlayer attacker) {
        if (state != STATE_EXPOSED || hitCooldown > 0) {
            return false;
        }
        hits++;
        hitCooldown = HIT_COOLDOWN_TICKS;
        boss.setCoreHits(hits);
        Vec3 core = CoreWeakPoint.worldPos(boss);
        BossFx.sound(level, core, ModSounds.BOSS_CORE_HIT.get(), 1.4F, 0.8F + 0.1F * hits);
        BossFx.particles(level, ParticleTypes.CRIT, core.x, core.y, core.z, 25, 0.6D, 0.6D, 0.6D, 0.3D);
        BossFx.particles(level, ParticleTypes.END_ROD, core.x, core.y, core.z, 12, 0.5D, 0.5D, 0.5D, 0.15D);
        if (hits >= required()) {
            state = STATE_DESTABILIZED;
            boss.setCoreState(state);
            broadcast(level, Component.translatable("boss.observer.core_destabilized"));
            boss.refreshHud();
            boss.startDefeat(level);
        } else {
            broadcast(level, Component.translatable("boss.observer.core_hits", hits, required()));
            boss.refreshHud();
        }
        return true;
    }

    private static int required() {
        return BossConfig.CORE_HITS_REQUIRED.get();
    }

    private void broadcast(ServerLevel level, Component message) {
        for (Player p : level.players()) {
            if (p instanceof ServerPlayer sp && sp.distanceToSqr(boss) < 80.0D * 80.0D) {
                sp.connection.send(new ClientboundSetActionBarTextPacket(message));
            }
        }
    }
}
