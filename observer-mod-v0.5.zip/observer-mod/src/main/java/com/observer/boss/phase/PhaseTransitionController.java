package com.observer.boss.phase;

import com.observer.boss.BossFx;
import com.observer.boss.animation.BossAnimationState;
import com.observer.boss.combat.BossAttackController;
import com.observer.boss.entity.PerfectCopyEntity;
import com.observer.registry.ModSounds;
import com.observer.story.Dialogue;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

/** The roar between phases: the boss stops, cannot be hurt, and throws everyone back. */
public final class PhaseTransitionController {
    private static final int DURATION = 60;

    private final PerfectCopyEntity boss;
    private int ticks;

    public PhaseTransitionController(PerfectCopyEntity boss) {
        this.boss = boss;
    }

    public boolean active() {
        return ticks > 0;
    }

    public void begin(ServerLevel level, BossPhase next) {
        ticks = DURATION;
        boss.skills().cancel();
        boss.getNavigation().stop();
        boss.setInvulnerable(true);
        boss.animation().play(BossAnimationState.ROAR);
        BossFx.sound(level, boss.position(), ModSounds.BOSS_PHASE.get(), 1.6F, 1.0F);
        BossFx.particles(level, ParticleTypes.SOUL, boss.getX(), boss.getY() + 6.0D, boss.getZ(), 50, 1.2D, 2.5D, 1.2D, 0.06D);
        BossAttackController.pushPlayers(boss, level, 14.0D, 1.4D, 0.5D);
        for (Player p : level.players()) {
            if (p instanceof ServerPlayer sp && sp.distanceToSqr(boss) < 80.0D * 80.0D) {
                Dialogue.title(sp, next.titleKey(), "boss.observer.phase_subtitle");
            }
        }
    }

    public void tick(ServerLevel level) {
        if (ticks <= 0) {
            return;
        }
        ticks--;
        if (ticks % 6 == 0) {
            BossFx.particles(level, ParticleTypes.REVERSE_PORTAL, boss.getX(), boss.getY() + 6.0D, boss.getZ(),
                    8, 1.0D, 2.0D, 1.0D, 0.08D);
        }
        if (ticks == 0) {
            boss.setInvulnerable(false);
            boss.animation().play(BossAnimationState.IDLE);
            boss.onTransitionFinished(level);
        }
    }

    public void forceEnd() {
        ticks = 0;
    }
}
