package com.observer.boss.ai;

import com.observer.boss.BossFx;
import com.observer.boss.animation.BossAnimationState;
import com.observer.boss.combat.BossCombatController;
import com.observer.boss.combat.BossTargetController;
import com.observer.boss.entity.PerfectCopyEntity;
import com.observer.boss.skills.BossSkill;
import com.observer.boss.skills.BossStance;
import com.observer.boss.skills.SkillContext;
import com.observer.registry.ModSounds;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;

import javax.annotation.Nullable;

/**
 * Sense -> read memory -> analyse -> choose -> act. Decisions are cached and only made every few ticks.
 * The boss reacts to the player's behaviour with plain algorithms, nothing more.
 */
public final class PerfectCopyBrain {
    private static final int DECISION_INTERVAL = 8;

    private final PerfectCopyEntity boss;
    private final BossTargetController targets = new BossTargetController();
    private final SkillSelector selector = new SkillSelector();
    private final AdaptivePlanner planner = new AdaptivePlanner();
    private final ThreatEvaluator threats = new ThreatEvaluator();

    @Nullable
    private LivingEntity target;
    private CombatAnalyzer.Readout readout = CombatAnalyzer.Readout.NEUTRAL;
    private BossStance suggested = BossStance.BLADE;
    private float threat;
    private int nextDecision;
    private boolean detected;

    public PerfectCopyBrain(PerfectCopyEntity boss) {
        this.boss = boss;
    }

    @Nullable
    public LivingEntity target() {
        return target;
    }

    public BossStance suggestedStance() {
        return suggested;
    }

    public CombatAnalyzer.Readout readout() {
        return readout;
    }

    public void tick(ServerLevel level) {
        if (boss.tickCount % 10 == 0 || target == null || !target.isAlive()) {
            target = targets.update(boss, level);
        }
        SkillContext ctx = new SkillContext(boss, level, target, target == null ? 0.0D : boss.distanceTo(target));

        if (boss.isKneeling()) { // core is open: no attacks, just turn toward whoever is hitting it
            boss.getNavigation().stop();
            if (target != null) {
                BossCombatController.face(boss, target.position(), 8.0F);
            }
            return;
        }
        if (boss.skills().isRunning()) {
            boss.skills().tick(ctx);
            return;
        }
        if (target == null) {
            boss.getNavigation().stop();
            boss.animation().play(BossAnimationState.IDLE);
            return;
        }
        if (!detected) {
            detected = true;
            BossFx.sound(level, boss.position(), ModSounds.BOSS_DETECT.get(), 1.4F, 0.7F);
        }

        if (boss.tickCount % 10 == 0) {
            if (target instanceof ServerPlayer player) {
                boss.analyzer().samplePlayer(player, ctx.distance());
            }
            readout = boss.analyzer().read(level.getGameTime(), boss.getStyle());
            threat = threats.evaluate(boss, level);
            suggested = planner.stanceFor(readout, threat);
        }

        BossCombatController.move(boss, target, ctx.distance(), boss.getStance());

        if (boss.tickCount >= nextDecision) {
            nextDecision = boss.tickCount + DECISION_INTERVAL;
            BossSkill skill = selector.select(ctx, readout, boss.getStance(), threat, boss.getRandom());
            if (skill != null) {
                boss.skills().start(skill, ctx);
            }
        }
    }
}
