package com.observer.boss.combat;

import com.observer.boss.entity.PerfectCopyEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Picks who to fight. The boss only knows about a player it can see, one standing very close,
 * or one it saw a few seconds ago. It never tracks anyone through walls.
 */
public final class BossTargetController {
    private static final int MEMORY_TICKS = 100;
    private static final double SENSE_RADIUS = 10.0D;
    private static final double MAX_RANGE = 70.0D;

    private final Map<UUID, Long> lastSeen = new HashMap<>();

    @Nullable
    public LivingEntity update(PerfectCopyEntity boss, ServerLevel level) {
        long now = level.getGameTime();
        Player best = null;
        double bestScore = Double.MAX_VALUE;
        for (Player p : level.players()) {
            if (!p.isAlive() || p.isSpectator()) {
                continue;
            }
            double distance = boss.distanceTo(p);
            if (distance > MAX_RANGE) {
                continue;
            }
            boolean visible = distance < SENSE_RADIUS || boss.hasLineOfSight(p);
            if (visible) {
                lastSeen.put(p.getUUID(), now);
            }
            Long seen = lastSeen.get(p.getUUID());
            if (seen == null || now - seen > MEMORY_TICKS) {
                continue;
            }
            double score = distance + (visible ? 0.0D : 20.0D) - (boss.isRecentAttacker(p) ? 12.0D : 0.0D);
            if (score < bestScore) {
                bestScore = score;
                best = p;
            }
        }
        return best;
    }
}
