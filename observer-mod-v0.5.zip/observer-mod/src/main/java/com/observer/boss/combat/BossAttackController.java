package com.observer.boss.combat;

import com.observer.boss.entity.PerfectCopyEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** Hit detection and damage delivery. All of it runs on the server. */
public final class BossAttackController {
    private BossAttackController() {
    }

    public static Vec3 forward(PerfectCopyEntity boss) {
        double yaw = Math.toRadians(boss.yBodyRot);
        return new Vec3(-Math.sin(yaw), 0.0D, Math.cos(yaw));
    }

    public static List<Player> playersInRange(PerfectCopyEntity boss, ServerLevel level, double range) {
        List<Player> found = new ArrayList<>();
        for (Player p : level.players()) {
            if (!p.isAlive() || p.isSpectator()) {
                continue;
            }
            double dx = p.getX() - boss.getX();
            double dz = p.getZ() - boss.getZ();
            if (dx * dx + dz * dz <= range * range && Math.abs(p.getY() - boss.getY()) <= 8.0D) {
                found.add(p);
            }
        }
        return found;
    }

    public static List<Player> playersInCone(PerfectCopyEntity boss, ServerLevel level, Vec3 forward,
                                             double range, double halfAngleDegrees) {
        List<Player> found = new ArrayList<>();
        double minCos = Math.cos(Math.toRadians(halfAngleDegrees));
        for (Player p : playersInRange(boss, level, range + 1.0D)) {
            Vec3 to = new Vec3(p.getX() - boss.getX(), 0.0D, p.getZ() - boss.getZ());
            double length = to.length();
            if (length < 0.001D || to.dot(forward) / length >= minCos) {
                found.add(p);
            }
        }
        return found;
    }

    public static void damage(PerfectCopyEntity boss, LivingEntity victim, float amount) {
        victim.hurt(boss.damageSources().mobAttack(boss), amount);
    }

    public static void knock(PerfectCopyEntity boss, LivingEntity victim, double horizontal, double vertical) {
        Vec3 away = new Vec3(victim.getX() - boss.getX(), 0.0D, victim.getZ() - boss.getZ());
        away = away.lengthSqr() < 1.0E-4D ? forward(boss) : away.normalize();
        victim.setDeltaMovement(victim.getDeltaMovement().add(away.x * horizontal, vertical, away.z * horizontal));
        victim.hurtMarked = true;
    }

    /** Throws players back without hurting them. */
    public static void pushPlayers(PerfectCopyEntity boss, ServerLevel level, double radius, double horizontal, double vertical) {
        for (Player p : playersInRange(boss, level, radius)) {
            knock(boss, p, horizontal, vertical);
        }
    }
}
