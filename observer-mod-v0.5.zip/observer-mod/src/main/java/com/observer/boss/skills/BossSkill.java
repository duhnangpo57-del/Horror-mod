package com.observer.boss.skills;

import com.observer.boss.entity.PerfectCopyEntity;
import com.observer.config.BossConfig;

/**
 * A skill is: telegraph (a warning the player can read), active (the effect), recovery (a window
 * to punish). Everything runs on the server; clients only see particles, sounds and the synced pose.
 */
public abstract class BossSkill {
    private final String id;
    private final int baseCooldown;
    private final int telegraphTicks;
    private final int activeTicks;
    private final int recoveryTicks;
    private final double minRange;
    private final double maxRange;
    private final int minPhase;

    private long readyAt;
    private int timer;
    private boolean running;

    protected BossSkill(String id, int baseCooldown, int telegraphTicks, int activeTicks, int recoveryTicks,
                        double minRange, double maxRange, int minPhase) {
        this.id = id;
        this.baseCooldown = baseCooldown;
        this.telegraphTicks = telegraphTicks;
        this.activeTicks = activeTicks;
        this.recoveryTicks = recoveryTicks;
        this.minRange = minRange;
        this.maxRange = maxRange;
        this.minPhase = minPhase;
    }

    public String id() {
        return id;
    }

    public boolean isRunning() {
        return running;
    }

    /** Reactive skills are triggered by events, not chosen by the selector. */
    public boolean isReactive() {
        return false;
    }

    public boolean ready(PerfectCopyEntity boss) {
        return boss.tickCount >= readyAt;
    }

    public boolean canUse(SkillContext c) {
        return !isReactive()
                && c.target() != null
                && ready(c.boss())
                && c.boss().getPhaseNumber() >= minPhase
                && c.distance() >= minRange
                && c.distance() <= maxRange
                && extraCheck(c);
    }

    protected boolean extraCheck(SkillContext c) {
        return true;
    }

    public final void begin(SkillContext c) {
        running = true;
        timer = 0;
        onBegin(c);
    }

    /** @return true while the skill is still running. */
    public final boolean tick(SkillContext c) {
        if (!running) {
            return false;
        }
        timer++;
        if (timer <= telegraphTicks) {
            onTelegraph(c, timer);
        } else if (timer <= telegraphTicks + activeTicks) {
            onActive(c, timer - telegraphTicks);
        } else if (timer <= telegraphTicks + activeTicks + recoveryTicks) {
            onRecovery(c, timer - telegraphTicks - activeTicks);
        } else {
            running = false;
            onEnd(c);
            startCooldown(c.boss());
            return false;
        }
        return true;
    }

    public final void cancel(PerfectCopyEntity boss) {
        if (running) {
            running = false;
            timer = 0;
            onCancel(boss);
            startCooldown(boss);
        }
    }

    protected final void startCooldown(PerfectCopyEntity boss) {
        readyAt = boss.tickCount + (long) Math.max(1.0D, baseCooldown * BossConfig.COOLDOWN_SCALE.get());
    }

    protected void onBegin(SkillContext c) {
    }

    protected void onTelegraph(SkillContext c, int t) {
    }

    protected void onActive(SkillContext c, int t) {
    }

    protected void onRecovery(SkillContext c, int t) {
    }

    protected void onEnd(SkillContext c) {
    }

    protected void onCancel(PerfectCopyEntity boss) {
    }
}
