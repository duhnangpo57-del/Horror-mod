package com.observer.boss.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.observer.ObserverMod;
import com.observer.boss.entity.PerfectCopyCloneEntity;
import com.observer.boss.model.PerfectCopyModel;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

/** The clones use the same model at half the boss's size. */
public class PerfectCopyCloneRenderer extends MobRenderer<PerfectCopyCloneEntity, PerfectCopyModel<PerfectCopyCloneEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(ObserverMod.MODID, "textures/entity/perfect_copy.png");

    public PerfectCopyCloneRenderer(EntityRendererProvider.Context context) {
        super(context, new PerfectCopyModel<>(context.bakeLayer(PerfectCopyModel.LAYER)), 0.9F);
        this.addLayer(new PerfectCopyGlowLayer<>(this));
    }

    @Override
    protected void scale(PerfectCopyCloneEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(0.5F, 0.5F, 0.5F);
    }

    @Override
    protected float getFlipDegrees(PerfectCopyCloneEntity entity) {
        return 0.0F;
    }

    @Override
    public ResourceLocation getTextureLocation(PerfectCopyCloneEntity entity) {
        return TEXTURE;
    }
}
