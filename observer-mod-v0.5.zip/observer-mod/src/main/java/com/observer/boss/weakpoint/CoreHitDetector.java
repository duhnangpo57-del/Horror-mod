package com.observer.boss.weakpoint;

import com.observer.boss.entity.PerfectCopyEntity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;

/**
 * Decides, on the server, whether a hit landed on the core. Only the attacker's real position
 * and look direction count; nothing the client reports is trusted.
 */
public final class CoreHitDetector {
    private static final double MAX_MELEE_DISTANCE_SQR = 8.0D * 8.0D;
    private static final double MAX_SHOT_DISTANCE_SQR = 80.0D * 80.0D;

    private CoreHitDetector() {
    }

    @Nullable
    public static ServerPlayer validate(PerfectCopyEntity boss, DamageSource source) {
        if (!(source.getEntity() instanceof ServerPlayer player)) {
            return null;
        }
        Vec3 core = CoreWeakPoint.worldPos(boss);
        AABB box = new AABB(core, core).inflate(CoreWeakPoint.RADIUS);
        Entity direct = source.getDirectEntity();

        if (direct == player) {
            if (player.distanceToSqr(core) > MAX_MELEE_DISTANCE_SQR) {
                return null;
            }
            Vec3 eye = player.getEyePosition();
            Vec3 end = eye.add(player.getViewVector(1.0F).scale(7.0D));
            return box.contains(eye) || box.clip(eye, end).isPresent() ? player : null;
        }
        if (direct != null && player.distanceToSqr(core) <= MAX_SHOT_DISTANCE_SQR) {
            double reach = CoreWeakPoint.RADIUS + 0.8D;
            return direct.position().distanceToSqr(core) <= reach * reach ? player : null;
        }
        return null;
    }
}
