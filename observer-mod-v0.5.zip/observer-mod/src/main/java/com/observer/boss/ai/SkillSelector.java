package com.observer.boss.ai;

import com.observer.boss.entity.PerfectCopyEntity;
import com.observer.boss.skills.BossSkill;
import com.observer.boss.skills.BossStance;
import com.observer.boss.skills.SkillContext;
import net.minecraft.util.RandomSource;

import javax.annotation.Nullable;

/** Utility scoring: every usable skill gets a score from distance, player habits, stance and threat. */
public final class SkillSelector {
    @Nullable
    public BossSkill select(SkillContext c, CombatAnalyzer.Readout r, BossStance stance, float threat, RandomSource random) {
        PerfectCopyEntity boss = c.boss();
        BossSkill finalCopy = boss.skills().finalCopy();

        if (boss.core().wantsFinalCopy()) {
            return finalCopy.canUse(c) ? finalCopy : null;
        }

        BossSkill best = null;
        double bestScore = 0.0D;
        for (BossSkill skill : boss.skills().selectable()) {
            if (skill == finalCopy || !skill.canUse(c)) {
                continue;
            }
            double score = score(skill.id(), c.distance(), r, stance, threat) * (0.85D + random.nextDouble() * 0.3D);
            if (score > bestScore) {
                bestScore = score;
                best = skill;
            }
        }
        return best;
    }

    private static double score(String id, double distance, CombatAnalyzer.Readout r, BossStance stance, float threat) {
        double s = switch (id) {
            case "copy_strike" -> 1.0D + (distance < 8.0D ? 2.0D : 0.0D) + r.meleeBias() * 0.5D;
            case "shadow_dash" -> 1.0D + (distance > 9.0D ? 1.5D : 0.0D) + r.rangedBias() * 1.5D;
            case "void_pulse" -> 1.0D + (distance < 12.0D ? 1.2D : 0.0D) + r.meleeBias() * 0.8D;
            case "mirror_clone" -> 1.4D;
            case "block_control" -> 0.9D + r.rangedBias() * 1.2D;
            case "terrain_break" -> 0.9D + r.mobility() * 1.5D + r.shieldBias();
            case "memory_trap" -> 0.9D + r.mobility() * 1.5D;
            case "weapon_shift" -> 2.5D;
            default -> 1.0D;
        };
        switch (stance) {
            case BLADE -> {
                if (id.equals("copy_strike") || id.equals("shadow_dash")) {
                    s *= 1.4D;
                }
            }
            case BOW -> {
                if (id.equals("shadow_dash")) {
                    s *= 1.3D;
                }
                if (id.equals("copy_strike")) {
                    s *= 1.2D;
                }
            }
            case SHIELD -> {
                if (id.equals("void_pulse")) {
                    s *= 1.4D;
                }
            }
            case CONTROL -> {
                if (id.equals("block_control") || id.equals("terrain_break") || id.equals("memory_trap") || id.equals("void_pulse")) {
                    s *= 1.5D;
                }
            }
        }
        if (threat > 0.7F && id.equals("void_pulse")) {
            s *= 1.3D;
        }
        return s;
    }
}
