package com.observer.boss.ai;

import com.observer.boss.skills.BossStance;

/** Picks the stance that answers the player's habits. Always one of the four fixed stances. */
public final class AdaptivePlanner {
    public BossStance stanceFor(CombatAnalyzer.Readout r, float threat) {
        if (threat > 0.85F && r.meleeBias() > 0.5D) {
            return BossStance.SHIELD;
        }
        if (r.rangedBias() > 0.6D) {
            return BossStance.BOW;
        }
        if (r.shieldBias() > 0.3D || r.mobility() > 0.55D) {
            return BossStance.CONTROL;
        }
        return BossStance.BLADE;
    }
}
