package com.observer.boss.skills;

import com.observer.boss.BossFx;
import com.observer.boss.animation.BossAnimationState;
import com.observer.boss.combat.BossAttackController;
import com.observer.boss.entity.PerfectCopyEntity;
import com.observer.boss.weakpoint.CoreWeakPoint;
import com.observer.config.BossConfig;
import com.observer.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Phase 4 ultimate. The boss freezes, the core charges, the arena darkens, and the floor is split into
 * eight wedges: four glow. Stand in an unmarked wedge. Then the wedges swap and it strikes again.
 * Afterwards the boss kneels and the core opens.
 */
public final class FinalCopySkill extends BossSkill {
    private static final int SECTORS = 8;
    private static final double RADIUS = 26.0D;

    private int parity;

    public FinalCopySkill() {
        super("final_copy", 300, 80, 24, 60, 0.0D, 80.0D, 4);
    }

    @Override
    protected void onBegin(SkillContext c) {
        PerfectCopyEntity boss = c.boss();
        boss.getNavigation().stop();
        boss.animation().play(BossAnimationState.CAST);
        parity = boss.getRandom().nextInt(2);
        BossFx.sound(c.level(), boss.position(), ModSounds.BOSS_FINAL.get(), 1.8F, 0.7F);
        for (Player p : BossAttackController.playersInRange(boss, c.level(), 40.0D)) {
            p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 120, 0, false, false));
        }
    }

    @Override
    protected void onTelegraph(SkillContext c, int t) {
        PerfectCopyEntity boss = c.boss();
        Vec3 core = CoreWeakPoint.worldPos(boss);
        BossFx.particles(c.level(), ParticleTypes.END_ROD, core.x, core.y, core.z, 4, 0.8D, 0.8D, 0.8D, 0.04D);
        if (t % 4 == 0) {
            drawWedges(c.level(), boss, parity);
        }
    }

    @Override
    protected void onActive(SkillContext c, int t) {
        PerfectCopyEntity boss = c.boss();
        if (t == 1) {
            strike(c.level(), boss, parity);
        } else if (t == 12) {
            parity = 1 - parity;
            BossFx.sound(c.level(), boss.position(), ModSounds.BOSS_FINAL.get(), 1.4F, 1.0F);
        } else if (t > 12 && t % 4 == 0 && t < 18) {
            drawWedges(c.level(), boss, parity);
        } else if (t == 18) {
            strike(c.level(), boss, parity);
        }
    }

    @Override
    protected void onRecovery(SkillContext c, int t) {
        if (t == 1) {
            c.boss().animation().play(BossAnimationState.KNEEL);
        }
    }

    @Override
    protected void onEnd(SkillContext c) {
        c.boss().core().expose(c.level());
    }

    private static void drawWedges(ServerLevel level, PerfectCopyEntity boss, int parity) {
        double step = Math.PI * 2.0D / SECTORS;
        for (int s = 0; s < SECTORS; s++) {
            if (s % 2 != parity) {
                continue;
            }
            for (double r = 6.0D; r <= RADIUS; r += 6.0D) {
                for (int k = 1; k <= 3; k++) {
                    double angle = s * step + step * k / 4.0D - Math.PI;
                    BossFx.particles(level, ParticleTypes.DRAGON_BREATH, boss.getX() + Math.cos(angle) * r, boss.getY() + 0.4D,
                            boss.getZ() + Math.sin(angle) * r, 1, 0.0D, 0.0D, 0.0D, 0.0D);
                }
            }
        }
    }

    private static void strike(ServerLevel level, PerfectCopyEntity boss, int parity) {
        BossFx.sound(level, boss.position(), ModSounds.BOSS_PULSE.get(), 1.8F, 0.5F);
        double step = Math.PI * 2.0D / SECTORS;
        for (Player p : BossAttackController.playersInRange(boss, level, RADIUS)) {
            double angle = Math.atan2(p.getZ() - boss.getZ(), p.getX() - boss.getX()) + Math.PI;
            int sector = (int) (angle / step) % SECTORS;
            if (sector % 2 == parity) {
                BossAttackController.damage(boss, p, BossConfig.scaledDamage(BossConfig.FINAL_DAMAGE));
                BossAttackController.knock(boss, p, 0.8D, 0.6D);
                if (p instanceof ServerPlayer) {
                    BossFx.particles(level, ParticleTypes.EXPLOSION, p.getX(), p.getY() + 1.0D, p.getZ(), 1, 0.0D, 0.0D, 0.0D, 0.0D);
                }
            }
        }
        for (int s = 0; s < SECTORS; s++) {
            if (s % 2 == parity) {
                double angle = s * step + step * 0.5D - Math.PI;
                BossFx.particles(level, ParticleTypes.FLASH, boss.getX() + Math.cos(angle) * 14.0D, boss.getY() + 1.0D,
                        boss.getZ() + Math.sin(angle) * 14.0D, 1, 0.0D, 0.0D, 0.0D, 0.0D);
            }
        }
    }
}
