package com.observer.boss.skills;

import com.observer.boss.BossFx;
import com.observer.boss.animation.BossAnimationState;
import com.observer.boss.combat.BossAttackController;
import com.observer.boss.combat.BossCombatController;
import com.observer.boss.entity.PerfectCopyEntity;
import com.observer.config.BossConfig;
import com.observer.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Picks a line, shows it, then charges along it. The line stops tracking before the dash, so sidestepping works. */
public final class ShadowDashSkill extends BossSkill {
    private static final int LOCK_TICK = 12;

    private Vec3 direction = new Vec3(0.0D, 0.0D, 1.0D);
    private double distance;
    private final Set<UUID> struck = new HashSet<>();

    public ShadowDashSkill() {
        super("shadow_dash", 140, 20, 12, 20, 6.0D, 24.0D, 1);
    }

    @Override
    protected void onBegin(SkillContext c) {
        struck.clear();
        c.boss().getNavigation().stop();
        c.boss().animation().play(BossAnimationState.WINDUP);
        BossFx.sound(c.level(), c.boss().position(), ModSounds.BOSS_DASH.get(), 1.2F, 0.7F);
        aimAtTarget(c);
    }

    private void aimAtTarget(SkillContext c) {
        if (c.target() == null) {
            return;
        }
        Vec3 flat = new Vec3(c.target().getX() - c.boss().getX(), 0.0D, c.target().getZ() - c.boss().getZ());
        double length = flat.length();
        if (length > 0.01D) {
            direction = flat.scale(1.0D / length);
            distance = Math.min(length - 1.5D, 24.0D);
        }
    }

    @Override
    protected void onTelegraph(SkillContext c, int t) {
        PerfectCopyEntity boss = c.boss();
        if (t < LOCK_TICK) {
            aimAtTarget(c);
        }
        BossCombatController.face(boss, boss.position().add(direction), 40.0F);
        if (t % 2 == 0) {
            for (int i = 1; i <= 8; i++) {
                double d = distance * i / 8.0D;
                BossFx.particles(c.level(), ParticleTypes.DRAGON_BREATH, boss.getX() + direction.x * d, boss.getY() + 0.3D,
                        boss.getZ() + direction.z * d, 1, 0.1D, 0.0D, 0.1D, 0.0D);
            }
        }
    }

    @Override
    protected void onActive(SkillContext c, int t) {
        PerfectCopyEntity boss = c.boss();
        boss.animation().play(BossAnimationState.DASH);
        double speed = Math.max(0.5D, distance / 12.0D);
        boss.setDeltaMovement(direction.x * speed, boss.getDeltaMovement().y, direction.z * speed);
        boss.hurtMarked = true;
        BossFx.particles(c.level(), ParticleTypes.SQUID_INK, boss.getX(), boss.getY() + 3.0D, boss.getZ(), 6, 0.9D, 2.5D, 0.9D, 0.02D);
        BossFx.particles(c.level(), ParticleTypes.DRAGON_BREATH, boss.getX(), boss.getY() + 1.5D, boss.getZ(), 6, 0.9D, 1.5D, 0.9D, 0.04D);

        AABB zone = boss.getBoundingBox().inflate(1.2D, 0.5D, 1.2D);
        for (Player p : BossAttackController.playersInRange(boss, c.level(), 12.0D)) {
            if (p.getBoundingBox().intersects(zone) && struck.add(p.getUUID())) {
                BossAttackController.damage(boss, p, BossConfig.scaledDamage(BossConfig.DASH_DAMAGE));
                BossAttackController.knock(boss, p, 1.4D, 0.5D);
            }
        }
    }

    @Override
    protected void onRecovery(SkillContext c, int t) {
        if (t == 1) {
            c.boss().setDeltaMovement(0.0D, c.boss().getDeltaMovement().y, 0.0D);
            c.boss().animation().play(BossAnimationState.IDLE);
        }
    }
}
