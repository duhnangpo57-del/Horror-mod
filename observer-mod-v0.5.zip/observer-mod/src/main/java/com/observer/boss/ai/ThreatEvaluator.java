package com.observer.boss.ai;

import com.observer.boss.combat.BossAttackController;
import com.observer.boss.entity.PerfectCopyEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;

public final class ThreatEvaluator {
    /** 0 = relaxed, 1 = in real trouble. More players nearby and less health both raise it. */
    public float evaluate(PerfectCopyEntity boss, ServerLevel level) {
        int near = BossAttackController.playersInRange(boss, level, 20.0D).size();
        float lost = 1.0F - boss.getHealth() / boss.getMaxHealth();
        return Mth.clamp(near * 0.25F + lost * 0.6F, 0.0F, 1.0F);
    }
}
