package com.observer.boss.animation;

import com.observer.boss.entity.PerfectCopyEntity;

/** The one place that changes the boss's synced animation state. */
public final class BossAnimationController {
    private final PerfectCopyEntity boss;

    public BossAnimationController(PerfectCopyEntity boss) {
        this.boss = boss;
    }

    public void play(BossAnimationState state) {
        if (boss.getAnimState() != state) {
            boss.setAnimState(state);
        }
    }

    /** Idle, walk or run depending on how fast the boss is actually moving. */
    public void locomotion(boolean wantsRun) {
        double speedSqr = boss.getDeltaMovement().horizontalDistanceSqr();
        if (speedSqr < 0.0004D) {
            play(BossAnimationState.IDLE);
        } else {
            play(wantsRun ? BossAnimationState.RUN : BossAnimationState.WALK);
        }
    }
}
