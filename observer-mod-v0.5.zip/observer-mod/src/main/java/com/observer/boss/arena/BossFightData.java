package com.observer.boss.arena;

import it.unimi.dsi.fastutil.longs.Long2LongMap;
import it.unimi.dsi.fastutil.longs.Long2LongOpenHashMap;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** Saved list of temporary arena changes, so a crash mid-fight can never leave the arena broken. */
public class BossFightData extends SavedData {
    public static final String DATA_NAME = "observer_boss_fight";

    private final Long2LongOpenHashMap expiry = new Long2LongOpenHashMap();

    public static BossFightData get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(BossFightData::load, BossFightData::new, DATA_NAME);
    }

    public Long2LongOpenHashMap expiry() {
        return expiry;
    }

    public void put(long pos, long expireTick) {
        expiry.put(pos, expireTick);
        setDirty();
    }

    public void clear() {
        if (!expiry.isEmpty()) {
            expiry.clear();
            setDirty();
        }
    }

    public static BossFightData load(CompoundTag tag) {
        BossFightData d = new BossFightData();
        long[] pos = tag.getLongArray("Pos");
        long[] exp = tag.getLongArray("Expire");
        int n = Math.min(Math.min(pos.length, exp.length), 8192);
        for (int i = 0; i < n; i++) {
            d.expiry.put(pos[i], exp[i]);
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        long[] pos = new long[expiry.size()];
        long[] exp = new long[expiry.size()];
        int i = 0;
        for (Long2LongMap.Entry e : expiry.long2LongEntrySet()) {
            pos[i] = e.getLongKey();
            exp[i] = e.getLongValue();
            i++;
        }
        tag.putLongArray("Pos", pos);
        tag.putLongArray("Expire", exp);
        return tag;
    }
}
