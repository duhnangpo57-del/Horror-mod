package com.observer.boss.combat;

import com.observer.boss.BossFx;
import com.observer.boss.entity.PerfectCopyEntity;
import com.observer.boss.skills.BossStance;
import com.observer.boss.weakpoint.CoreHitDetector;
import com.observer.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Everything that happens when something hurts the boss: core hits, body hits while the core is open,
 * Perfect Dodge, frontal guard, and the rule that nothing can kill it except the core.
 */
public final class BossDamageHandler {
    public record Outcome(boolean cancel, float amount) {
    }

    private final PerfectCopyEntity boss;

    public BossDamageHandler(PerfectCopyEntity boss) {
        this.boss = boss;
    }

    public Outcome process(DamageSource source, float amount) {
        if (!(boss.level() instanceof ServerLevel level)) {
            return new Outcome(false, amount);
        }
        // admin kill, void: let it through
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return new Outcome(false, amount);
        }
        if (boss.isBusy()) {
            return new Outcome(true, 0.0F);
        }

        Entity attacker = source.getEntity();
        if (attacker instanceof Player player) {
            boss.noteAttacker(player);
            boss.analyzer().recordPlayerDamage(level.getGameTime(), source.getDirectEntity() == attacker, amount);
        }

        // weak point
        if (boss.core().isExposed()) {
            ServerPlayer coreAttacker = CoreHitDetector.validate(boss, source);
            if (coreAttacker != null && boss.core().registerHit(level, coreAttacker)) {
                return new Outcome(false, 0.5F);   // a flinch, but health is not what the core fight is about
            }
            return new Outcome(false, amount * 0.1F); // body hits while kneeling barely matter
        }

        // Perfect Dodge
        if (attacker != null && boss.skills().dodge().tryDodge(boss, level, attacker)) {
            return new Outcome(true, 0.0F);
        }

        float result = amount;
        // frontal guard in the shield stance
        if (boss.getStance() == BossStance.SHIELD && attacker != null && isInFront(attacker)) {
            result *= 0.5F;
            BossFx.particles(level, ParticleTypes.ENCHANTED_HIT, boss.getX(), boss.getY() + 4.0D, boss.getZ(), 10, 1.0D, 1.5D, 1.0D, 0.1D);
            BossFx.sound(level, boss.position(), ModSounds.BOSS_CORE_HIT.get(), 0.6F, 1.6F);
        }

        // nothing but the core may kill it
        if (!boss.isDefeating() && result >= boss.getHealth()) {
            result = Math.max(0.0F, boss.getHealth() - 1.0F);
            if (result <= 0.0F) {
                return new Outcome(true, 0.0F);
            }
        }
        return new Outcome(false, result);
    }

    private boolean isInFront(Entity attacker) {
        Vec3 to = new Vec3(attacker.getX() - boss.getX(), 0.0D, attacker.getZ() - boss.getZ());
        if (to.lengthSqr() < 1.0E-4D) {
            return true;
        }
        return to.normalize().dot(BossAttackController.forward(boss)) > 0.3D;
    }
}
