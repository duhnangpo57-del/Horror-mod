package com.observer.boss;

import com.observer.config.BossConfig;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.phys.Vec3;

/** All boss particles and sounds go through here so they respect the config limits. */
public final class BossFx {
    private static final int MAX_PARTICLES_PER_CALL = 80;

    private BossFx() {
    }

    public static void particles(ServerLevel level, ParticleOptions type, double x, double y, double z,
                                 int count, double dx, double dy, double dz, double speed) {
        double scale = BossConfig.PARTICLE_SCALE.get();
        if (scale <= 0.0D || count <= 0) {
            return;
        }
        int n = Math.max(1, Math.min(MAX_PARTICLES_PER_CALL, (int) Math.round(count * scale)));
        level.sendParticles(type, x, y, z, n, dx, dy, dz, speed);
    }

    public static void ring(ServerLevel level, ParticleOptions type, Vec3 center, double radius, int points) {
        double scale = BossConfig.PARTICLE_SCALE.get();
        if (scale <= 0.0D) {
            return;
        }
        int n = Math.max(3, Math.min(MAX_PARTICLES_PER_CALL, (int) Math.round(points * scale)));
        for (int i = 0; i < n; i++) {
            double angle = Math.PI * 2.0D * i / n;
            level.sendParticles(type, center.x + Math.cos(angle) * radius, center.y + 0.15D,
                    center.z + Math.sin(angle) * radius, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        }
    }

    public static void sound(ServerLevel level, Vec3 pos, SoundEvent sound, float volume, float pitch) {
        float v = (float) (volume * BossConfig.SOUND_VOLUME.get());
        if (v <= 0.0F) {
            return;
        }
        level.playSound(null, pos.x, pos.y, pos.z, sound, SoundSource.HOSTILE, v, pitch);
    }

    /** Lightning that looks real but sets nothing on fire and breaks nothing. */
    public static void lightning(ServerLevel level, Vec3 pos) {
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt != null) {
            bolt.moveTo(pos);
            bolt.setVisualOnly(true);
            level.addFreshEntity(bolt);
        }
    }
}
