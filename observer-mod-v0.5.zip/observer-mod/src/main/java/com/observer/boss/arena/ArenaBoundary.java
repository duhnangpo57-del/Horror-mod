package com.observer.boss.arena;

import com.observer.dimension.ArenaGenerator;
import com.observer.dimension.ModDimensions;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;

/** The only region where boss skills may change blocks. */
public final class ArenaBoundary {
    private ArenaBoundary() {
    }

    public static boolean inDomain(Level level) {
        return level.dimension() == ModDimensions.DOMAIN;
    }

    public static boolean contains(BlockPos pos) {
        return Math.abs(pos.getX()) <= ArenaGenerator.HALF
                && Math.abs(pos.getZ()) <= ArenaGenerator.HALF
                && pos.getY() >= ArenaGenerator.FLOOR_Y
                && pos.getY() <= ArenaGenerator.FLOOR_Y + 30;
    }
}
