package com.observer.boss.phase;

public enum BossPhase {
    IMITATION(1),
    ADAPTATION(2),
    PERFECT_COPY(3),
    ORIGINAL(4);

    private final int number;

    BossPhase(int number) {
        this.number = number;
    }

    public int number() {
        return number;
    }

    public String titleKey() {
        return "boss.observer.phase" + number;
    }

    public static BossPhase byNumber(int n) {
        for (BossPhase p : values()) {
            if (p.number == n) {
                return p;
            }
        }
        return IMITATION;
    }

    /** 100-75% phase 1, 75-50% phase 2, 50-25% phase 3, 25-0% phase 4. */
    public static BossPhase forHealth(float ratio) {
        if (ratio <= 0.25F) {
            return ORIGINAL;
        }
        if (ratio <= 0.50F) {
            return PERFECT_COPY;
        }
        if (ratio <= 0.75F) {
            return ADAPTATION;
        }
        return IMITATION;
    }
}
