package com.observer.boss.arena;

import com.observer.dimension.ModDimensions;
import com.observer.registry.ModEntities;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;

/** Server-wide safety net: restores the arena when no boss is alive (crash, disconnect, despawn). */
public final class ArenaRestoreManager {
    private ArenaRestoreManager() {
    }

    public static void tick(MinecraftServer server) {
        ServerLevel domain = server.getLevel(ModDimensions.DOMAIN);
        if (domain == null || BossFightData.get(server).expiry().isEmpty()) {
            return;
        }
        boolean bossAlive = !domain.getEntities(ModEntities.PERFECT_COPY.get(), e -> e.isAlive()).isEmpty();
        if (bossAlive) {
            ArenaBlockManager.tick(domain);
        } else {
            ArenaBlockManager.restoreAll(domain);
        }
    }
}
