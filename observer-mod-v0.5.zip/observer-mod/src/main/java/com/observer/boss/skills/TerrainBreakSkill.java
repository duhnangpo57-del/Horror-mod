package com.observer.boss.skills;

import com.observer.boss.BossFx;
import com.observer.boss.animation.BossAnimationState;
import com.observer.boss.arena.ArenaBlockManager;
import com.observer.boss.arena.ArenaBoundary;
import com.observer.config.BossConfig;
import com.observer.dimension.ArenaGenerator;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** Marks three circles on the floor, waits, then turns them to magma for a few seconds. Move off the red. */
public final class TerrainBreakSkill extends BossSkill {
    private static final double RADIUS = 3.4D;
    private static final int LIFETIME_TICKS = 140;

    private final List<Vec3> zones = new ArrayList<>();

    public TerrainBreakSkill() {
        super("terrain_break", 360, 40, 10, 15, 0.0D, 40.0D, 2);
    }

    @Override
    protected boolean extraCheck(SkillContext c) {
        return BossConfig.ENABLE_ARENA_BLOCK_SKILLS.get() && ArenaBoundary.inDomain(c.level());
    }

    @Override
    protected void onBegin(SkillContext c) {
        c.boss().getNavigation().stop();
        c.boss().animation().play(BossAnimationState.CAST);
        zones.clear();
        if (c.target() == null) {
            return;
        }
        RandomSource random = c.boss().getRandom();
        zones.add(c.target().position());
        for (int i = 0; i < 2; i++) {
            double angle = random.nextDouble() * Math.PI * 2.0D;
            double distance = 4.0D + random.nextDouble() * 6.0D;
            zones.add(c.target().position().add(Math.cos(angle) * distance, 0.0D, Math.sin(angle) * distance));
        }
    }

    @Override
    protected void onTelegraph(SkillContext c, int t) {
        if (t % 4 == 0) {
            for (Vec3 zone : zones) {
                BossFx.ring(c.level(), ParticleTypes.FLAME, new Vec3(zone.x, ArenaGenerator.FLOOR_Y + 1.0D, zone.z), RADIUS, 20);
            }
        }
    }

    @Override
    protected void onActive(SkillContext c, int t) {
        if (t != 1) {
            return;
        }
        for (Vec3 zone : zones) {
            int cx = (int) Math.floor(zone.x);
            int cz = (int) Math.floor(zone.z);
            int r = (int) Math.ceil(RADIUS);
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (dx * dx + dz * dz <= RADIUS * RADIUS) {
                        ArenaBlockManager.floorTemp(c.level(), new BlockPos(cx + dx, ArenaGenerator.FLOOR_Y, cz + dz),
                                Blocks.MAGMA_BLOCK.defaultBlockState(), LIFETIME_TICKS);
                    }
                }
            }
            BossFx.particles(c.level(), ParticleTypes.LAVA, zone.x, ArenaGenerator.FLOOR_Y + 1.2D, zone.z, 20, 1.5D, 0.3D, 1.5D, 0.0D);
        }
        zones.clear();
    }

    @Override
    protected void onRecovery(SkillContext c, int t) {
        if (t == 1) {
            c.boss().animation().play(BossAnimationState.IDLE);
        }
    }
}
