package com.observer.boss.animation;

/** Every pose the boss model can be in. Synced to clients as an int. */
public enum BossAnimationState {
    IDLE, WALK, RUN, WINDUP, ATTACK, DASH, CAST, KNEEL, ROAR, DEATH;

    private static final BossAnimationState[] VALUES = values();

    public static BossAnimationState byId(int id) {
        return id >= 0 && id < VALUES.length ? VALUES[id] : IDLE;
    }
}
