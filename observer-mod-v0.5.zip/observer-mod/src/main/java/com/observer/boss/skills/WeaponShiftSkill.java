package com.observer.boss.skills;

import com.observer.boss.BossFx;
import com.observer.boss.animation.BossAnimationState;
import com.observer.boss.weakpoint.CoreWeakPoint;
import com.observer.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.phys.Vec3;

/** Changes the boss's stance to counter what the player has actually been doing. Only picks from the four stances. */
public final class WeaponShiftSkill extends BossSkill {
    public WeaponShiftSkill() {
        super("weapon_shift", 400, 20, 2, 10, 0.0D, 70.0D, 2);
    }

    @Override
    protected boolean extraCheck(SkillContext c) {
        return c.boss().brain().suggestedStance() != c.boss().getStance();
    }

    @Override
    protected void onBegin(SkillContext c) {
        c.boss().getNavigation().stop();
        c.boss().animation().play(BossAnimationState.CAST);
        BossFx.sound(c.level(), c.boss().position(), ModSounds.BOSS_DODGE.get(), 1.0F, 1.3F);
    }

    @Override
    protected void onTelegraph(SkillContext c, int t) {
        Vec3 core = CoreWeakPoint.worldPos(c.boss());
        BossFx.particles(c.level(), ParticleTypes.ENCHANT, core.x, core.y, core.z, 8, 1.0D, 1.0D, 1.0D, 0.5D);
    }

    @Override
    protected void onActive(SkillContext c, int t) {
        if (t == 1) {
            c.boss().setStance(c.boss().brain().suggestedStance());
            Vec3 core = CoreWeakPoint.worldPos(c.boss());
            BossFx.particles(c.level(), ParticleTypes.END_ROD, core.x, core.y, core.z, 20, 1.0D, 1.0D, 1.0D, 0.2D);
        }
    }

    @Override
    protected void onRecovery(SkillContext c, int t) {
        if (t == 1) {
            c.boss().animation().play(BossAnimationState.IDLE);
        }
    }
}
