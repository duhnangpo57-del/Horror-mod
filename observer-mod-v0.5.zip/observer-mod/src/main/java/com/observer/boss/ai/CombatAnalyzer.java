package com.observer.boss.ai;

import com.observer.memory.CombatStyle;
import net.minecraft.world.entity.player.Player;

import java.util.ArrayDeque;

/** Turns what the player has actually done (this fight, plus what the Observer remembers) into a few numbers. */
public final class CombatAnalyzer {
    public record Readout(double meleeBias, double rangedBias, double shieldBias, double mobility, double averageRange) {
        public static final Readout NEUTRAL = new Readout(0.5D, 0.5D, 0.0D, 0.3D, 8.0D);
    }

    private record Sample(long tick, boolean melee, float amount) {
    }

    private static final long WINDOW_TICKS = 1200L;

    private final ArrayDeque<Sample> samples = new ArrayDeque<>();
    private double observations;
    private double blocking;
    private double sprinting;
    private double rangeSum;

    public void recordPlayerDamage(long tick, boolean melee, float amount) {
        samples.addLast(new Sample(tick, melee, amount));
        while (samples.size() > 64) {
            samples.removeFirst();
        }
    }

    public void samplePlayer(Player player, double distance) {
        observations++;
        if (player.isBlocking()) {
            blocking++;
        }
        if (player.isSprinting()) {
            sprinting++;
        }
        rangeSum += distance;
        if (observations > 400.0D) { // keep it recent: halve everything
            observations *= 0.5D;
            blocking *= 0.5D;
            sprinting *= 0.5D;
            rangeSum *= 0.5D;
        }
    }

    public Readout read(long now, CombatStyle memory) {
        double melee = 0.0D;
        double ranged = 0.0D;
        for (Sample s : samples) {
            if (now - s.tick() <= WINDOW_TICKS) {
                if (s.melee()) {
                    melee += s.amount();
                } else {
                    ranged += s.amount();
                }
            }
        }
        double liveTotal = melee + ranged;
        double memoryMelee = 1.0D - memory.rangedRatio();
        double liveMelee = liveTotal > 0.0D ? melee / liveTotal : memoryMelee;
        double w = Math.min(1.0D, liveTotal / 30.0D);
        double meleeBias = memoryMelee * (1.0D - w) + liveMelee * w;

        double wo = Math.min(1.0D, observations / 60.0D);
        double liveShield = observations > 0.0D ? blocking / observations : 0.0D;
        double liveSprint = observations > 0.0D ? sprinting / observations : 0.0D;
        double shield = memory.shieldRate() * (1.0D - wo) + liveShield * wo;
        double mobility = memory.sprintRatio() * (1.0D - wo) + liveSprint * wo;
        double range = observations > 0.0D ? rangeSum / observations : 8.0D;
        return new Readout(meleeBias, 1.0D - meleeBias, shield, mobility, range);
    }
}
