package com.observer.boss.skills;

import com.observer.boss.BossFx;
import com.observer.boss.animation.BossAnimationState;
import com.observer.boss.combat.BossAttackController;
import com.observer.boss.entity.PerfectCopyEntity;
import com.observer.boss.weakpoint.CoreWeakPoint;
import com.observer.config.BossConfig;
import com.observer.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Charges the core (rings close in), then sends an expanding ring across the floor. Jump it, or stand outside it. */
public final class VoidPulseSkill extends BossSkill {
    private static final double START_RADIUS = 3.0D;
    private static final double SPEED = 0.8D;
    private static final double BAND = 1.3D;

    private final Set<UUID> struck = new HashSet<>();

    public VoidPulseSkill() {
        super("void_pulse", 220, 40, 26, 20, 0.0D, 22.0D, 2);
    }

    @Override
    protected void onBegin(SkillContext c) {
        struck.clear();
        c.boss().getNavigation().stop();
        c.boss().animation().play(BossAnimationState.CAST);
        BossFx.sound(c.level(), c.boss().position(), ModSounds.BOSS_PULSE.get(), 0.9F, 0.6F);
    }

    @Override
    protected void onTelegraph(SkillContext c, int t) {
        PerfectCopyEntity boss = c.boss();
        Vec3 core = CoreWeakPoint.worldPos(boss);
        BossFx.particles(c.level(), ParticleTypes.END_ROD, core.x, core.y, core.z, 3, 0.6D, 0.6D, 0.6D, 0.02D);
        if (t % 4 == 0) {
            double radius = 12.0D - (12.0D - START_RADIUS) * t / 40.0D;
            BossFx.ring(c.level(), ParticleTypes.PORTAL, boss.position(), radius, 24);
        }
    }

    @Override
    protected void onActive(SkillContext c, int t) {
        PerfectCopyEntity boss = c.boss();
        double radius = START_RADIUS + t * SPEED;
        if (t == 1) {
            BossFx.sound(c.level(), boss.position(), ModSounds.BOSS_PULSE.get(), 1.6F, 0.5F);
        }
        BossFx.ring(c.level(), ParticleTypes.SQUID_INK, boss.position(), radius, 36);
        BossFx.ring(c.level(), ParticleTypes.DRAGON_BREATH, boss.position(), radius - 0.4D, 24);

        for (Player p : BossAttackController.playersInRange(boss, c.level(), radius + BAND)) {
            double dx = p.getX() - boss.getX();
            double dz = p.getZ() - boss.getZ();
            double d = Math.sqrt(dx * dx + dz * dz);
            if (Math.abs(d - radius) <= BAND && p.onGround() && struck.add(p.getUUID())) {
                BossAttackController.damage(boss, p, BossConfig.scaledDamage(BossConfig.PULSE_DAMAGE));
                BossAttackController.knock(boss, p, 1.0D, 0.55D);
            }
        }
    }

    @Override
    protected void onRecovery(SkillContext c, int t) {
        if (t == 1) {
            c.boss().animation().play(BossAnimationState.IDLE);
        }
    }
}
