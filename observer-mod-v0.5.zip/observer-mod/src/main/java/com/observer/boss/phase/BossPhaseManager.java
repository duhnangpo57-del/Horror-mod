package com.observer.boss.phase;

import com.observer.boss.entity.PerfectCopyEntity;
import net.minecraft.server.level.ServerLevel;

/** Moves the boss through its four phases as health drops, one phase at a time. */
public final class BossPhaseManager {
    private final PerfectCopyEntity boss;
    private final PhaseTransitionController transition;
    private BossPhase phase = BossPhase.IMITATION;

    public BossPhaseManager(PerfectCopyEntity boss) {
        this.boss = boss;
        this.transition = new PhaseTransitionController(boss);
    }

    public BossPhase current() {
        return phase;
    }

    public boolean isTransitioning() {
        return transition.active();
    }

    public void restore(int number) {
        phase = BossPhase.byNumber(number);
    }

    public void tick(ServerLevel level) {
        if (transition.active()) {
            transition.tick(level);
            return;
        }
        BossPhase wanted = BossPhase.forHealth(boss.getHealth() / boss.getMaxHealth());
        if (wanted.number() > phase.number()) {
            phase = BossPhase.byNumber(phase.number() + 1);
            boss.onPhaseChanged(phase);
            transition.begin(level, phase);
        }
    }
}
