package com.observer.boss.weakpoint;

import com.observer.boss.entity.PerfectCopyEntity;
import net.minecraft.world.phys.Vec3;

/** Where the chest core is in the world. Separate from the body hitbox on purpose. */
public final class CoreWeakPoint {
    /** Radius of the sphere (as a box) that counts as the core. */
    public static final double RADIUS = 1.1D;

    private CoreWeakPoint() {
    }

    public static Vec3 worldPos(PerfectCopyEntity boss) {
        double yaw = Math.toRadians(boss.yBodyRot);
        Vec3 forward = new Vec3(-Math.sin(yaw), 0.0D, Math.cos(yaw));
        boolean kneeling = boss.isKneeling();
        double height = kneeling ? 3.9D : 7.0D;
        double out = kneeling ? 0.9D : 1.0D;
        return boss.position().add(forward.scale(out)).add(0.0D, height, 0.0D);
    }
}
