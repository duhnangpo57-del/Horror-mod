package com.observer.boss.skills;

import com.observer.boss.entity.PerfectCopyEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;

import javax.annotation.Nullable;

public record SkillContext(PerfectCopyEntity boss, ServerLevel level, @Nullable LivingEntity target, double distance) {
}
