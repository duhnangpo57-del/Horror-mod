package com.observer.boss.skills;

import com.observer.boss.BossFx;
import com.observer.boss.animation.BossAnimationState;
import com.observer.boss.combat.BossAttackController;
import com.observer.boss.entity.PerfectCopyCloneEntity;
import com.observer.boss.entity.PerfectCopyEntity;
import com.observer.config.BossConfig;
import com.observer.registry.ModEntities;
import com.observer.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

/** Calls up to two clones. The cap is enforced by the boss, so they can never pile up. */
public final class MirrorCloneSkill extends BossSkill {
    public MirrorCloneSkill() {
        super("mirror_clone", 600, 30, 10, 20, 0.0D, 45.0D, 3);
    }

    @Override
    protected boolean extraCheck(SkillContext c) {
        return c.boss().liveClones() < BossConfig.CLONE_COUNT.get();
    }

    @Override
    protected void onBegin(SkillContext c) {
        c.boss().getNavigation().stop();
        c.boss().animation().play(BossAnimationState.CAST);
        BossFx.sound(c.level(), c.boss().position(), ModSounds.BOSS_CLONE.get(), 1.4F, 0.8F);
    }

    @Override
    protected void onTelegraph(SkillContext c, int t) {
        if (t % 4 == 0) {
            BossFx.ring(c.level(), ParticleTypes.PORTAL, c.boss().position(), 6.0D, 20);
        }
    }

    @Override
    protected void onActive(SkillContext c, int t) {
        if (t != 1) {
            return;
        }
        PerfectCopyEntity boss = c.boss();
        ServerLevel level = c.level();
        Vec3 forward = BossAttackController.forward(boss);
        Vec3 side = new Vec3(-forward.z, 0.0D, forward.x);
        int room = BossConfig.CLONE_COUNT.get() - boss.liveClones();
        for (int i = 0; i < Math.min(2, room); i++) {
            double sign = i == 0 ? 1.0D : -1.0D;
            Vec3 spot = boss.position().add(side.scale(6.0D * sign)).add(forward.scale(3.0D));
            PerfectCopyCloneEntity clone = ModEntities.PERFECT_COPY_CLONE.get().create(level);
            if (clone == null) {
                continue;
            }
            clone.moveTo(spot.x, boss.getY(), spot.z, boss.getYRot(), 0.0F);
            if (!level.noCollision(clone)) {
                clone.moveTo(spot.x, boss.getY() + 1.0D, spot.z, boss.getYRot(), 0.0F);
                if (!level.noCollision(clone)) {
                    continue;
                }
            }
            clone.setOwnerBoss(boss);
            level.addFreshEntity(clone);
            boss.registerClone(clone);
            BossFx.particles(level, ParticleTypes.REVERSE_PORTAL, spot.x, boss.getY() + 1.2D, spot.z, 30, 0.5D, 1.0D, 0.5D, 0.1D);
        }
    }

    @Override
    protected void onRecovery(SkillContext c, int t) {
        if (t == 1) {
            c.boss().animation().play(BossAnimationState.IDLE);
        }
    }
}
