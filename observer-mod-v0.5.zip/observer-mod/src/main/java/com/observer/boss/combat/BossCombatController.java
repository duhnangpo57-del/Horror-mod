package com.observer.boss.combat;

import com.observer.boss.animation.BossAnimationState;
import com.observer.boss.entity.PerfectCopyEntity;
import com.observer.boss.skills.BossStance;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.phys.Vec3;

/** Walking, running and turning. Keeps the boss at a distance that suits its current stance. */
public final class BossCombatController {
    private BossCombatController() {
    }

    public static void face(PerfectCopyEntity boss, Vec3 point, float maxTurnDegrees) {
        double dx = point.x - boss.getX();
        double dz = point.z - boss.getZ();
        if (dx * dx + dz * dz < 1.0E-4D) {
            return;
        }
        float yaw = (float) (Mth.atan2(dz, dx) * (180.0D / Math.PI)) - 90.0F;
        float turned = Mth.approachDegrees(boss.getYRot(), yaw, maxTurnDegrees);
        boss.setYRot(turned);
        boss.yBodyRot = turned;
        boss.yHeadRot = turned;
    }

    public static double preferredDistance(BossStance stance) {
        return switch (stance) {
            case BLADE -> 5.0D;
            case BOW -> 15.0D;
            case SHIELD -> 6.0D;
            case CONTROL -> 11.0D;
        };
    }

    public static void move(PerfectCopyEntity boss, LivingEntity target, double distance, BossStance stance) {
        face(boss, target.position(), 12.0F);
        PathNavigation nav = boss.getNavigation();
        double preferred = preferredDistance(stance);
        boolean run = distance > 16.0D;

        if (distance > preferred + 1.0D) {
            nav.moveTo(target, run ? 1.35D : 1.0D);
            boss.animation().locomotion(run);
        } else if (distance < preferred - 3.0D && stance != BossStance.BLADE) {
            Vec3 away = DefaultRandomPos.getPosAway(boss, 10, 4, target.position());
            if (away != null) {
                nav.moveTo(away.x, away.y, away.z, 1.0D);
                boss.animation().locomotion(false);
            }
        } else {
            nav.stop();
            boss.animation().play(BossAnimationState.IDLE);
        }
    }
}
