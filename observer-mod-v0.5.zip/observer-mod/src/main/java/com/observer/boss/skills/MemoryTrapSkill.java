package com.observer.boss.skills;

import com.observer.boss.BossFx;
import com.observer.boss.animation.BossAnimationState;
import com.observer.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * Draws three warning circles. After the warning each one slows whoever stands in it for five seconds.
 * Slowness only, never a root, and only after the warning, so there is always time to step out.
 */
public final class MemoryTrapSkill extends BossSkill {
    public static final double RADIUS = 2.8D;
    private static final int TRAP_LIFETIME = 100;

    private final List<Vec3> centers = new ArrayList<>();

    public MemoryTrapSkill() {
        super("memory_trap", 300, 30, 10, 15, 0.0D, 40.0D, 3);
    }

    @Override
    protected void onBegin(SkillContext c) {
        c.boss().getNavigation().stop();
        c.boss().animation().play(BossAnimationState.CAST);
        BossFx.sound(c.level(), c.boss().position(), ModSounds.BOSS_TRAP.get(), 1.2F, 0.8F);
        centers.clear();
        if (c.target() == null) {
            return;
        }
        RandomSource random = c.boss().getRandom();
        centers.add(c.target().position());
        for (int i = 0; i < 2; i++) {
            double angle = random.nextDouble() * Math.PI * 2.0D;
            double distance = 4.5D + random.nextDouble() * 5.0D;
            centers.add(c.target().position().add(Math.cos(angle) * distance, 0.0D, Math.sin(angle) * distance));
        }
    }

    @Override
    protected void onTelegraph(SkillContext c, int t) {
        if (t % 4 == 0) {
            for (Vec3 center : centers) {
                BossFx.ring(c.level(), ParticleTypes.SOUL_FIRE_FLAME, center, RADIUS, 16);
            }
        }
    }

    @Override
    protected void onActive(SkillContext c, int t) {
        if (t != 1) {
            return;
        }
        long expire = c.boss().tickCount + TRAP_LIFETIME;
        for (Vec3 center : centers) {
            c.boss().addTrap(center, expire);
            BossFx.particles(c.level(), ParticleTypes.SOUL, center.x, center.y + 0.3D, center.z, 15, 1.2D, 0.2D, 1.2D, 0.02D);
        }
        centers.clear();
    }

    @Override
    protected void onRecovery(SkillContext c, int t) {
        if (t == 1) {
            c.boss().animation().play(BossAnimationState.IDLE);
        }
    }
}
