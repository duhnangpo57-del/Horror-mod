package com.observer.boss.skills;

import com.observer.boss.BossFx;
import com.observer.boss.animation.BossAnimationState;
import com.observer.boss.entity.PerfectCopyEntity;
import com.observer.config.BossConfig;
import com.observer.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Reactive. Sometimes sidesteps a player's attack. A long cooldown, a chance roll, and no dodging while
 * the core is open mean the player always gets hits in.
 */
public final class PerfectDodgeSkill extends BossSkill {
    private static final float CHANCE = 0.4F;

    public PerfectDodgeSkill() {
        super("perfect_dodge", 240, 0, 0, 0, 0.0D, 100.0D, 3);
    }

    @Override
    public boolean isReactive() {
        return true;
    }

    public boolean tryDodge(PerfectCopyEntity boss, ServerLevel level, Entity attacker) {
        if (!BossConfig.ENABLE_DODGE.get() || boss.getPhaseNumber() < 3 || boss.isKneeling()
                || boss.skills().isRunning() || !ready(boss)) {
            return false;
        }
        if (boss.getRandom().nextFloat() > CHANCE) {
            return false;
        }
        Vec3 away = new Vec3(boss.getX() - attacker.getX(), 0.0D, boss.getZ() - attacker.getZ());
        Vec3 flat = away.lengthSqr() < 1.0E-4D ? new Vec3(0.0D, 0.0D, 1.0D) : away.normalize();
        double sign = boss.getRandom().nextBoolean() ? 6.0D : -6.0D;
        Vec3 step = new Vec3(-flat.z * sign, 0.0D, flat.x * sign);
        AABB moved = boss.getBoundingBox().move(step.x, 0.0D, step.z);
        if (!level.noCollision(boss, moved)) {
            return false;
        }
        BossFx.particles(level, ParticleTypes.SQUID_INK, boss.getX(), boss.getY() + 3.0D, boss.getZ(), 25, 1.0D, 2.5D, 1.0D, 0.03D);
        boss.moveTo(boss.getX() + step.x, boss.getY(), boss.getZ() + step.z, boss.getYRot(), 0.0F);
        BossFx.particles(level, ParticleTypes.REVERSE_PORTAL, boss.getX(), boss.getY() + 3.0D, boss.getZ(), 25, 1.0D, 2.5D, 1.0D, 0.08D);
        BossFx.sound(level, boss.position(), ModSounds.BOSS_DODGE.get(), 1.2F, 0.9F);
        boss.animation().play(BossAnimationState.DASH);
        startCooldown(boss);
        return true;
    }
}
