package com.observer.boss.entity;

import com.observer.boss.BossFx;
import com.observer.boss.ai.CombatAnalyzer;
import com.observer.boss.ai.PerfectCopyBrain;
import com.observer.boss.animation.BossAnimated;
import com.observer.boss.animation.BossAnimationController;
import com.observer.boss.animation.BossAnimationState;
import com.observer.boss.arena.BossArenaController;
import com.observer.boss.combat.BossDamageHandler;
import com.observer.boss.phase.BossPhase;
import com.observer.boss.phase.BossPhaseManager;
import com.observer.boss.skills.BossSkillManager;
import com.observer.boss.skills.BossStance;
import com.observer.boss.skills.MemoryTrapSkill;
import com.observer.boss.weakpoint.CoreExposureController;
import com.observer.boss.weakpoint.CoreWeakPoint;
import com.observer.config.BossConfig;
import com.observer.memory.CombatStyle;
import com.observer.memory.PlayerProfile;
import com.observer.registry.ModItems;
import com.observer.registry.ModSounds;
import com.observer.story.Dialogue;
import com.observer.story.StoryManager;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * THE PERFECT COPY. A ten-block-tall humanoid made of black glass and purple light.
 * The model is ten blocks tall, but the hitbox is deliberately smaller (and shrinks again when it kneels).
 * All logic is server-side; clients only receive synced fields and the usual particles and sounds.
 */
public class PerfectCopyEntity extends Monster implements BossAnimated {
    private static final EntityDataAccessor<Optional<UUID>> DATA_COPY_OF =
            SynchedEntityData.defineId(PerfectCopyEntity.class, EntityDataSerializers.OPTIONAL_UUID);
    private static final EntityDataAccessor<Integer> DATA_ANIM =
            SynchedEntityData.defineId(PerfectCopyEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_PHASE =
            SynchedEntityData.defineId(PerfectCopyEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_CORE_STATE =
            SynchedEntityData.defineId(PerfectCopyEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_CORE_HITS =
            SynchedEntityData.defineId(PerfectCopyEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_STANCE =
            SynchedEntityData.defineId(PerfectCopyEntity.class, EntityDataSerializers.INT);

    private static final EntityDimensions STANDING = EntityDimensions.scalable(2.2F, 6.0F);
    private static final EntityDimensions KNEELING = EntityDimensions.scalable(2.4F, 4.8F);
    private static final UUID SPEED_ID = UUID.fromString("7c1a5f20-3b1d-4d7e-8a60-1a2b3c4d5e61");
    private static final int INTRO_TICKS = 100;
    private static final int DEFEAT_TICKS = 140;

    private record Trap(Vec3 center, long expireTick) {
    }

    private final ServerBossEvent bossBar = new ServerBossEvent(
            Component.translatable("entity.observer.perfect_copy"),
            BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.NOTCHED_10);
    private final BossAnimationController animation = new BossAnimationController(this);
    private final BossPhaseManager phases = new BossPhaseManager(this);
    private final CoreExposureController core = new CoreExposureController(this);
    private final BossDamageHandler damageHandler = new BossDamageHandler(this);
    private final BossSkillManager skills = new BossSkillManager(this);
    private final CombatAnalyzer analyzer = new CombatAnalyzer();
    private final PerfectCopyBrain brain = new PerfectCopyBrain(this);
    private final BossArenaController arena = new BossArenaController(this);
    private final List<Trap> traps = new ArrayList<>();
    private final List<PerfectCopyCloneEntity> clones = new ArrayList<>();
    private final Map<UUID, Integer> recentAttackers = new HashMap<>();

    private CombatStyle style = CombatStyle.DEFAULT;
    private boolean introPending = true;
    private int introTicks;
    private int defeatTicks;
    private boolean defeating;
    private boolean defeatDone;
    private int animStartClient;

    public PerfectCopyEntity(EntityType<? extends PerfectCopyEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
        this.xpReward = 300;
        bossBar.setPlayBossMusic(true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 1000.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.30D)
                .add(Attributes.ATTACK_DAMAGE, 8.0D)
                .add(Attributes.FOLLOW_RANGE, 70.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.ARMOR, 6.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_COPY_OF, Optional.empty());
        this.entityData.define(DATA_ANIM, 0);
        this.entityData.define(DATA_PHASE, 1);
        this.entityData.define(DATA_CORE_STATE, 0);
        this.entityData.define(DATA_CORE_HITS, 0);
        this.entityData.define(DATA_STANCE, 0);
    }

    @Override
    protected void registerGoals() {
        // No vanilla goals: PerfectCopyBrain drives everything.
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        if (DATA_ANIM.equals(key)) {
            animStartClient = this.tickCount;
        }
        super.onSyncedDataUpdated(key);
    }

    // ------------------------------------------------------------------ accessors

    public BossAnimationController animation() {
        return animation;
    }

    public BossSkillManager skills() {
        return skills;
    }

    public CoreExposureController core() {
        return core;
    }

    public CombatAnalyzer analyzer() {
        return analyzer;
    }

    public PerfectCopyBrain brain() {
        return brain;
    }

    public CombatStyle getStyle() {
        return style;
    }

    public BossStance getStance() {
        return BossStance.byId(this.entityData.get(DATA_STANCE));
    }

    public void setStance(BossStance stance) {
        this.entityData.set(DATA_STANCE, stance.ordinal());
    }

    @Nullable
    public UUID getCopyOf() {
        return this.entityData.get(DATA_COPY_OF).orElse(null);
    }

    @Override
    public BossAnimationState getAnimState() {
        return BossAnimationState.byId(this.entityData.get(DATA_ANIM));
    }

    public void setAnimState(BossAnimationState state) {
        this.entityData.set(DATA_ANIM, state.ordinal());
    }

    @Override
    public float getAnimTime(float ageInTicks) {
        return ageInTicks - animStartClient;
    }

    @Override
    public boolean isKneeling() {
        return this.getPose() == Pose.CROUCHING;
    }

    public void setKneeling(boolean kneeling) {
        this.setPose(kneeling ? Pose.CROUCHING : Pose.STANDING);
    }

    @Override
    public int getPhaseNumber() {
        return this.entityData.get(DATA_PHASE);
    }

    public int getCoreHits() {
        return this.entityData.get(DATA_CORE_HITS);
    }

    public void setCoreHits(int hits) {
        this.entityData.set(DATA_CORE_HITS, hits);
    }

    public int getCoreState() {
        return this.entityData.get(DATA_CORE_STATE);
    }

    public void setCoreState(int state) {
        this.entityData.set(DATA_CORE_STATE, state);
    }

    public boolean isDefeating() {
        return defeating;
    }

    /** True while rising, roaring between phases, or collapsing: the boss is untouchable and idle. */
    public boolean isBusy() {
        return introTicks > 0 || defeating || phases.isTransitioning();
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        return pose == Pose.CROUCHING ? KNEELING : STANDING;
    }

    // ------------------------------------------------------------------ setup

    /** Remembers whose fighting style to imitate. */
    public void copyFrom(ServerPlayer player, @Nullable PlayerProfile profile) {
        this.entityData.set(DATA_COPY_OF, Optional.of(player.getUUID()));
        if (profile != null) {
            this.style = profile.combatStyle();
        }
    }

    /** Health scales with the number of players taking part. */
    public void applyScaling(int players) {
        double extra = 1.0D + BossConfig.HEALTH_PER_EXTRA_PLAYER.get() * Math.max(0, players - 1);
        AttributeInstance health = getAttribute(Attributes.MAX_HEALTH);
        if (health != null) {
            health.setBaseValue(BossConfig.MAX_HEALTH.get() * BossConfig.DIFFICULTY.get() * extra);
        }
        this.setHealth(this.getMaxHealth());
    }

    // ------------------------------------------------------------------ bookkeeping used by skills

    public void noteAttacker(Player player) {
        recentAttackers.put(player.getUUID(), this.tickCount);
    }

    public boolean isRecentAttacker(Player player) {
        Integer at = recentAttackers.get(player.getUUID());
        return at != null && this.tickCount - at < 200;
    }

    public void registerClone(PerfectCopyCloneEntity clone) {
        clones.add(clone);
    }

    public int liveClones() {
        clones.removeIf(c -> !c.isAlive());
        return clones.size();
    }

    private void discardClones() {
        for (PerfectCopyCloneEntity clone : clones) {
            if (clone.isAlive()) {
                clone.discard();
            }
        }
        clones.clear();
    }

    public void addTrap(Vec3 center, long expireTick) {
        if (traps.size() < 9) {
            traps.add(new Trap(center, expireTick));
        }
    }

    public void shootSoulArrow(LivingEntity target, double yawOffsetDegrees) {
        Arrow arrow = new Arrow(this.level(), this);
        arrow.setPos(this.getX(), this.getY() + 5.0D, this.getZ());
        Vec3 dir = new Vec3(target.getX() - arrow.getX(), target.getY(0.5D) - arrow.getY(), target.getZ() - arrow.getZ())
                .yRot((float) Math.toRadians(yawOffsetDegrees));
        arrow.setBaseDamage(BossConfig.scaledDamage(BossConfig.NORMAL_DAMAGE) / 3.5D);
        arrow.pickup = AbstractArrow.Pickup.DISALLOWED;
        arrow.setSecondsOnFire(3);
        arrow.shoot(dir.x, dir.y, dir.z, 2.0F, 1.5F);
        this.level().addFreshEntity(arrow);
        if (this.level() instanceof ServerLevel level) {
            BossFx.sound(level, this.position(), ModSounds.BOSS_ATTACK.get(), 1.0F, 1.2F);
        }
    }

    // ------------------------------------------------------------------ phase hooks

    public void onPhaseChanged(BossPhase phase) {
        this.entityData.set(DATA_PHASE, phase.number());
        AttributeInstance speed = getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) {
            speed.removeModifier(SPEED_ID);
            if (phase.number() > 1) {
                speed.addTransientModifier(new AttributeModifier(SPEED_ID, "observer_phase_speed",
                        0.10D * (phase.number() - 1), AttributeModifier.Operation.MULTIPLY_BASE));
            }
        }
        bossBar.setColor(switch (phase) {
            case IMITATION -> BossEvent.BossBarColor.PURPLE;
            case ADAPTATION -> BossEvent.BossBarColor.PINK;
            case PERFECT_COPY -> BossEvent.BossBarColor.RED;
            case ORIGINAL -> BossEvent.BossBarColor.WHITE;
        });
        bossBar.setCreateWorldFog(phase.number() >= 3);
        bossBar.setDarkenScreen(phase.number() >= 4);
        if (phase == BossPhase.ORIGINAL) {
            core.onPhase4Start();
        }
        refreshHud();
    }

    public void onTransitionFinished(ServerLevel level) {
        refreshHud();
    }

    public void refreshHud() {
        Component name = Component.translatable("entity.observer.perfect_copy");
        if (core.isExposed()) {
            bossBar.setName(Component.translatable("boss.observer.hud_core", name, getPhaseNumber(),
                    core.hits(), BossConfig.CORE_HITS_REQUIRED.get()));
        } else if (core.isDestabilized()) {
            bossBar.setName(Component.translatable("boss.observer.core_destabilized"));
        } else {
            bossBar.setName(Component.translatable("boss.observer.hud", name, getPhaseNumber()));
        }
    }

    // ------------------------------------------------------------------ damage

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (this.level().isClientSide) {
            return super.hurt(source, amount);
        }
        BossDamageHandler.Outcome outcome = damageHandler.process(source, amount);
        if (outcome.cancel()) {
            return false;
        }
        return super.hurt(source, outcome.amount());
    }

    // ------------------------------------------------------------------ tick

    @Override
    public void tick() {
        super.tick();
        if (!(this.level() instanceof ServerLevel level)) {
            clientTick();
            return;
        }
        if (introPending) {
            introPending = false;
            startIntro();
        }
        if (introTicks > 0) {
            introTicks--;
            tickIntro(level);
            return;
        }
        if (defeating) {
            tickDefeat(level);
            return;
        }

        bossBar.setProgress(Math.max(0.0F, Math.min(1.0F, this.getHealth() / this.getMaxHealth())));
        phases.tick(level);
        core.tick(level);
        if (!phases.isTransitioning()) {
            brain.tick(level);
        }
        if (this.tickCount % 5 == 0) {
            tickTraps(level);
        }
        arena.tick(level);
        ambient(level);

        if (this.tickCount % 100 == 0 && level.getNearestPlayer(this, 100.0D) == null) {
            this.discard(); // nobody left to fight
        }
    }

    private void clientTick() {
        if (this.tickCount % 3 != 0) {
            return;
        }
        Vec3 coreWorld = CoreWeakPoint.worldPos(this);
        this.level().addParticle(ParticleTypes.PORTAL, coreWorld.x + (this.random.nextDouble() - 0.5D) * 2.0D,
                coreWorld.y + (this.random.nextDouble() - 0.5D) * 2.0D, coreWorld.z + (this.random.nextDouble() - 0.5D) * 2.0D,
                0.0D, 0.05D, 0.0D);
        if (getPhaseNumber() >= 2 && this.tickCount % 6 == 0) {
            this.level().addParticle(ParticleTypes.SMOKE, this.getX() + (this.random.nextDouble() - 0.5D) * 2.4D,
                    this.getY() + this.random.nextDouble() * 8.0D, this.getZ() + (this.random.nextDouble() - 0.5D) * 2.4D,
                    0.0D, 0.02D, 0.0D);
        }
    }

    private void ambient(ServerLevel level) {
        if (this.tickCount % 200 == 0) {
            BossFx.sound(level, this.position(), ModSounds.BOSS_AMBIENT.get(), 0.7F, 0.8F);
        }
        if (this.tickCount % 320 == 100 && !skills.isRunning()) {
            BossFx.sound(level, this.position(), ModSounds.BOSS_IDLE.get(), 0.9F, 0.7F);
        }
    }

    private void tickTraps(ServerLevel level) {
        if (traps.isEmpty()) {
            return;
        }
        traps.removeIf(t -> this.tickCount >= t.expireTick());
        for (Trap trap : traps) {
            if (this.tickCount % 10 == 0) {
                BossFx.ring(level, ParticleTypes.SOUL_FIRE_FLAME, trap.center(), MemoryTrapSkill.RADIUS, 14);
            }
            for (Player p : level.players()) {
                double dx = p.getX() - trap.center().x;
                double dz = p.getZ() - trap.center().z;
                if (p.isAlive() && !p.isSpectator() && dx * dx + dz * dz <= MemoryTrapSkill.RADIUS * MemoryTrapSkill.RADIUS
                        && Math.abs(p.getY() - trap.center().y) < 3.0D) {
                    p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 2, false, true));
                }
            }
        }
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        if (!isBusy()) {
            this.playSound(ModSounds.BOSS_STEP.get(), (float) (1.2D * BossConfig.SOUND_VOLUME.get()), 0.6F);
        }
    }

    // ------------------------------------------------------------------ intro

    private void startIntro() {
        introTicks = INTRO_TICKS;
        this.setInvulnerable(true);
        animation.play(BossAnimationState.ROAR);
        this.setStance(BossStance.BLADE);
        bossBar.setProgress(0.0F);
        refreshHud();
    }

    private void tickIntro(ServerLevel level) {
        bossBar.setProgress(1.0F - introTicks / (float) INTRO_TICKS);
        double angle = this.tickCount * 0.5D;
        double height = (1.0D - introTicks / (double) INTRO_TICKS) * 9.0D;
        for (int i = 0; i < 3; i++) {
            double a = angle + i * Math.PI * 2.0D / 3.0D;
            BossFx.particles(level, ParticleTypes.SOUL_FIRE_FLAME, this.getX() + Math.cos(a) * 3.0D, this.getY() + height,
                    this.getZ() + Math.sin(a) * 3.0D, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        }
        if (introTicks == INTRO_TICKS - 2) {
            BossFx.lightning(level, this.position());
            BossFx.sound(level, this.position(), ModSounds.BOSS_PHASE.get(), 1.8F, 0.7F);
            for (Player p : level.players()) {
                if (p instanceof ServerPlayer sp && sp.distanceToSqr(this) < 100.0D * 100.0D) {
                    Dialogue.title(sp, "boss.observer.title", "boss.observer.subtitle");
                }
            }
        }
        if (introTicks == 0) {
            this.setInvulnerable(false);
            animation.play(BossAnimationState.IDLE);
            BossFx.particles(level, ParticleTypes.EXPLOSION_EMITTER, this.getX(), this.getY() + 2.0D, this.getZ(), 1, 0.0D, 0.0D, 0.0D, 0.0D);
            refreshHud();
        }
    }

    // ------------------------------------------------------------------ defeat

    /** Core destabilised: collapse for a few seconds, then end the fight. Never an instant death. */
    public void startDefeat(ServerLevel level) {
        if (defeating) {
            return;
        }
        defeating = true;
        defeatTicks = DEFEAT_TICKS;
        skills.cancel();
        discardClones();
        this.getNavigation().stop();
        this.setInvulnerable(true);
        this.setKneeling(true);
        animation.play(BossAnimationState.DEATH);
        BossFx.sound(level, this.position(), ModSounds.BOSS_DEFEAT.get(), 1.8F, 0.7F);
    }

    private void tickDefeat(ServerLevel level) {
        defeatTicks--;
        float progress = defeatTicks / (float) DEFEAT_TICKS;
        bossBar.setProgress(Math.max(0.0F, progress));
        Vec3 c = CoreWeakPoint.worldPos(this);
        int fragments = 4 + (int) ((1.0F - progress) * 16.0F);
        BossFx.particles(level, ParticleTypes.SOUL_FIRE_FLAME, this.getX(), this.getY() + 2.5D, this.getZ(), fragments, 1.2D, 2.0D, 1.2D, 0.06D);
        BossFx.particles(level, ParticleTypes.END_ROD, c.x, c.y, c.z, Math.max(1, (int) (progress * 8.0F)), 0.4D, 0.4D, 0.4D, 0.1D);
        if (defeatTicks % 30 == 0) {
            BossFx.particles(level, ParticleTypes.EXPLOSION, this.getX(), this.getY() + 2.0D, this.getZ(), 2, 1.0D, 1.5D, 1.0D, 0.0D);
        }
        if (defeatTicks <= 0) {
            completeDefeat(level);
        }
    }

    private void completeDefeat(ServerLevel level) {
        if (defeatDone) {
            return;
        }
        defeatDone = true;
        BossFx.particles(level, ParticleTypes.EXPLOSION_EMITTER, this.getX(), this.getY() + 3.0D, this.getZ(), 3, 1.5D, 2.0D, 1.5D, 0.0D);
        BossFx.particles(level, ParticleTypes.SOUL, this.getX(), this.getY() + 3.0D, this.getZ(), 80, 1.5D, 3.0D, 1.5D, 0.12D);
        this.spawnAtLocation(new ItemStack(ModItems.MEMORY_SHARD.get()));
        ExperienceOrb.award(level, this.position(), 500);
        arena.onBossRemoved(level);
        StoryManager.onBossDefeated(level);
        this.discard();
    }

    @Override
    public void die(DamageSource source) {
        // Only an admin kill gets here; still finish the encounter properly.
        if (!defeatDone && this.level() instanceof ServerLevel level) {
            defeatDone = true;
            this.spawnAtLocation(new ItemStack(ModItems.MEMORY_SHARD.get()));
            arena.onBossRemoved(level);
            StoryManager.onBossDefeated(level);
        }
        super.die(source);
    }

    @Override
    public void remove(Entity.RemovalReason reason) {
        if (!this.level().isClientSide) {
            bossBar.removeAllPlayers();
            discardClones();
            if (reason.shouldDestroy() && this.level() instanceof ServerLevel level) {
                arena.onBossRemoved(level);
            }
        }
        super.remove(reason);
    }

    // ------------------------------------------------------------------ boss bar visibility

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossBar.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossBar.removePlayer(player);
    }

    // ------------------------------------------------------------------ misc overrides

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    protected boolean shouldDespawnInPeaceful() {
        return false;
    }

    @Override
    public boolean canChangeDimensions() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    // ------------------------------------------------------------------ save data

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        UUID copy = getCopyOf();
        if (copy != null) {
            tag.putUUID("CopyOf", copy);
        }
        tag.putInt("Phase", getPhaseNumber());
        tag.putInt("CoreHits", core.hits());
        tag.putInt("CoreState", core.state());
        tag.putInt("Stance", getStance().ordinal());
        tag.putBoolean("IntroDone", true);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("CopyOf")) {
            this.entityData.set(DATA_COPY_OF, Optional.of(tag.getUUID("CopyOf")));
        }
        if (tag.getBoolean("IntroDone")) {
            introPending = false;
        }
        BossPhase phase = BossPhase.byNumber(Math.max(1, Math.min(4, tag.getInt("Phase"))));
        phases.restore(phase.number());
        onPhaseChanged(phase);
        core.restore(tag.getInt("CoreHits"), tag.getInt("CoreState"));
        setStance(BossStance.byId(tag.getInt("Stance")));
        refreshHud();
    }
}
