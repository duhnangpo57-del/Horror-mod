package com.observer.boss.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.observer.ObserverMod;
import com.observer.boss.animation.BossAnimated;
import com.observer.boss.animation.BossAnimationState;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;

/**
 * Tall, thin, long-armed humanoid with long fingers, a small head, a glowing chest core in a spinning ring,
 * and jointed knees and elbows. Built at 5 blocks and drawn at 2x, which makes it 10 blocks tall.
 * Texture layout: everything except the glowing parts lives in the top half (v < 64); eyes, core and ring
 * bars have their own areas below it so the glow texture can light them without lighting the rest.
 */
public class PerfectCopyModel<T extends LivingEntity & BossAnimated> extends EntityModel<T> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(ObserverMod.MODID, "perfect_copy"), "main");

    private final ModelPart root;
    private final ModelPart hips;
    private final ModelPart torso;
    private final ModelPart head;
    private final ModelPart ring;
    private final ModelPart rThigh;
    private final ModelPart rShin;
    private final ModelPart lThigh;
    private final ModelPart lShin;
    private final ModelPart rArm;
    private final ModelPart rFore;
    private final ModelPart lArm;
    private final ModelPart lFore;

    public PerfectCopyModel(ModelPart root) {
        this.root = root.getChild("root");
        this.hips = this.root.getChild("hips");
        this.torso = hips.getChild("torso");
        this.head = torso.getChild("neck").getChild("head");
        this.ring = torso.getChild("core").getChild("ring");
        this.rThigh = hips.getChild("right_thigh");
        this.rShin = rThigh.getChild("right_shin");
        this.lThigh = hips.getChild("left_thigh");
        this.lShin = lThigh.getChild("left_shin");
        this.rArm = torso.getChild("right_arm");
        this.rFore = rArm.getChild("right_forearm");
        this.lArm = torso.getChild("left_arm");
        this.lFore = lArm.getChild("left_forearm");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot().addOrReplaceChild("root", CubeListBuilder.create(), PartPose.offset(0.0F, 24.0F, 0.0F));

        PartDefinition hips = root.addOrReplaceChild("hips",
                CubeListBuilder.create().texOffs(52, 0).addBox(-6.0F, -3.0F, -4.0F, 12.0F, 6.0F, 8.0F),
                PartPose.offset(0.0F, -36.0F, 0.0F));

        // legs: thigh, knee, shin, foot
        PartDefinition rThigh = hips.addOrReplaceChild("right_thigh",
                CubeListBuilder.create().texOffs(0, 34).addBox(-2.5F, 0.0F, -2.5F, 5.0F, 18.0F, 5.0F),
                PartPose.offset(-4.0F, 3.0F, 0.0F));
        rThigh.addOrReplaceChild("right_shin",
                CubeListBuilder.create().texOffs(22, 34).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 18.0F, 4.0F)
                        .texOffs(40, 34).addBox(-2.5F, 16.0F, -5.0F, 5.0F, 2.0F, 7.0F),
                PartPose.offset(0.0F, 18.0F, 0.0F));
        PartDefinition lThigh = hips.addOrReplaceChild("left_thigh",
                CubeListBuilder.create().texOffs(0, 34).addBox(-2.5F, 0.0F, -2.5F, 5.0F, 18.0F, 5.0F),
                PartPose.offset(4.0F, 3.0F, 0.0F));
        lThigh.addOrReplaceChild("left_shin",
                CubeListBuilder.create().texOffs(22, 34).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 18.0F, 4.0F)
                        .texOffs(40, 34).addBox(-2.5F, 16.0F, -5.0F, 5.0F, 2.0F, 7.0F),
                PartPose.offset(0.0F, 18.0F, 0.0F));

        // torso with spikes along the back
        PartDefinition torso = hips.addOrReplaceChild("torso",
                CubeListBuilder.create().texOffs(0, 0).addBox(-8.0F, -22.0F, -4.5F, 16.0F, 22.0F, 9.0F)
                        .texOffs(52, 16).addBox(-1.0F, -20.0F, 4.5F, 2.0F, 5.0F, 3.0F)
                        .addBox(-1.0F, -14.0F, 4.5F, 2.0F, 5.0F, 3.0F)
                        .addBox(-1.0F, -8.0F, 4.5F, 2.0F, 5.0F, 3.0F),
                PartPose.offset(0.0F, -3.0F, 0.0F));

        // chest core, set into the front, with a ring of bars around it
        PartDefinition core = torso.addOrReplaceChild("core",
                CubeListBuilder.create().texOffs(0, 72).addBox(-3.0F, -3.5F, -3.0F, 6.0F, 7.0F, 3.0F),
                PartPose.offset(0.0F, -12.0F, -4.5F));
        core.addOrReplaceChild("ring",
                CubeListBuilder.create()
                        .texOffs(0, 88).addBox(-6.0F, -6.0F, -1.0F, 12.0F, 1.0F, 2.0F)
                        .addBox(-6.0F, 5.0F, -1.0F, 12.0F, 1.0F, 2.0F)
                        .texOffs(30, 88).addBox(-6.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F)
                        .addBox(5.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F),
                PartPose.offset(0.0F, 0.0F, -3.0F));

        // shoulders
        torso.addOrReplaceChild("right_shoulder",
                CubeListBuilder.create().texOffs(0, 50).addBox(-4.0F, -3.0F, -4.0F, 8.0F, 6.0F, 8.0F),
                PartPose.offset(-11.0F, -20.0F, 0.0F));
        torso.addOrReplaceChild("left_shoulder",
                CubeListBuilder.create().texOffs(0, 50).addBox(-4.0F, -3.0F, -4.0F, 8.0F, 6.0F, 8.0F),
                PartPose.offset(11.0F, -20.0F, 0.0F));

        // arms: upper arm, elbow, forearm, hand with four long fingers
        addArm(torso, "right", -11.0F);
        addArm(torso, "left", 11.0F);

        // neck, small head, horns, glowing eyes
        PartDefinition neck = torso.addOrReplaceChild("neck",
                CubeListBuilder.create().texOffs(96, 0).addBox(-2.0F, -3.0F, -2.0F, 4.0F, 3.0F, 4.0F),
                PartPose.offset(0.0F, -22.0F, 0.0F));
        neck.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(96, 10).addBox(-4.0F, -9.0F, -4.0F, 8.0F, 9.0F, 8.0F)
                        .texOffs(96, 28).addBox(-4.0F, -13.0F, -1.0F, 1.0F, 5.0F, 1.0F)
                        .addBox(3.0F, -13.0F, -1.0F, 1.0F, 5.0F, 1.0F)
                        .texOffs(0, 64).addBox(-3.5F, -6.0F, -4.5F, 3.0F, 1.0F, 1.0F)
                        .addBox(0.5F, -6.0F, -4.5F, 3.0F, 1.0F, 1.0F),
                PartPose.offset(0.0F, -3.0F, 0.0F));

        return LayerDefinition.create(mesh, 128, 128);
    }

    private static void addArm(PartDefinition torso, String side, float x) {
        PartDefinition arm = torso.addOrReplaceChild(side + "_arm",
                CubeListBuilder.create().texOffs(60, 34).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 20.0F, 4.0F),
                PartPose.offset(x, -19.0F, 0.0F));
        PartDefinition fore = arm.addOrReplaceChild(side + "_forearm",
                CubeListBuilder.create().texOffs(80, 34).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 22.0F, 3.0F),
                PartPose.offset(0.0F, 20.0F, 0.0F));
        fore.addOrReplaceChild(side + "_hand",
                CubeListBuilder.create().texOffs(96, 34).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 3.0F, 4.0F)
                        .texOffs(96, 44).addBox(-2.0F, 3.0F, -1.5F, 1.0F, 9.0F, 1.0F)
                        .addBox(-0.75F, 3.0F, -1.5F, 1.0F, 10.0F, 1.0F)
                        .addBox(0.5F, 3.0F, -1.5F, 1.0F, 9.0F, 1.0F)
                        .addBox(1.0F, 3.0F, 0.5F, 1.0F, 7.0F, 1.0F),
                PartPose.offset(0.0F, 22.0F, 0.0F));
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float age, float headYaw, float headPitch) {
        root.getAllParts().forEach(ModelPart::resetPose);
        BossAnimationState state = entity.getAnimState();
        float t = entity.getAnimTime(age);
        boolean kneel = entity.isKneeling() || state == BossAnimationState.KNEEL || state == BossAnimationState.DEATH;
        float deg = (float) Math.PI / 180.0F;

        // walking: slow, heavy stride with bending knees and swinging arms
        float walk = limbSwing * 0.45F;
        float amp = Mth.clamp(limbSwingAmount * 1.3F, 0.0F, 1.0F);
        float run = state == BossAnimationState.RUN ? 1.5F : 1.0F;
        if (!kneel) {
            rThigh.xRot = Mth.cos(walk) * 0.8F * amp * run;
            lThigh.xRot = -Mth.cos(walk) * 0.8F * amp * run;
            rShin.xRot = Math.max(0.0F, -Mth.sin(walk)) * 0.9F * amp;
            lShin.xRot = Math.max(0.0F, Mth.sin(walk)) * 0.9F * amp;
            rArm.xRot = -Mth.cos(walk) * 0.6F * amp * run;
            lArm.xRot = Mth.cos(walk) * 0.6F * amp * run;
            rFore.xRot = -0.15F - Math.max(0.0F, Mth.cos(walk)) * 0.5F * amp;
            lFore.xRot = -0.15F - Math.max(0.0F, -Mth.cos(walk)) * 0.5F * amp;
            torso.yRot = Mth.cos(walk) * 0.1F * amp;
            hips.y -= Math.abs(Mth.sin(walk)) * 1.2F * amp;
            if (state == BossAnimationState.RUN) {
                torso.xRot += 0.3F;
                head.xRot -= 0.2F;
            }
        }

        // idle: breathing and slow arm sway
        float breathe = Mth.sin(age * 0.07F);
        torso.xRot += 0.025F * breathe;
        rArm.zRot += 0.06F + 0.025F * breathe;
        lArm.zRot -= 0.06F + 0.025F * breathe;
        rFore.xRot -= 0.1F + 0.04F * breathe;
        lFore.xRot -= 0.1F + 0.04F * breathe;

        // head follows the target
        head.yRot += Mth.clamp(headYaw, -50.0F, 50.0F) * deg;
        head.xRot += Mth.clamp(headPitch, -25.0F, 25.0F) * deg;

        // the ring around the core spins; faster when charging
        ring.zRot = age * (state == BossAnimationState.CAST || kneel ? 0.25F : 0.06F);

        switch (state) {
            case WINDUP -> {
                float p = Mth.clamp(t / 14.0F, 0.0F, 1.0F);
                rArm.xRot = -2.7F * p;
                rFore.xRot = -0.9F * p;
                lArm.xRot = -0.6F * p;
                torso.yRot -= 0.4F * p;
                torso.xRot -= 0.15F * p;
            }
            case ATTACK -> {
                float p = Mth.clamp(t / 6.0F, 0.0F, 1.0F);
                rArm.xRot = -2.7F + 3.1F * p;
                rFore.xRot = -0.9F + 0.9F * p;
                torso.yRot = -0.4F + 0.9F * p;
                torso.xRot += 0.35F * p;
                head.xRot += 0.2F * p;
            }
            case DASH -> {
                torso.xRot += 0.95F;
                head.xRot -= 0.6F;
                rArm.xRot = 1.5F;
                lArm.xRot = 1.5F;
                rThigh.xRot = -0.9F;
                lThigh.xRot = 0.9F;
                rShin.xRot = 0.8F;
            }
            case CAST -> {
                rArm.xRot = -2.8F;
                lArm.xRot = -2.8F;
                rArm.zRot = 0.5F;
                lArm.zRot = -0.5F;
                rFore.xRot = -0.3F;
                lFore.xRot = -0.3F;
                torso.xRot -= 0.15F;
                head.xRot -= 0.4F;
                rThigh.zRot = 0.12F;
                lThigh.zRot = -0.12F;
            }
            case ROAR -> {
                head.xRot -= 0.7F;
                torso.xRot -= 0.25F;
                torso.zRot = Mth.sin(age * 1.4F) * 0.03F;
                rArm.zRot = 1.1F;
                lArm.zRot = -1.1F;
                rArm.xRot = -0.2F;
                lArm.xRot = -0.2F;
            }
            default -> {
            }
        }

        if (kneel) {
            hips.y += 14.0F;
            rThigh.xRot = -1.35F;
            lThigh.xRot = -1.35F;
            rShin.xRot = 2.0F;
            lShin.xRot = 2.0F;
            torso.xRot += 0.55F;
            head.xRot += 0.35F;
            rArm.xRot = 0.3F;
            lArm.xRot = 0.3F;
            if (state == BossAnimationState.DEATH) {
                float p = Mth.clamp(t / 120.0F, 0.0F, 1.0F);
                torso.xRot += 1.0F * p;
                head.xRot += 0.7F * p;
                hips.y += 8.0F * p;
                rArm.xRot += 0.6F * p;
                lArm.xRot += 0.6F * p;
            }
        }

        // flinch when hit
        if (entity.hurtTime > 0) {
            torso.xRot -= 0.2F * (entity.hurtTime / 10.0F);
        }
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
