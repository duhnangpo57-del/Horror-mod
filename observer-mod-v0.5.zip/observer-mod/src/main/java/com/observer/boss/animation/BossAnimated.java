package com.observer.boss.animation;

/** Implemented by anything that is drawn with PerfectCopyModel. */
public interface BossAnimated {
    BossAnimationState getAnimState();

    /** Ticks since the current animation started, including the partial tick. */
    float getAnimTime(float ageInTicks);

    boolean isKneeling();

    /** 1 to 4. Used for the glow colour. */
    int getPhaseNumber();
}
