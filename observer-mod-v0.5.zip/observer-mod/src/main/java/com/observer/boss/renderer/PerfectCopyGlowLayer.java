package com.observer.boss.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.observer.ObserverMod;
import com.observer.boss.animation.BossAnimated;
import com.observer.boss.model.PerfectCopyModel;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Mob;

/** Draws the glow texture at full brightness, pulsing, and tinted by phase: violet, magenta, red, white-hot. */
public class PerfectCopyGlowLayer<T extends Mob & BossAnimated> extends RenderLayer<T, PerfectCopyModel<T>> {
    private static final ResourceLocation GLOW =
            new ResourceLocation(ObserverMod.MODID, "textures/entity/perfect_copy_glow.png");

    public PerfectCopyGlowLayer(RenderLayerParent<T, PerfectCopyModel<T>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffers, int packedLight, T entity,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (entity.isInvisible()) {
            return;
        }
        float pulse = 0.7F + 0.3F * Mth.sin(ageInTicks * 0.18F);
        float r;
        float g;
        float b;
        switch (entity.getPhaseNumber()) {
            case 2 -> {
                r = 1.0F;
                g = 0.35F;
                b = 1.0F;
            }
            case 3 -> {
                r = 1.0F;
                g = 0.2F;
                b = 0.45F;
            }
            case 4 -> {
                r = 1.0F;
                g = 0.9F;
                b = 1.0F;
            }
            default -> {
                r = 0.7F;
                g = 0.3F;
                b = 1.0F;
            }
        }
        VertexConsumer consumer = buffers.getBuffer(RenderType.eyes(GLOW));
        this.getParentModel().renderToBuffer(poseStack, consumer, LightTexture.FULL_BRIGHT,
                OverlayTexture.NO_OVERLAY, r * pulse, g * pulse, b * pulse, 1.0F);
    }
}
