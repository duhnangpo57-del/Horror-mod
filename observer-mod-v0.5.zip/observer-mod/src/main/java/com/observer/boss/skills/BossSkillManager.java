package com.observer.boss.skills;

import com.observer.boss.entity.PerfectCopyEntity;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/** Owns the ten skills, runs one at a time, and cancels cleanly. */
public final class BossSkillManager {
    private final PerfectCopyEntity boss;
    private final List<BossSkill> selectable = new ArrayList<>();
    private final PerfectDodgeSkill dodge = new PerfectDodgeSkill();
    private final FinalCopySkill finalCopy = new FinalCopySkill();
    @Nullable
    private BossSkill current;

    public BossSkillManager(PerfectCopyEntity boss) {
        this.boss = boss;
        selectable.add(new CopyStrikeSkill());
        selectable.add(new ShadowDashSkill());
        selectable.add(new MirrorCloneSkill());
        selectable.add(new BlockControlSkill());
        selectable.add(new TerrainBreakSkill());
        selectable.add(new VoidPulseSkill());
        selectable.add(new WeaponShiftSkill());
        selectable.add(new MemoryTrapSkill());
        selectable.add(finalCopy);
    }

    public List<BossSkill> selectable() {
        return selectable;
    }

    public PerfectDodgeSkill dodge() {
        return dodge;
    }

    public FinalCopySkill finalCopy() {
        return finalCopy;
    }

    public boolean isRunning() {
        return current != null;
    }

    @Nullable
    public String currentId() {
        return current == null ? null : current.id();
    }

    public void start(BossSkill skill, SkillContext context) {
        current = skill;
        skill.begin(context);
    }

    public void tick(SkillContext context) {
        if (current != null && !current.tick(context)) {
            current = null;
        }
    }

    public void cancel() {
        if (current != null) {
            current.cancel(boss);
            current = null;
        }
    }
}
