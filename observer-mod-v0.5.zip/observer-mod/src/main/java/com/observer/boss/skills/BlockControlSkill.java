package com.observer.boss.skills;

import com.observer.boss.BossFx;
import com.observer.boss.animation.BossAnimationState;
import com.observer.boss.arena.ArenaBlockManager;
import com.observer.boss.arena.ArenaBoundary;
import com.observer.config.BossConfig;
import com.observer.dimension.ArenaGenerator;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * Raises temporary stone: a wall across the player's path or a ring of pillars around them.
 * Only inside the arena, only in air, never on a player, and it all goes away by itself.
 */
public final class BlockControlSkill extends BossSkill {
    private static final int LIFETIME_TICKS = 160;

    private final List<BlockPos> planned = new ArrayList<>();
    private BlockState material = Blocks.POLISHED_BLACKSTONE.defaultBlockState();

    public BlockControlSkill() {
        super("block_control", 320, 30, 10, 20, 6.0D, 30.0D, 2);
    }

    @Override
    protected boolean extraCheck(SkillContext c) {
        return BossConfig.ENABLE_ARENA_BLOCK_SKILLS.get() && ArenaBoundary.inDomain(c.level());
    }

    @Override
    protected void onBegin(SkillContext c) {
        c.boss().getNavigation().stop();
        c.boss().animation().play(BossAnimationState.CAST);
        planned.clear();
        if (c.target() == null) {
            return;
        }
        boolean wall = c.boss().getRandom().nextBoolean();
        material = wall ? Blocks.POLISHED_BLACKSTONE.defaultBlockState() : Blocks.CRYING_OBSIDIAN.defaultBlockState();
        int baseY = ArenaGenerator.FLOOR_Y + 1;
        if (wall) {
            Vec3 toTarget = new Vec3(c.target().getX() - c.boss().getX(), 0.0D, c.target().getZ() - c.boss().getZ());
            Vec3 dir = toTarget.lengthSqr() < 1.0E-4D ? new Vec3(0.0D, 0.0D, 1.0D) : toTarget.normalize();
            Vec3 side = new Vec3(-dir.z, 0.0D, dir.x);
            Vec3 center = c.boss().position().add(dir.scale(8.0D));
            for (int i = -3; i <= 3; i++) {
                for (int h = 0; h < 3; h++) {
                    planned.add(BlockPos.containing(center.x + side.x * i, baseY + h, center.z + side.z * i));
                }
            }
        } else {
            for (int k = 0; k < 4; k++) {
                double angle = Math.PI / 2.0D * k + Math.PI / 4.0D;
                double x = c.target().getX() + Math.cos(angle) * 5.0D;
                double z = c.target().getZ() + Math.sin(angle) * 5.0D;
                for (int h = 0; h < 4; h++) {
                    planned.add(BlockPos.containing(x, baseY + h, z));
                }
            }
        }
    }

    @Override
    protected void onTelegraph(SkillContext c, int t) {
        if (t % 4 == 0) {
            for (BlockPos pos : planned) {
                if (pos.getY() == ArenaGenerator.FLOOR_Y + 1) {
                    BossFx.particles(c.level(), ParticleTypes.DRAGON_BREATH, pos.getX() + 0.5D, pos.getY() + 0.2D,
                            pos.getZ() + 0.5D, 1, 0.1D, 0.0D, 0.1D, 0.0D);
                }
            }
        }
    }

    @Override
    protected void onActive(SkillContext c, int t) {
        if (t != 1) {
            return;
        }
        for (BlockPos pos : planned) {
            ArenaBlockManager.placeTemp(c.level(), pos, material, LIFETIME_TICKS);
        }
        planned.clear();
    }

    @Override
    protected void onRecovery(SkillContext c, int t) {
        if (t == 1) {
            c.boss().animation().play(BossAnimationState.IDLE);
        }
    }
}
