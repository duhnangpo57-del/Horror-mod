package com.observer.boss.arena;

import com.observer.boss.entity.PerfectCopyEntity;
import com.observer.dimension.ArenaGenerator;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

/** Fight-state housekeeping inside the Domain: rescues players who fall into the void, restores blocks. */
public final class BossArenaController {
    public static final double PLAYER_SPAWN_Z = 18.5D;
    public static final double BOSS_SPAWN_Z = -14.5D;

    private final PerfectCopyEntity boss;

    public BossArenaController(PerfectCopyEntity boss) {
        this.boss = boss;
    }

    public void tick(ServerLevel level) {
        if (!ArenaBoundary.inDomain(level) || boss.tickCount % 20 != 0) {
            return;
        }
        ArenaBlockManager.tick(level);
        for (Player p : level.players()) {
            if (p instanceof ServerPlayer sp && !sp.isSpectator() && sp.getY() < ArenaGenerator.FLOOR_Y - 12) {
                sp.fallDistance = 0.0F;
                sp.teleportTo(level, 0.5D, ArenaGenerator.FLOOR_Y + 2.0D, PLAYER_SPAWN_Z, 180.0F, 0.0F);
                sp.hurt(level.damageSources().magic(), 4.0F);
                sp.sendSystemMessage(Component.translatable("boss.observer.void_rescue"));
            }
        }
    }

    public void onBossRemoved(ServerLevel level) {
        if (ArenaBoundary.inDomain(level)) {
            ArenaBlockManager.restoreAll(level);
        }
    }
}
