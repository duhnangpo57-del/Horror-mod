package com.observer.boss.skills;

/** Set by Weapon Shift. Changes how the boss fights, never gives it new abilities. */
public enum BossStance {
    /** Melee focus. */
    BLADE,
    /** Ranged focus: Copy Strike becomes a fan of soul arrows. */
    BOW,
    /** Guard and counter: takes half damage from the front. */
    SHIELD,
    /** Area control: zone skills are preferred. */
    CONTROL;

    private static final BossStance[] VALUES = values();

    public static BossStance byId(int id) {
        return id >= 0 && id < VALUES.length ? VALUES[id] : BLADE;
    }
}
