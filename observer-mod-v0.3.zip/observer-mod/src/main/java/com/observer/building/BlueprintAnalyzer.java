package com.observer.building;

import com.observer.memory.PlayerProfile;
import it.unimi.dsi.fastutil.longs.Long2IntMap;
import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;
import net.minecraft.core.BlockPos;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/**
 * Finds the densest cluster of blocks a player has placed and turns it into a blueprint.
 * Runs in linear time over the placement log using 8x8x8 buckets.
 */
public final class BlueprintAnalyzer {
    private static final int MIN_BLOCKS = 30;

    private BlueprintAnalyzer() {
    }

    @Nullable
    public static Blueprint analyze(PlayerProfile profile, int maxBlocks) {
        int n = profile.placementCount();
        if (n < MIN_BLOCKS) {
            return null;
        }
        Long2IntOpenHashMap buckets = new Long2IntOpenHashMap();
        for (int i = 0; i < n; i++) {
            buckets.addTo(bucket(profile.placementPos(i)), 1);
        }

        long bestKey = 0L;
        int best = 0;
        for (Long2IntMap.Entry e : buckets.long2IntEntrySet()) {
            long key = e.getLongKey();
            int bx = BlockPos.getX(key);
            int by = BlockPos.getY(key);
            int bz = BlockPos.getZ(key);
            int sum = 0;
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        sum += buckets.get(BlockPos.asLong(bx + dx, by + dy, bz + dz));
                    }
                }
            }
            if (sum > best) {
                best = sum;
                bestKey = key;
            }
        }
        if (best < MIN_BLOCKS) {
            return null;
        }

        int cx = BlockPos.getX(bestKey);
        int cy = BlockPos.getY(bestKey);
        int cz = BlockPos.getZ(bestKey);
        List<Integer> picked = new ArrayList<>();
        int minX = Integer.MAX_VALUE;
        int minY = Integer.MAX_VALUE;
        int minZ = Integer.MAX_VALUE;
        for (int i = 0; i < n; i++) {
            long packed = profile.placementPos(i);
            if (Math.abs((BlockPos.getX(packed) >> 3) - cx) > 1
                    || Math.abs((BlockPos.getY(packed) >> 3) - cy) > 1
                    || Math.abs((BlockPos.getZ(packed) >> 3) - cz) > 1) {
                continue;
            }
            if (profile.placementId(i).equals("minecraft:air")) {
                continue;
            }
            picked.add(i);
            minX = Math.min(minX, BlockPos.getX(packed));
            minY = Math.min(minY, BlockPos.getY(packed));
            minZ = Math.min(minZ, BlockPos.getZ(packed));
        }
        if (picked.size() < MIN_BLOCKS) {
            return null;
        }
        List<BlueprintBlock> blocks = new ArrayList<>();
        for (int i : picked) {
            long packed = profile.placementPos(i);
            blocks.add(new BlueprintBlock(
                    BlockPos.getX(packed) - minX,
                    BlockPos.getY(packed) - minY,
                    BlockPos.getZ(packed) - minZ,
                    profile.placementId(i)));
        }
        return Blueprint.sorted("player_build", blocks).limit(maxBlocks);
    }

    private static long bucket(long packed) {
        return BlockPos.asLong(BlockPos.getX(packed) >> 3, BlockPos.getY(packed) >> 3, BlockPos.getZ(packed) >> 3);
    }
}
