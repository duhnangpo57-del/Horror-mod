package com.observer.building;

import java.util.ArrayList;
import java.util.List;

/** Built-in blueprints. "observer:material" means: use whatever building block the Observer has most of. */
public final class BlueprintLibrary {
    private BlueprintLibrary() {
    }

    /** 5x5 hut: walls 2 high with a 1-wide doorway, flat roof. 57 blocks. */
    public static Blueprint shelter() {
        List<BlueprintBlock> out = new ArrayList<>();
        for (int y = 0; y < 2; y++) {
            for (int x = 0; x < 5; x++) {
                for (int z = 0; z < 5; z++) {
                    boolean edge = x == 0 || x == 4 || z == 0 || z == 4;
                    boolean doorway = z == 0 && x == 2;
                    if (edge && !doorway) {
                        out.add(new BlueprintBlock(x, y, z, ConstructionTask.MATERIAL));
                    }
                }
            }
        }
        for (int x = 0; x < 5; x++) {
            for (int z = 0; z < 5; z++) {
                out.add(new BlueprintBlock(x, 2, z, ConstructionTask.MATERIAL));
            }
        }
        return Blueprint.sorted("shelter", out);
    }
}
