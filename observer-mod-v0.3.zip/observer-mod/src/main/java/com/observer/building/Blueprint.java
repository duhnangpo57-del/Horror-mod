package com.observer.building;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** A set of blocks relative to a minimum corner, ordered bottom-up. */
public record Blueprint(String name, List<BlueprintBlock> blocks) {

    public static Blueprint sorted(String name, List<BlueprintBlock> blocks) {
        List<BlueprintBlock> copy = new ArrayList<>(blocks);
        copy.sort(Comparator.comparingInt(BlueprintBlock::y)
                .thenComparingInt(BlueprintBlock::x)
                .thenComparingInt(BlueprintBlock::z));
        return new Blueprint(name, copy);
    }

    public Blueprint limit(int max) {
        return blocks.size() <= max ? this : new Blueprint(name, new ArrayList<>(blocks.subList(0, max)));
    }

    public int sizeX() {
        int max = 0;
        for (BlueprintBlock b : blocks) {
            max = Math.max(max, b.x() + 1);
        }
        return max;
    }

    public int sizeZ() {
        int max = 0;
        for (BlueprintBlock b : blocks) {
            max = Math.max(max, b.z() + 1);
        }
        return max;
    }
}
