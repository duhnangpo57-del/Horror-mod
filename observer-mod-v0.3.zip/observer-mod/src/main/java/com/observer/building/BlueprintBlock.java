package com.observer.building;

public record BlueprintBlock(int x, int y, int z, String blockId) {
}
