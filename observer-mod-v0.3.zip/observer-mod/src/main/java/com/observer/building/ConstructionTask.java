package com.observer.building;

import com.observer.entity.ObserverEntity;
import com.observer.interaction.BlockBreaker;
import com.observer.interaction.BlockPlacer;
import com.observer.interaction.BlockRules;
import com.observer.survival.SurvivalPlanner;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/**
 * Builds a blueprint one real block at a time, bottom-up, using items from the Observer's inventory.
 * Re-checks its own work afterwards and fixes gaps. Fully saved to NBT, so it survives reloads.
 */
public final class ConstructionTask {
    public static final String MATERIAL = "observer:material";

    public enum Status { RUNNING, DONE, NEED_MATERIALS }

    public record Target(BlockPos pos, String blockId) {
    }

    private record Supply(boolean skip, @Nullable ItemStack stack) {
        static final Supply SKIP = new Supply(true, null);
        static final Supply NEED = new Supply(false, null);
    }

    private final String name;
    private final BlockPos origin;
    private List<Target> targets;
    private int index;
    private int round;
    private int stuck;

    private ConstructionTask(String name, BlockPos origin, List<Target> targets) {
        this.name = name;
        this.origin = origin;
        this.targets = targets;
    }

    public static ConstructionTask create(Blueprint blueprint, BlockPos origin) {
        List<Target> list = new ArrayList<>();
        for (BlueprintBlock b : blueprint.blocks()) {
            list.add(new Target(origin.offset(b.x(), b.y(), b.z()), b.blockId()));
        }
        return new ConstructionTask(blueprint.name(), origin.immutable(), list);
    }

    public String name() {
        return name;
    }

    public BlockPos origin() {
        return origin;
    }

    public int remaining() {
        return Math.max(0, targets.size() - index);
    }

    public Status tick(ObserverEntity entity, ServerLevel level, int elapsed) {
        int guard = 0;
        while (index < targets.size() && guard++ < 64) {
            Target target = targets.get(index);
            Supply supply = resolve(entity, level, target);
            if (supply.skip()) {
                index++;
                continue;
            }
            if (supply.stack() == null) {
                return Status.NEED_MATERIALS;
            }
            ItemStack stack = supply.stack();
            Block wanted = ((BlockItem) stack.getItem()).getBlock();
            BlockState current = level.getBlockState(target.pos());

            if (current.is(wanted)) {
                index++;
                stuck = 0;
                continue;
            }
            if (!current.isAir() && !current.canBeReplaced()) {
                if (BlockRules.canBreak(entity, level, target.pos(), current)) {
                    if (!target.pos().equals(entity.breaker().target())) {
                        entity.breaker().begin(target.pos());
                    }
                    if (entity.breaker().tick(level, elapsed) == BlockBreaker.Result.FAILED) {
                        index++;
                    }
                    return Status.RUNNING;
                }
                index++;
                continue;
            }

            Vec3 center = Vec3.atCenterOf(target.pos());
            if (entity.getEyePosition().distanceToSqr(center) > 20.0D) {
                if (entity.getNavigation().isDone()) {
                    entity.getNavigation().moveTo(center.x, center.y, center.z, 1.0D);
                }
                if (++stuck > 80) {
                    index++;
                    stuck = 0;
                }
                return Status.RUNNING;
            }
            if (entity.getBoundingBox().intersects(new AABB(target.pos()))) {
                Vec3 away = DefaultRandomPos.getPos(entity, 4, 2);
                if (away != null) {
                    entity.getNavigation().moveTo(away.x, away.y, away.z, 1.0D);
                }
                if (++stuck > 30) {
                    index++;
                    stuck = 0;
                }
                return Status.RUNNING;
            }
            entity.getLookControl().setLookAt(center.x, center.y, center.z);
            if (BlockPlacer.place(entity, level, target.pos(), stack)) {
                index++;
                stuck = 0;
            } else if (++stuck > 6) {
                index++;
                stuck = 0;
            }
            return Status.RUNNING;
        }
        return index >= targets.size() ? verify(level) : Status.RUNNING;
    }

    private Supply resolve(ObserverEntity entity, ServerLevel level, Target target) {
        if (!MATERIAL.equals(target.blockId())) {
            Block block = ForgeRegistries.BLOCKS.getValue(new ResourceLocation(target.blockId()));
            if (block == null || block == Blocks.AIR || !(block.asItem() instanceof BlockItem)) {
                return Supply.SKIP;
            }
            if (!block.defaultBlockState().isCollisionShapeFullBlock(level, target.pos())) {
                return Supply.SKIP; // only full blocks are copied; doors, stairs, torches are left out
            }
            ItemStack exact = entity.inventory().find(s -> s.is(block.asItem()));
            if (exact != null) {
                return new Supply(false, exact);
            }
        }
        Item material = entity.inventory().mostCommon(SurvivalPlanner::isBuildMaterial);
        if (material == null || !(material instanceof BlockItem)) {
            return Supply.NEED;
        }
        ItemStack stack = entity.inventory().find(s -> s.is(material));
        return stack == null ? Supply.NEED : new Supply(false, stack);
    }

    /** Looks for holes and goes back for them (at most twice). */
    private Status verify(ServerLevel level) {
        List<Target> holes = new ArrayList<>();
        for (Target t : targets) {
            BlockState state = level.getBlockState(t.pos());
            if (state.isAir() || state.canBeReplaced()) {
                holes.add(t);
            }
        }
        if (holes.isEmpty() || round >= 2) {
            return Status.DONE;
        }
        round++;
        targets = holes;
        index = 0;
        return Status.RUNNING;
    }

    // ------------------------------------------------------------ persistence

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putString("Name", name);
        tag.putLong("Origin", origin.asLong());
        tag.putInt("Index", index);
        tag.putInt("Round", round);

        List<String> palette = new ArrayList<>();
        long[] positions = new long[targets.size()];
        int[] ids = new int[targets.size()];
        for (int i = 0; i < targets.size(); i++) {
            Target t = targets.get(i);
            int p = palette.indexOf(t.blockId());
            if (p < 0) {
                palette.add(t.blockId());
                p = palette.size() - 1;
            }
            positions[i] = t.pos().asLong();
            ids[i] = p;
        }
        ListTag pal = new ListTag();
        for (String s : palette) {
            pal.add(StringTag.valueOf(s));
        }
        tag.put("Palette", pal);
        tag.putLongArray("Pos", positions);
        tag.putIntArray("Ids", ids);
        return tag;
    }

    @Nullable
    public static ConstructionTask load(CompoundTag tag) {
        ListTag pal = tag.getList("Palette", Tag.TAG_STRING);
        long[] positions = tag.getLongArray("Pos");
        int[] ids = tag.getIntArray("Ids");
        int n = Math.min(positions.length, ids.length);
        if (n == 0 || n > 4096) {
            return null;
        }
        List<Target> list = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            if (ids[i] >= 0 && ids[i] < pal.size()) {
                list.add(new Target(BlockPos.of(positions[i]), pal.getString(ids[i])));
            }
        }
        if (list.isEmpty()) {
            return null;
        }
        ConstructionTask task = new ConstructionTask(tag.getString("Name"), BlockPos.of(tag.getLong("Origin")), list);
        task.index = Math.max(0, Math.min(tag.getInt("Index"), list.size()));
        task.round = Math.max(0, Math.min(tag.getInt("Round"), 2));
        return task;
    }
}
