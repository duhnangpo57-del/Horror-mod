package com.observer.building;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

import javax.annotation.Nullable;

public final class BuildSites {
    private BuildSites() {
    }

    /**
     * Looks for a roughly level, dry footprint near {@code around}.
     * @return the minimum corner at ground level, or null if none was found
     */
    @Nullable
    public static BlockPos findFlat(ServerLevel level, BlockPos around, int sizeX, int sizeZ,
                                    int maxDiff, int radius, RandomSource random) {
        BlockPos best = null;
        int bestDiff = Integer.MAX_VALUE;
        for (int attempt = 0; attempt < 40; attempt++) {
            int x = around.getX() + random.nextInt(radius * 2 + 1) - radius;
            int z = around.getZ() + random.nextInt(radius * 2 + 1) - radius;
            if (!level.hasChunkAt(new BlockPos(x, around.getY(), z))
                    || !level.hasChunkAt(new BlockPos(x + sizeX, around.getY(), z + sizeZ))) {
                continue;
            }
            int min = Integer.MAX_VALUE;
            int max = Integer.MIN_VALUE;
            boolean bad = false;
            for (int dx : new int[] {0, sizeX - 1}) {
                for (int dz : new int[] {0, sizeZ - 1}) {
                    int h = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x + dx, z + dz);
                    BlockState below = level.getBlockState(new BlockPos(x + dx, h - 1, z + dz));
                    if (!below.getFluidState().isEmpty()) {
                        bad = true;
                    }
                    min = Math.min(min, h);
                    max = Math.max(max, h);
                }
            }
            if (bad) {
                continue;
            }
            int diff = max - min;
            if (diff < bestDiff) {
                bestDiff = diff;
                best = new BlockPos(x, max, z);
            }
            if (diff <= 1) {
                break;
            }
        }
        return bestDiff <= maxDiff ? best : null;
    }
}
