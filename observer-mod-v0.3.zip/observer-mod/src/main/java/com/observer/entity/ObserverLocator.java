package com.observer.entity;

import com.observer.memory.ObserverWorldData;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;

import javax.annotation.Nullable;
import java.util.UUID;

public final class ObserverLocator {
    private ObserverLocator() {
    }

    /** The one registered Observer, if it is currently loaded. */
    @Nullable
    public static ObserverEntity find(MinecraftServer server) {
        UUID id = ObserverWorldData.get(server).getObserverId();
        if (id == null) {
            return null;
        }
        for (ServerLevel level : server.getAllLevels()) {
            Entity entity = level.getEntity(id);
            if (entity instanceof ObserverEntity observer) {
                return observer;
            }
        }
        return null;
    }
}
