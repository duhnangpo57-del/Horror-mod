package com.observer.entity;

import com.observer.ai.ObserverBrain;
import com.observer.config.ObserverConfig;
import com.observer.interaction.BlockBreaker;
import com.observer.interaction.ItemCollector;
import com.observer.memory.ObserverWorldData;
import com.observer.survival.Crafter;
import com.observer.survival.ObserverInventory;
import com.observer.survival.SurvivalPlanner;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.OpenDoorGoal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.Optional;
import java.util.UUID;

public class ObserverEntity extends PathfinderMob {
    private static final EntityDataAccessor<Optional<UUID>> DATA_SKIN_OF =
            SynchedEntityData.defineId(ObserverEntity.class, EntityDataSerializers.OPTIONAL_UUID);

    private static final int POSITION_SYNC_INTERVAL = 200;
    private static final long BREAK_WINDOW_TICKS = 72000L;
    private static final String TAG_VERSION = "ObserverEntityVersion";
    private static final String TAG_BRAIN = "Brain";
    private static final int ENTITY_VERSION = 3;

    private final ObserverInventory inventory = new ObserverInventory(this);
    private final BlockBreaker breaker = new BlockBreaker(this);
    private final ObserverBrain brain = new ObserverBrain(this);

    private long breakWindowStart;
    private int breaksInWindow;
    private long lastHurtTime = -100000L;
    private long nextGearCheck;
    private long nextArmorCraft;
    private long nextEat;
    private long nextRegen;

    public ObserverEntity(EntityType<? extends ObserverEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.FOLLOW_RANGE, 48.0D)
                .add(Attributes.ATTACK_DAMAGE, 3.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.3D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_SKIN_OF, Optional.empty());
    }

    public ObserverBrain getObserverBrain() {
        return brain;
    }

    public ObserverInventory inventory() {
        return inventory;
    }

    public BlockBreaker breaker() {
        return breaker;
    }

    // ------------------------------------------------------------------ appearance

    /** The player whose skin this Observer wears, if any. */
    @Nullable
    public UUID getSkinOf() {
        return this.entityData.get(DATA_SKIN_OF).orElse(null);
    }

    public void setSkinOf(@Nullable UUID player) {
        this.entityData.set(DATA_SKIN_OF, Optional.ofNullable(player));
    }

    // ------------------------------------------------------------------ block-breaking budget

    public boolean canBreakMoreBlocks(long now) {
        if (now - breakWindowStart > BREAK_WINDOW_TICKS) {
            breakWindowStart = now;
            breaksInWindow = 0;
        }
        return breaksInWindow < ObserverConfig.MAX_BREAKS_PER_HOUR.get();
    }

    public void noteBlockBroken(long now) {
        if (now - breakWindowStart > BREAK_WINDOW_TICKS) {
            breakWindowStart = now;
            breaksInWindow = 0;
        }
        breaksInWindow++;
    }

    // ------------------------------------------------------------------ upkeep (runs every brain update)

    public void upkeep(ServerLevel level, long now) {
        ItemCollector.pickup(this, level);

        if (now >= nextGearCheck) {
            nextGearCheck = now + 100L;
            inventory.equipBestArmor();
            if (now >= nextArmorCraft) {
                nextArmorCraft = now + 2400L;
                tryCraftArmor(level);
            }
        }
        if (this.getHealth() < this.getMaxHealth() * 0.7F && now >= nextEat) {
            nextEat = now + 60L;
            tryEat();
        }
        if (now - lastHurtTime > 400L && now >= nextRegen && this.getHealth() < this.getMaxHealth()) {
            nextRegen = now + 200L;
            this.heal(1.0F);
        }
    }

    private void tryEat() {
        ItemStack food = inventory.find(SurvivalPlanner::isFood);
        if (food == null) {
            return;
        }
        FoodProperties props = food.getItem().getFoodProperties();
        this.heal(props == null ? 2.0F : Math.max(1.0F, props.getNutrition()));
        this.playSound(SoundEvents.GENERIC_EAT, 0.6F, 1.0F);
        this.swing(InteractionHand.MAIN_HAND);
        food.shrink(1);
    }

    /** Armor needs 4-8 of one material; only tries when the Observer really holds enough. */
    private void tryCraftArmor(ServerLevel level) {
        craftSet(level, Items.DIAMOND, Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS);
        craftSet(level, Items.IRON_INGOT, Items.IRON_HELMET, Items.IRON_CHESTPLATE, Items.IRON_LEGGINGS, Items.IRON_BOOTS);
        craftSet(level, Items.LEATHER, Items.LEATHER_HELMET, Items.LEATHER_CHESTPLATE, Items.LEATHER_LEGGINGS, Items.LEATHER_BOOTS);
    }

    private void craftSet(ServerLevel level, Item material, Item... pieces) {
        int[] cost = {5, 8, 7, 4};
        for (int i = 0; i < pieces.length; i++) {
            Item piece = pieces[i];
            if (!(piece instanceof ArmorItem armor)) {
                continue;
            }
            ItemStack worn = this.getItemBySlot(armor.getEquipmentSlot());
            if (worn.getItem() instanceof ArmorItem wornArmor && wornArmor.getDefense() >= armor.getDefense()) {
                continue;
            }
            if (inventory.find(s -> s.is(piece)) != null) {
                continue;
            }
            if (inventory.count(s -> s.is(material)) >= cost[i]) {
                Crafter.craft(this, level, piece);
            }
        }
        inventory.equipBestArmor();
    }

    // ------------------------------------------------------------------ vanilla overrides

    @Override
    protected void registerGoals() {
        // Decisions come from ObserverBrain; only keep it afloat and let it use doors.
        if (this.getNavigation() instanceof GroundPathNavigation ground) {
            ground.setCanOpenDoors(true);
        }
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new OpenDoorGoal(this, true));
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean hurt = super.hurt(source, amount);
        if (hurt) {
            lastHurtTime = this.tickCount;
        }
        return hurt;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide || !this.isAlive()) {
            return;
        }
        brain.tick();
        if (this.tickCount % POSITION_SYNC_INTERVAL == 0) {
            MinecraftServer server = this.level().getServer();
            if (server != null) {
                ObserverWorldData.get(server).updateLastKnown(
                        this.getUUID(),
                        this.blockPosition(),
                        this.level().dimension().location().toString());
            }
        }
    }

    @Override
    public void remove(Entity.RemovalReason reason) {
        // Only a real death/discard frees the world's single Observer slot.
        // Chunk unloads and dimension changes keep the registration.
        if (!this.level().isClientSide) {
            breaker.cancel();
            if (reason.shouldDestroy()) {
                MinecraftServer server = this.level().getServer();
                if (server != null) {
                    ObserverWorldData.get(server).release(this.getUUID());
                }
            }
        }
        super.remove(reason);
    }

    @Override
    protected void dropCustomDeathLoot(DamageSource source, int looting, boolean recentlyHit) {
        super.dropCustomDeathLoot(source, looting, recentlyHit);
        inventory.dropAll();
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.PLAYER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.PLAYER_DEATH;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt(TAG_VERSION, ENTITY_VERSION);
        tag.put(TAG_BRAIN, brain.save());
        inventory.save(tag);
        UUID skin = getSkinOf();
        if (skin != null) {
            tag.putUUID("SkinOf", skin);
        }
        tag.putLong("BreakWindowStart", breakWindowStart);
        tag.putInt("BreaksInWindow", breaksInWindow);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains(TAG_BRAIN, Tag.TAG_COMPOUND)) {
            brain.load(tag.getCompound(TAG_BRAIN));
        }
        inventory.load(tag);
        if (tag.hasUUID("SkinOf")) {
            setSkinOf(tag.getUUID("SkinOf"));
        }
        breakWindowStart = tag.getLong("BreakWindowStart");
        breaksInWindow = Math.max(0, tag.getInt("BreaksInWindow"));
    }
}
