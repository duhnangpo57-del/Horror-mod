package com.observer.survival;

import com.observer.entity.ObserverEntity;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

/**
 * The Observer's real inventory: a 27-slot bag plus whatever is in its hands.
 * Armor lives in the normal equipment slots. Items are never created from nothing
 * except by crafting (which consumes real ingredients).
 */
public final class ObserverInventory {
    private static final EquipmentSlot[] ARMOR = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private final ObserverEntity owner;
    private final SimpleContainer bag = new SimpleContainer(27);

    public ObserverInventory(ObserverEntity owner) {
        this.owner = owner;
    }

    public SimpleContainer bag() {
        return bag;
    }

    /** Live references: hands first, then the bag. */
    private List<ItemStack> live() {
        List<ItemStack> list = new ArrayList<>(bag.getContainerSize() + 2);
        list.add(owner.getMainHandItem());
        list.add(owner.getOffhandItem());
        for (int i = 0; i < bag.getContainerSize(); i++) {
            list.add(bag.getItem(i));
        }
        return list;
    }

    /** Copies of every non-empty stack (safe to modify). */
    public List<ItemStack> snapshot() {
        List<ItemStack> copies = new ArrayList<>();
        for (ItemStack s : live()) {
            if (!s.isEmpty()) {
                copies.add(s.copy());
            }
        }
        return copies;
    }

    public int count(Predicate<ItemStack> predicate) {
        int total = 0;
        for (ItemStack s : live()) {
            if (!s.isEmpty() && predicate.test(s)) {
                total += s.getCount();
            }
        }
        return total;
    }

    @Nullable
    public ItemStack find(Predicate<ItemStack> predicate) {
        for (ItemStack s : live()) {
            if (!s.isEmpty() && predicate.test(s)) {
                return s;
            }
        }
        return null;
    }

    /** Removes up to {@code amount} matching items. Returns how many were removed. */
    public int consume(Predicate<ItemStack> predicate, int amount) {
        int left = amount;
        for (ItemStack s : live()) {
            if (left <= 0) {
                break;
            }
            if (!s.isEmpty() && predicate.test(s)) {
                int take = Math.min(left, s.getCount());
                s.shrink(take);
                left -= take;
            }
        }
        return amount - left;
    }

    public void add(ItemStack stack) {
        if (stack.isEmpty()) {
            return;
        }
        ItemStack rest = bag.addItem(stack.copy());
        if (!rest.isEmpty()) {
            owner.spawnAtLocation(rest);
        }
    }

    /** The item (type) with the highest total count among matching stacks. */
    @Nullable
    public Item mostCommon(Predicate<ItemStack> predicate) {
        Map<Item, Integer> totals = new HashMap<>();
        for (ItemStack s : live()) {
            if (!s.isEmpty() && predicate.test(s)) {
                totals.merge(s.getItem(), s.getCount(), Integer::sum);
            }
        }
        Item best = null;
        int bestCount = 0;
        for (Map.Entry<Item, Integer> e : totals.entrySet()) {
            if (e.getValue() > bestCount) {
                bestCount = e.getValue();
                best = e.getKey();
            }
        }
        return best;
    }

    // ------------------------------------------------------------ equipping

    public void equipBestTool(BlockState state) {
        ItemStack current = owner.getMainHandItem();
        float bestScore = toolScore(current, state);
        int bestIndex = -1;
        for (int i = 0; i < bag.getContainerSize(); i++) {
            ItemStack s = bag.getItem(i);
            float score = toolScore(s, state);
            if (score > bestScore + 0.01F) {
                bestScore = score;
                bestIndex = i;
            }
        }
        if (bestIndex >= 0) {
            swapIntoMainHand(bestIndex);
        }
    }

    private static float toolScore(ItemStack stack, BlockState state) {
        if (stack.isEmpty()) {
            return state.requiresCorrectToolForDrops() ? 0.0F : 1.0F;
        }
        if (state.requiresCorrectToolForDrops() && !stack.isCorrectToolForDrops(state)) {
            return 0.0F;
        }
        return Math.max(1.0F, stack.getDestroySpeed(state));
    }

    public void equipBestWeapon() {
        ItemStack current = owner.getMainHandItem();
        float best = weaponScore(current);
        int bestIndex = -1;
        for (int i = 0; i < bag.getContainerSize(); i++) {
            float score = weaponScore(bag.getItem(i));
            if (score > best + 0.01F) {
                best = score;
                bestIndex = i;
            }
        }
        if (bestIndex >= 0) {
            swapIntoMainHand(bestIndex);
        }
    }

    private static float weaponScore(ItemStack stack) {
        if (stack.isEmpty()) {
            return 0.0F;
        }
        if (stack.getItem() instanceof SwordItem sword) {
            return 4.0F + sword.getDamage();
        }
        if (stack.getItem() instanceof AxeItem axe) {
            return 3.0F + axe.getAttackDamage();
        }
        return 0.5F;
    }

    private void swapIntoMainHand(int bagIndex) {
        ItemStack from = bag.getItem(bagIndex);
        ItemStack old = owner.getMainHandItem();
        owner.setItemSlot(EquipmentSlot.MAINHAND, from);
        bag.setItem(bagIndex, old.isEmpty() ? ItemStack.EMPTY : old);
    }

    public void equipBestArmor() {
        for (EquipmentSlot slot : ARMOR) {
            ItemStack worn = owner.getItemBySlot(slot);
            int best = worn.getItem() instanceof ArmorItem a ? a.getDefense() : -1;
            int bestIndex = -1;
            for (int i = 0; i < bag.getContainerSize(); i++) {
                ItemStack s = bag.getItem(i);
                if (s.getItem() instanceof ArmorItem armor && armor.getEquipmentSlot() == slot && armor.getDefense() > best) {
                    best = armor.getDefense();
                    bestIndex = i;
                }
            }
            if (bestIndex >= 0) {
                ItemStack from = bag.getItem(bestIndex);
                owner.setItemSlot(slot, from);
                bag.setItem(bestIndex, worn.isEmpty() ? ItemStack.EMPTY : worn);
            }
        }
    }

    // ------------------------------------------------------------ persistence

    public void save(CompoundTag tag) {
        tag.put("Bag", bag.createTag());
    }

    public void load(CompoundTag tag) {
        if (tag.contains("Bag", Tag.TAG_LIST)) {
            bag.fromTag(tag.getList("Bag", Tag.TAG_COMPOUND));
        }
    }

    public void dropAll() {
        for (int i = 0; i < bag.getContainerSize(); i++) {
            ItemStack s = bag.getItem(i);
            if (!s.isEmpty()) {
                owner.spawnAtLocation(s);
                bag.setItem(i, ItemStack.EMPTY);
            }
        }
    }
}
