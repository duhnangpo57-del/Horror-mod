package com.observer.survival;

import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.TieredItem;

/** Pure inventory questions used to decide what the Observer needs next. */
public final class SurvivalPlanner {
    private SurvivalPlanner() {
    }

    public static boolean isFood(ItemStack s) {
        return s.getItem().isEdible();
    }

    public static boolean isStoneMaterial(ItemStack s) {
        return s.is(Items.COBBLESTONE) || s.is(Items.COBBLED_DEEPSLATE) || s.is(Items.BLACKSTONE);
    }

    public static boolean isBuildMaterial(ItemStack s) {
        return isStoneMaterial(s) || s.is(Items.STONE) || s.is(Items.DIRT) || s.is(ItemTags.PLANKS)
                || s.is(Items.ANDESITE) || s.is(Items.DIORITE) || s.is(Items.GRANITE);
    }

    /** Logs plus the logs' worth hidden in planks and sticks. */
    public static int woodUnits(ObserverInventory inv) {
        int logs = inv.count(s -> s.is(ItemTags.LOGS));
        int planks = inv.count(s -> s.is(ItemTags.PLANKS));
        int sticks = inv.count(s -> s.is(Items.STICK));
        return logs + planks / 4 + sticks / 8;
    }

    public static boolean hasPickaxe(ObserverInventory inv, int minLevel) {
        return hasTiered(inv, PickaxeItem.class, minLevel);
    }

    public static boolean hasAxe(ObserverInventory inv, int minLevel) {
        return hasTiered(inv, AxeItem.class, minLevel);
    }

    public static boolean hasSword(ObserverInventory inv, int minLevel) {
        return hasTiered(inv, SwordItem.class, minLevel);
    }

    private static boolean hasTiered(ObserverInventory inv, Class<? extends Item> type, int minLevel) {
        return inv.count(s -> type.isInstance(s.getItem())
                && s.getItem() instanceof TieredItem tiered && tiered.getTier().getLevel() >= minLevel) > 0;
    }
}
