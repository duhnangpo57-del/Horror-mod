package com.observer.survival;

import com.observer.entity.ObserverEntity;
import com.observer.interaction.BlockRules;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import java.util.Set;
import java.util.function.Predicate;

/** Bounded, throttled search for the nearest minable block of a kind. Never scans the whole world. */
public final class ResourceScanner {
    private ResourceScanner() {
    }

    @Nullable
    public static BlockPos find(ServerLevel level, ObserverEntity entity, int radius,
                                Predicate<BlockState> match, Set<Long> ignored) {
        BlockPos origin = entity.blockPosition();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        int vertical = Math.max(4, radius / 2);

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                int x = origin.getX() + dx;
                int z = origin.getZ() + dz;
                if (!level.hasChunkAt(new BlockPos(x, origin.getY(), z))) {
                    continue;
                }
                for (int dy = -vertical; dy <= vertical; dy++) {
                    int y = origin.getY() + dy;
                    if (y < level.getMinBuildHeight() || y >= level.getMaxBuildHeight()) {
                        continue;
                    }
                    pos.set(x, y, z);
                    BlockState state = level.getBlockState(pos);
                    if (!match.test(state)) {
                        continue;
                    }
                    double dist = origin.distSqr(pos);
                    if (dist >= bestDist || ignored.contains(pos.asLong())) {
                        continue;
                    }
                    if (!exposed(level, pos)) {
                        continue;
                    }
                    BlockPos candidate = pos.immutable();
                    if (candidate.equals(origin.below()) || !BlockRules.canBreak(entity, level, candidate, state)) {
                        continue;
                    }
                    best = candidate;
                    bestDist = dist;
                }
            }
        }
        return best;
    }

    /** At least one open side, and no lava touching it. */
    private static boolean exposed(ServerLevel level, BlockPos pos) {
        boolean open = false;
        for (Direction dir : Direction.values()) {
            BlockState neighbour = level.getBlockState(pos.relative(dir));
            if (neighbour.getFluidState().is(FluidTags.LAVA)) {
                return false;
            }
            if (!neighbour.canOcclude()) {
                open = true;
            }
        }
        return open;
    }
}
