package com.observer.survival;

import com.observer.entity.ObserverEntity;
import com.observer.interaction.BlockPlacer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.block.Blocks;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Crafts using the real recipe manager and real ingredients from the Observer's inventory.
 * Missing intermediates (planks, sticks, tables) are crafted first. Recipes larger than
 * 2x2 need a crafting table nearby, which the Observer places if it has to.
 */
public final class Crafter {
    private static final int MAX_DEPTH = 3;

    private Crafter() {
    }

    public static boolean craft(ObserverEntity entity, ServerLevel level, Item target) {
        return craft(entity, level, target, 0, new HashSet<>());
    }

    private static boolean craft(ObserverEntity entity, ServerLevel level, Item target, int depth, Set<Item> visiting) {
        if (depth > MAX_DEPTH || !visiting.add(target)) {
            return false;
        }
        try {
            for (CraftingRecipe recipe : recipesFor(level, target)) {
                if (attempt(entity, level, recipe, depth, visiting)) {
                    return true;
                }
            }
            return false;
        } finally {
            visiting.remove(target);
        }
    }

    private static List<CraftingRecipe> recipesFor(ServerLevel level, Item target) {
        List<CraftingRecipe> matches = new ArrayList<>();
        for (CraftingRecipe recipe : level.getRecipeManager().getAllRecipesFor(RecipeType.CRAFTING)) {
            if (!recipe.isSpecial() && recipe.getResultItem(level.registryAccess()).is(target)) {
                matches.add(recipe);
            }
        }
        return matches;
    }

    private static boolean attempt(ObserverEntity entity, ServerLevel level, CraftingRecipe recipe,
                                   int depth, Set<Item> visiting) {
        List<Ingredient> ingredients = new ArrayList<>();
        for (Ingredient ingredient : recipe.getIngredients()) {
            if (!ingredient.isEmpty()) {
                ingredients.add(ingredient);
            }
        }
        if (ingredients.isEmpty()) {
            return false;
        }
        boolean needsTable = !recipe.canCraftInDimensions(2, 2);
        boolean tableReady = !needsTable || tableNearby(entity, level);
        for (int round = 0; round < 10; round++) {
            List<Ingredient> missing = missing(entity, ingredients);
            if (!missing.isEmpty()) {
                if (depth >= MAX_DEPTH) {
                    return false;
                }
                boolean progress = false;
                for (Ingredient ingredient : missing) {
                    if (craftAny(entity, level, ingredient, depth + 1, visiting)) {
                        progress = true;
                        break;
                    }
                }
                if (!progress) {
                    return false;
                }
                continue;
            }
            if (!tableReady) {
                // Only now, with every ingredient in hand, is a table worth making or placing.
                if (!ensureTable(entity, level, depth, visiting)) {
                    return false;
                }
                tableReady = true;
                continue;
            }
            break;
        }
        if (!missing(entity, ingredients).isEmpty() || (needsTable && !tableNearby(entity, level))) {
            return false;
        }
        for (Ingredient ingredient : ingredients) {
            entity.inventory().consume(ingredient, 1);
        }
        entity.inventory().add(recipe.getResultItem(level.registryAccess()).copy());
        return true;
    }

    private static boolean craftAny(ObserverEntity entity, ServerLevel level, Ingredient ingredient,
                                    int depth, Set<Item> visiting) {
        for (ItemStack option : ingredient.getItems()) {
            if (craft(entity, level, option.getItem(), depth, visiting)) {
                return true;
            }
        }
        return false;
    }

    private static List<Ingredient> missing(ObserverEntity entity, List<Ingredient> ingredients) {
        List<ItemStack> pool = entity.inventory().snapshot();
        List<Ingredient> missing = new ArrayList<>();
        for (Ingredient ingredient : ingredients) {
            boolean found = false;
            for (ItemStack s : pool) {
                if (!s.isEmpty() && ingredient.test(s)) {
                    s.shrink(1);
                    found = true;
                    break;
                }
            }
            if (!found) {
                missing.add(ingredient);
            }
        }
        return missing;
    }

    // ------------------------------------------------------------ crafting table

    public static boolean tableNearby(ObserverEntity entity, ServerLevel level) {
        BlockPos origin = entity.blockPosition();
        for (int dx = -4; dx <= 4; dx++) {
            for (int dy = -2; dy <= 2; dy++) {
                for (int dz = -4; dz <= 4; dz++) {
                    if (level.getBlockState(origin.offset(dx, dy, dz)).is(Blocks.CRAFTING_TABLE)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static boolean ensureTable(ObserverEntity entity, ServerLevel level, int depth, Set<Item> visiting) {
        if (tableNearby(entity, level)) {
            return true;
        }
        ItemStack table = entity.inventory().find(s -> s.is(Items.CRAFTING_TABLE));
        if (table == null) {
            if (!craft(entity, level, Items.CRAFTING_TABLE, depth + 1, visiting)) {
                return false;
            }
            table = entity.inventory().find(s -> s.is(Items.CRAFTING_TABLE));
            if (table == null) {
                return false;
            }
        }
        BlockPos spot = findSpot(entity, level);
        return spot != null && BlockPlacer.place(entity, level, spot, table);
    }

    @Nullable
    private static BlockPos findSpot(ObserverEntity entity, ServerLevel level) {
        BlockPos origin = entity.blockPosition();
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                if (dx == 0 && dz == 0) {
                    continue;
                }
                BlockPos pos = origin.offset(dx, 0, dz);
                BlockPos below = pos.below();
                if (level.getBlockState(pos).isAir() && level.getBlockState(pos.above()).isAir()
                        && level.getBlockState(below).isFaceSturdy(level, below, Direction.UP)) {
                    return pos;
                }
            }
        }
        return null;
    }
}
