package com.observer.memory;

import java.util.Map;

/** How a player fights, derived from observed behaviour. Used by the boss to imitate and counter. */
public record CombatStyle(
        double rangedRatio,
        double shieldRate,
        double critRate,
        double sprintRatio,
        double jumpsPerMinute,
        int healUses,
        String weaponId,
        Map<String, String> armorBySlot) {

    public static final CombatStyle DEFAULT = new CombatStyle(0.0D, 0.0D, 0.0D, 0.3D, 4.0D, 0, "", Map.of());
}
