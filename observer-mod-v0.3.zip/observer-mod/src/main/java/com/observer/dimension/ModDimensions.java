package com.observer.dimension;

import com.observer.ObserverMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

public final class ModDimensions {
    /** observer:the_domain, defined by the data pack files in data/observer/dimension*. */
    public static final ResourceKey<Level> DOMAIN =
            ResourceKey.create(Registries.DIMENSION, new ResourceLocation(ObserverMod.MODID, "the_domain"));

    private ModDimensions() {
    }
}
