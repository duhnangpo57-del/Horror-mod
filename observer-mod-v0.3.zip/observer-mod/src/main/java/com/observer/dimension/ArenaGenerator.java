package com.observer.dimension;

import com.observer.building.Blueprint;
import com.observer.building.BlueprintAnalyzer;
import com.observer.building.BlueprintBlock;
import com.observer.memory.PlayerProfile;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.registries.ForgeRegistries;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Builds the boss arena once. The pillars are made from the blocks the player mined most;
 * floating ruins around it are copies of what the player built. It is generated structure,
 * not Observer behaviour, so it uses setBlock directly.
 */
public final class ArenaGenerator {
    public static final int FLOOR_Y = 63;
    public static final int RADIUS = 24;

    private ArenaGenerator() {
    }

    public static void generate(ServerLevel level, @Nullable PlayerProfile profile) {
        for (int cx = -4; cx <= 4; cx++) {
            for (int cz = -4; cz <= 4; cz++) {
                level.getChunk(cx, cz);
            }
        }

        BlockState dark = Blocks.POLISHED_BLACKSTONE.defaultBlockState();
        BlockState brick = Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState();
        BlockState rim = Blocks.CRYING_OBSIDIAN.defaultBlockState();
        BlockState dais = Blocks.GILDED_BLACKSTONE.defaultBlockState();

        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int x = -RADIUS; x <= RADIUS; x++) {
            for (int z = -RADIUS; z <= RADIUS; z++) {
                double d = Math.sqrt((double) x * x + (double) z * z);
                if (d > RADIUS) {
                    continue;
                }
                BlockState state;
                if (d < 4.0D) {
                    state = dais;
                } else if (d > RADIUS - 1.5D) {
                    state = rim;
                } else {
                    state = ((x + z) & 1) == 0 ? dark : brick;
                }
                level.setBlock(pos.set(x, FLOOR_Y, z), state, 2);
            }
        }

        List<BlockState> materials = pillarMaterials(level, profile);
        for (int i = 0; i < 8; i++) {
            double angle = Math.PI * 2.0D * i / 8.0D;
            int px = (int) Math.round(Math.cos(angle) * 18.0D);
            int pz = (int) Math.round(Math.sin(angle) * 18.0D);
            BlockState material = materials.get(i % materials.size());
            for (int y = 1; y <= 9; y++) {
                level.setBlock(pos.set(px, FLOOR_Y + y, pz), material, 2);
            }
            level.setBlock(pos.set(px, FLOOR_Y + 10, pz), Blocks.END_ROD.defaultBlockState(), 2);
        }

        if (profile != null) {
            Blueprint blueprint = BlueprintAnalyzer.analyze(profile, 250);
            if (blueprint != null) {
                for (int i = 0; i < 3; i++) {
                    double angle = Math.PI * 2.0D * i / 3.0D + 0.5D;
                    int ox = (int) Math.round(Math.cos(angle) * 40.0D) - blueprint.sizeX() / 2;
                    int oz = (int) Math.round(Math.sin(angle) * 40.0D) - blueprint.sizeZ() / 2;
                    placeRuin(level, blueprint, new BlockPos(ox, FLOOR_Y + 14, oz));
                }
            }
        }
    }

    private static void placeRuin(ServerLevel level, Blueprint blueprint, BlockPos origin) {
        for (BlueprintBlock b : blueprint.blocks()) {
            Block block = ForgeRegistries.BLOCKS.getValue(new ResourceLocation(b.blockId()));
            if (block == null || block == Blocks.AIR) {
                continue;
            }
            level.setBlock(origin.offset(b.x(), b.y(), b.z()), block.defaultBlockState(), 2);
        }
    }

    private static List<BlockState> pillarMaterials(ServerLevel level, @Nullable PlayerProfile profile) {
        List<BlockState> materials = new ArrayList<>();
        if (profile != null) {
            List<Map.Entry<String, Integer>> mined = new ArrayList<>(profile.getMinedBlocks().entrySet());
            mined.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));
            for (Map.Entry<String, Integer> e : mined) {
                if (materials.size() >= 8) {
                    break;
                }
                Block block = ForgeRegistries.BLOCKS.getValue(new ResourceLocation(e.getKey()));
                if (block != null && block != Blocks.AIR
                        && block.defaultBlockState().isCollisionShapeFullBlock(level, BlockPos.ZERO)) {
                    materials.add(block.defaultBlockState());
                }
            }
        }
        while (materials.size() < 8) {
            materials.add(Blocks.DEEPSLATE_BRICKS.defaultBlockState());
        }
        return materials;
    }
}
