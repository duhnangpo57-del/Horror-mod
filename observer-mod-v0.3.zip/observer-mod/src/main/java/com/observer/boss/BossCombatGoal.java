package com.observer.boss;

import com.observer.interaction.BlockPlacer;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.EnumSet;

public class BossCombatGoal extends Goal {
    private final ObserverBossEntity boss;
    private int attackCooldown;
    private int shootCooldown;
    private int strafeTicks;
    private float strafeDirection = 1.0F;
    private long vantageUntil;
    @Nullable
    private BlockPos vantage;

    public BossCombatGoal(ObserverBossEntity boss) {
        this.boss = boss;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        LivingEntity target = boss.getTarget();
        return target != null && target.isAlive();
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public void stop() {
        boss.raiseShield(false);
        boss.setSprinting(false);
        boss.getNavigation().stop();
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void tick() {
        LivingEntity target = boss.getTarget();
        if (target == null) {
            return;
        }
        boss.getLookControl().setLookAt(target, 30.0F, 30.0F);
        if (attackCooldown > 0) {
            attackCooldown--;
        }
        if (shootCooldown > 0) {
            shootCooldown--;
        }

        double distance = boss.distanceTo(target);
        BossTactic tactic = boss.tactics().current(boss, target);
        boss.setSprinting(boss.getStyle().sprintRatio() > 0.35D && tactic == BossTactic.PRESS);
        pillarTowards(target);

        switch (tactic) {
            case KITE -> kite(target, distance);
            case GUARD -> guard(target, distance);
            case VANTAGE -> vantagePoint(target, distance);
            default -> press(target, distance);
        }
    }

    private int meleeCooldown() {
        return switch (boss.getPhase()) {
            case 1 -> 20;
            case 2 -> 16;
            default -> 12;
        };
    }

    private int shootDelay() {
        return boss.getPhase() >= 3 ? 14 : 24;
    }

    private void melee(LivingEntity target) {
        if (attackCooldown > 0) {
            return;
        }
        boss.swing(InteractionHand.MAIN_HAND);
        boss.doHurtTarget(target);
        attackCooldown = meleeCooldown();
    }

    private void shoot(LivingEntity target, double distance) {
        if (shootCooldown > 0 || distance < 4.0D || distance > 28.0D || !boss.hasLineOfSight(target)) {
            return;
        }
        boss.shootArrow(target);
        shootCooldown = shootDelay();
    }

    private void press(LivingEntity target, double distance) {
        boss.raiseShield(false);
        PathNavigation nav = boss.getNavigation();
        if (distance > 2.6D) {
            nav.moveTo(target, boss.isSprinting() ? 1.35D : 1.15D);
        } else {
            nav.stop();
            melee(target);
        }
        if (boss.getStyle().jumpsPerMinute() > 8.0D && boss.onGround() && boss.getRandom().nextInt(40) == 0) {
            boss.getJumpControl().jump();
        }
    }

    private void kite(LivingEntity target, double distance) {
        boss.raiseShield(false);
        PathNavigation nav = boss.getNavigation();
        if (distance < 8.0D) {
            Vec3 away = DefaultRandomPos.getPosAway(boss, 12, 6, target.position());
            if (away != null) {
                nav.moveTo(away.x, away.y, away.z, 1.25D);
            }
            if (distance < 2.5D) {
                melee(target);
            }
        } else if (distance > 18.0D) {
            nav.moveTo(target, 1.1D);
        } else {
            nav.stop();
            if (--strafeTicks <= 0) {
                strafeTicks = 30 + boss.getRandom().nextInt(30);
                strafeDirection = -strafeDirection;
            }
            boss.getMoveControl().strafe(0.0F, 0.8F * strafeDirection);
        }
        shoot(target, distance);
    }

    private void guard(LivingEntity target, double distance) {
        PathNavigation nav = boss.getNavigation();
        if (distance > 3.2D) {
            boss.raiseShield(true);
            nav.moveTo(target, 0.95D);
        } else {
            nav.stop();
            if (attackCooldown <= 0) {
                boss.raiseShield(false);
                melee(target);
            } else {
                boss.raiseShield(true);
            }
        }
    }

    private void vantagePoint(LivingEntity target, double distance) {
        boss.raiseShield(false);
        PathNavigation nav = boss.getNavigation();
        long now = boss.level().getGameTime();
        if (distance < 4.0D) {
            melee(target);
            return;
        }
        if (vantage == null || now > vantageUntil) {
            vantage = findVantage(target);
            vantageUntil = now + 120L;
        }
        if (vantage != null && boss.distanceToSqr(Vec3.atCenterOf(vantage)) > 9.0D) {
            nav.moveTo(vantage.getX() + 0.5D, vantage.getY(), vantage.getZ() + 0.5D, 1.2D);
        } else {
            nav.stop();
        }
        shoot(target, distance);
    }

    /** The highest standable spot in a ring around the target (the arena pillars count). */
    @Nullable
    private BlockPos findVantage(LivingEntity target) {
        if (!(boss.level() instanceof ServerLevel level)) {
            return null;
        }
        BlockPos best = null;
        int bestY = boss.getBlockY();
        for (int i = 0; i < 12; i++) {
            double angle = boss.getRandom().nextDouble() * Math.PI * 2.0D;
            double radius = 6.0D + boss.getRandom().nextDouble() * 8.0D;
            int x = (int) Math.floor(target.getX() + Math.cos(angle) * radius);
            int z = (int) Math.floor(target.getZ() + Math.sin(angle) * radius);
            BlockPos column = new BlockPos(x, 0, z);
            if (!level.hasChunkAt(column)) {
                continue;
            }
            BlockPos top = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, column);
            if (top.getY() > bestY) {
                bestY = top.getY();
                best = top;
            }
        }
        return best;
    }

    /** If the target is above, jump and drop a block under the feet to climb after it. */
    private void pillarTowards(LivingEntity target) {
        if (!(boss.level() instanceof ServerLevel level)) {
            return;
        }
        double rise = target.getY() - boss.getY();
        if (rise <= 2.5D || boss.distanceTo(target) > 14.0F) {
            return;
        }
        if (boss.onGround()) {
            if (boss.getRandom().nextInt(8) == 0) {
                boss.getJumpControl().jump();
            }
        } else if (boss.getDeltaMovement().y < 0.05D) {
            BlockPos below = boss.blockPosition().below();
            if (level.getBlockState(below).isAir()
                    && BlockPlacer.place(boss, level, below, new ItemStack(Items.COBBLESTONE, 4))) {
                boss.rememberPlaced(below);
            }
        }
    }
}
