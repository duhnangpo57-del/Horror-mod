package com.observer.boss;

import com.observer.memory.CombatStyle;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;

import java.util.ArrayDeque;

/**
 * Chooses how the boss fights. Phase 1 mimics the player; phase 2 counters whatever the player
 * has actually been doing in the last 20 seconds; phase 3 mixes both and pushes harder.
 */
public final class AdaptiveTactics {
    private record Hit(int tick, boolean melee, float amount) {
    }

    private static final int WINDOW_TICKS = 400;

    private final ArrayDeque<Hit> recent = new ArrayDeque<>();
    private BossTactic current = BossTactic.PRESS;
    private int nextChange;

    public void recordPlayerDamage(int tick, boolean melee, float amount) {
        recent.addLast(new Hit(tick, melee, amount));
        while (recent.size() > 64) {
            recent.removeFirst();
        }
    }

    public BossTactic current(ObserverBossEntity boss, LivingEntity target) {
        if (boss.tickCount >= nextChange) {
            current = choose(boss, target);
            nextChange = boss.tickCount + 100 + boss.getRandom().nextInt(60);
        }
        return current;
    }

    private BossTactic choose(ObserverBossEntity boss, LivingEntity target) {
        RandomSource random = boss.getRandom();
        CombatStyle style = boss.getStyle();
        int phase = boss.getPhase();

        if (phase <= 1) {
            if (style.rangedRatio() > 0.5D) {
                return BossTactic.KITE;
            }
            if (style.shieldRate() > 0.25D) {
                boss.ensureShield();
                return BossTactic.GUARD;
            }
            return BossTactic.PRESS;
        }

        float melee = 0.0F;
        float ranged = 0.0F;
        for (Hit h : recent) {
            if (boss.tickCount - h.tick() <= WINDOW_TICKS) {
                if (h.melee()) {
                    melee += h.amount();
                } else {
                    ranged += h.amount();
                }
            }
        }

        if (phase == 2) {
            if (melee + ranged < 1.0F) {
                return BossTactic.PRESS;
            }
            if (melee > ranged * 1.5F) {
                return random.nextBoolean() ? BossTactic.KITE : BossTactic.VANTAGE; // player is melee-heavy: stay away
            }
            if (ranged > melee * 1.5F) {
                boss.ensureShield(); // player is ranged-heavy: close in behind a shield
                return BossTactic.GUARD;
            }
            return BossTactic.VANTAGE;
        }

        // phase 3: relentless
        if (boss.distanceTo(target) > 12.0F) {
            return BossTactic.KITE;
        }
        return melee > ranged * 2.0F && random.nextInt(3) == 0 ? BossTactic.VANTAGE : BossTactic.PRESS;
    }
}
