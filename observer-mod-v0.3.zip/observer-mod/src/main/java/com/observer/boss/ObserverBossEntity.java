package com.observer.boss;

import com.observer.config.ObserverConfig;
import com.observer.memory.CombatStyle;
import com.observer.memory.PlayerProfile;
import com.observer.registry.ModItems;
import com.observer.registry.ModSounds;
import com.observer.story.Dialogue;
import com.observer.story.StoryManager;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.BossEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import java.util.Optional;
import java.util.UUID;

/**
 * THE PERFECT COPY. It wears what the player wears, wields what the player wields and fights the way
 * the player has been seen fighting. In later phases it counters the player's actual habits.
 */
public class ObserverBossEntity extends Monster {
    private static final EntityDataAccessor<Optional<UUID>> DATA_COPY_OF =
            SynchedEntityData.defineId(ObserverBossEntity.class, EntityDataSerializers.OPTIONAL_UUID);
    private static final UUID SPEED_ID = UUID.fromString("5b3f2a10-7d41-4a5e-9c10-0a1b2c3d4e51");
    private static final UUID DAMAGE_ID = UUID.fromString("5b3f2a10-7d41-4a5e-9c10-0a1b2c3d4e52");

    private final ServerBossEvent bossBar = new ServerBossEvent(
            Component.translatable("entity.observer.the_copy"),
            BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.NOTCHED_10);
    private final AdaptiveTactics tactics = new AdaptiveTactics();
    private final LongArrayList placed = new LongArrayList();

    private CombatStyle style = CombatStyle.DEFAULT;
    private int phase = 1;
    private int healsLeft = 2;
    private long nextHealTick;

    public ObserverBossEntity(EntityType<? extends ObserverBossEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
        this.xpReward = 100;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 300.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.30D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.FOLLOW_RANGE, 48.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6D)
                .add(Attributes.ARMOR, 6.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_COPY_OF, Optional.empty());
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new BossCombatGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    // ------------------------------------------------------------------ setup

    @Nullable
    public UUID getCopyOf() {
        return this.entityData.get(DATA_COPY_OF).orElse(null);
    }

    public CombatStyle getStyle() {
        return style;
    }

    public int getPhase() {
        return phase;
    }

    public AdaptiveTactics tactics() {
        return tactics;
    }

    /** Becomes a copy of this player: name, skin, gear, and (if known) fighting style. */
    public void copyFrom(ServerPlayer player, @Nullable PlayerProfile profile) {
        this.entityData.set(DATA_COPY_OF, Optional.of(player.getUUID()));
        this.setCustomName(player.getName());
        this.setCustomNameVisible(true);
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            this.setItemSlot(slot, player.getItemBySlot(slot).copy());
            this.setDropChance(slot, 0.0F);
        }
        if (profile != null) {
            this.style = profile.combatStyle();
        }
        if (this.getMainHandItem().isEmpty()) {
            this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.IRON_SWORD));
        }
        if (style.shieldRate() > 0.25D) {
            ensureShield();
        }
    }

    /** Scales health and damage by the config. */
    public void applyDifficulty() {
        double scale = ObserverConfig.BOSS_DIFFICULTY.get();
        AttributeInstance health = getAttribute(Attributes.MAX_HEALTH);
        AttributeInstance damage = getAttribute(Attributes.ATTACK_DAMAGE);
        if (health != null) {
            health.setBaseValue(ObserverConfig.BOSS_BASE_HEALTH.get() * scale);
        }
        if (damage != null) {
            damage.setBaseValue(ObserverConfig.BOSS_BASE_DAMAGE.get() * scale);
        }
        this.setHealth(this.getMaxHealth());
    }

    // ------------------------------------------------------------------ combat helpers

    public boolean hasShield() {
        return this.getOffhandItem().getItem() instanceof ShieldItem;
    }

    public void ensureShield() {
        if (this.getOffhandItem().isEmpty()) {
            this.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.SHIELD));
            this.setDropChance(EquipmentSlot.OFFHAND, 0.0F);
        }
    }

    public void raiseShield(boolean up) {
        if (!hasShield()) {
            return;
        }
        if (up && !this.isUsingItem()) {
            this.startUsingItem(InteractionHand.OFF_HAND);
        } else if (!up && this.isUsingItem()) {
            this.stopUsingItem();
        }
    }

    public void shootArrow(LivingEntity target) {
        Arrow arrow = new Arrow(this.level(), this);
        double dx = target.getX() - this.getX();
        double dy = target.getY(0.3333333333333333D) - arrow.getY();
        double dz = target.getZ() - this.getZ();
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        arrow.setBaseDamage(ObserverConfig.BOSS_BASE_DAMAGE.get() * ObserverConfig.BOSS_DIFFICULTY.get() / 3.0D);
        arrow.pickup = AbstractArrow.Pickup.DISALLOWED;
        arrow.shoot(dx, dy + horizontal * 0.2D, dz, 1.8F, phase >= 3 ? 2.0F : 5.0F);
        this.playSound(SoundEvents.SKELETON_SHOOT, 1.0F, 1.0F / (this.getRandom().nextFloat() * 0.4F + 0.8F));
        this.level().addFreshEntity(arrow);
    }

    public void rememberPlaced(BlockPos pos) {
        if (placed.size() < 512) {
            placed.add(pos.asLong());
        }
    }

    private void cleanupPlaced() {
        if (this.level() instanceof ServerLevel level) {
            for (int i = 0; i < placed.size(); i++) {
                BlockPos pos = BlockPos.of(placed.getLong(i));
                BlockState state = level.getBlockState(pos);
                if (state.is(Blocks.COBBLESTONE)) {
                    level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
                }
            }
        }
        placed.clear();
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean hurt = super.hurt(source, amount);
        if (hurt && source.getEntity() instanceof Player) {
            tactics.recordPlayerDamage(this.tickCount, source.getDirectEntity() == source.getEntity(), amount);
        }
        return hurt;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            return;
        }
        bossBar.setProgress(Math.max(0.0F, Math.min(1.0F, this.getHealth() / this.getMaxHealth())));
        updatePhase();
        tryHeal();
        if (this.tickCount % 100 == 0 && this.level().getNearestPlayer(this, 96.0D) == null) {
            this.discard(); // nobody left to fight
        }
    }

    private void updatePhase() {
        float ratio = this.getHealth() / this.getMaxHealth();
        int target = ratio > 0.66F ? 1 : ratio > 0.33F ? 2 : 3;
        if (target <= phase) {
            return;
        }
        phase = target;
        applyPhaseModifiers();
        bossBar.setColor(phase == 2 ? BossEvent.BossBarColor.YELLOW : BossEvent.BossBarColor.RED);
        if (this.level() instanceof ServerLevel level) {
            level.sendParticles(ParticleTypes.SOUL, this.getX(), this.getY() + 1.0D, this.getZ(), 40, 0.6D, 0.9D, 0.6D, 0.05D);
            level.playSound(null, this.blockPosition(), ModSounds.BOSS_PHASE.get(),
                    net.minecraft.sounds.SoundSource.HOSTILE, 1.5F, 1.0F);
            for (Player p : level.players()) {
                if (p instanceof ServerPlayer sp && sp.distanceToSqr(this) < 64.0D * 64.0D) {
                    Dialogue.say(sp, "story.observer.boss.phase" + phase);
                }
            }
        }
    }

    private void applyPhaseModifiers() {
        AttributeInstance speed = getAttribute(Attributes.MOVEMENT_SPEED);
        AttributeInstance damage = getAttribute(Attributes.ATTACK_DAMAGE);
        if (speed != null) {
            speed.removeModifier(SPEED_ID);
            if (phase >= 2) {
                speed.addTransientModifier(new AttributeModifier(SPEED_ID, "observer_phase_speed",
                        phase == 2 ? 0.10D : 0.25D, AttributeModifier.Operation.MULTIPLY_BASE));
            }
        }
        if (damage != null) {
            damage.removeModifier(DAMAGE_ID);
            if (phase >= 2) {
                damage.addTransientModifier(new AttributeModifier(DAMAGE_ID, "observer_phase_damage",
                        phase == 2 ? 0.15D : 0.35D, AttributeModifier.Operation.MULTIPLY_BASE));
            }
        }
    }

    /** Uses a healing item the way the player has been seen to, at most twice. */
    private void tryHeal() {
        if (healsLeft <= 0 || style.healUses() <= 0 || this.tickCount < nextHealTick) {
            return;
        }
        if (this.getHealth() < this.getMaxHealth() * 0.4F) {
            healsLeft--;
            nextHealTick = this.tickCount + 400L;
            this.heal(this.getMaxHealth() * 0.15F);
            this.playSound(SoundEvents.GENERIC_EAT, 1.0F, 1.0F);
            if (this.level() instanceof ServerLevel level) {
                level.sendParticles(ParticleTypes.HEART, this.getX(), this.getY() + 2.0D, this.getZ(), 6, 0.3D, 0.3D, 0.3D, 0.0D);
            }
        }
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (this.level() instanceof ServerLevel level) {
            cleanupPlaced();
            StoryManager.onBossDefeated(level);
        }
    }

    @Override
    protected void dropCustomDeathLoot(DamageSource source, int looting, boolean recentlyHit) {
        super.dropCustomDeathLoot(source, looting, recentlyHit);
        this.spawnAtLocation(new ItemStack(ModItems.MEMORY_SHARD.get()));
    }

    @Override
    public void remove(Entity.RemovalReason reason) {
        if (!this.level().isClientSide) {
            bossBar.removeAllPlayers();
            if (reason.shouldDestroy()) {
                cleanupPlaced();
            }
        }
        super.remove(reason);
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossBar.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossBar.removePlayer(player);
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    protected boolean shouldDespawnInPeaceful() {
        return false;
    }

    @Override
    public boolean canChangeDimensions() {
        return false;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        UUID copy = getCopyOf();
        if (copy != null) {
            tag.putUUID("CopyOf", copy);
        }
        tag.putInt("Phase", phase);
        tag.putInt("HealsLeft", healsLeft);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("CopyOf")) {
            this.entityData.set(DATA_COPY_OF, Optional.of(tag.getUUID("CopyOf")));
        }
        phase = Math.max(1, Math.min(3, tag.getInt("Phase")));
        healsLeft = tag.contains("HealsLeft") ? tag.getInt("HealsLeft") : 2;
        applyPhaseModifiers();
        if (this.hasCustomName()) {
            bossBar.setName(this.getDisplayName());
        }
    }

    @Override
    public void setCustomName(@Nullable Component name) {
        super.setCustomName(name);
        bossBar.setName(this.getDisplayName());
    }
}
