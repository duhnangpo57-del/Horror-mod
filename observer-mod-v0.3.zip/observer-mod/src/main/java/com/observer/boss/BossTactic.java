package com.observer.boss;

public enum BossTactic {
    /** Close in and fight in melee. */
    PRESS,
    /** Keep distance and shoot. */
    KITE,
    /** Shield up, advance slowly, counter-attack. */
    GUARD,
    /** Take high ground (pillars) and shoot from there. */
    VANTAGE
}
