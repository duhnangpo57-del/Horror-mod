package com.observer.interaction;

import com.observer.entity.ObserverEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Breaks one block at a time the way a player does: walk into reach, look at it,
 * pick the right tool, accumulate progress by hardness and tool speed, show the crack
 * animation, then destroy it and collect the drops into the real inventory.
 */
public final class BlockBreaker {
    public enum Result { RUNNING, DONE, FAILED }

    private static final double REACH_SQR = 4.5D * 4.5D;
    private static final int TIMEOUT_TICKS = 900;

    private final ObserverEntity entity;
    @Nullable
    private BlockPos target;
    private float progress;
    private int stage = -1;
    private int elapsedTotal;
    private int swingTimer;

    public BlockBreaker(ObserverEntity entity) {
        this.entity = entity;
    }

    public boolean isActive() {
        return target != null;
    }

    @Nullable
    public BlockPos target() {
        return target;
    }

    public void begin(BlockPos pos) {
        clearCrack();
        target = pos.immutable();
        progress = 0.0F;
        stage = -1;
        elapsedTotal = 0;
        swingTimer = 0;
    }

    public void cancel() {
        clearCrack();
        target = null;
        progress = 0.0F;
        stage = -1;
    }

    private void clearCrack() {
        if (target != null && entity.level() instanceof ServerLevel level) {
            level.destroyBlockProgress(entity.getId(), target, -1);
        }
    }

    public Result tick(ServerLevel level, int elapsed) {
        if (target == null) {
            return Result.FAILED;
        }
        BlockPos pos = target;
        BlockState state = level.getBlockState(pos);
        if (state.isAir()) {
            cancel();
            return Result.DONE;
        }
        if (!BlockRules.canBreak(entity, level, pos, state)) {
            cancel();
            return Result.FAILED;
        }
        elapsedTotal += elapsed;
        if (elapsedTotal > TIMEOUT_TICKS) {
            cancel();
            return Result.FAILED;
        }

        Vec3 eye = entity.getEyePosition();
        Vec3 center = Vec3.atCenterOf(pos);
        if (eye.distanceToSqr(center) > REACH_SQR) {
            PathNavigation nav = entity.getNavigation();
            if (nav.isDone()) {
                nav.moveTo(center.x, center.y, center.z, 1.0D);
            }
            return Result.RUNNING;
        }
        entity.getNavigation().stop();

        // Only break what can actually be reached; dig through whatever is in the way.
        BlockHitResult hit = level.clip(new ClipContext(eye, center,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, entity));
        if (hit.getType() == HitResult.Type.BLOCK && !hit.getBlockPos().equals(pos)) {
            BlockPos blocker = hit.getBlockPos();
            if (BlockRules.canBreak(entity, level, blocker, level.getBlockState(blocker))) {
                int keep = elapsedTotal;
                begin(blocker);
                elapsedTotal = keep;
                return Result.RUNNING;
            }
            cancel();
            return Result.FAILED;
        }

        entity.getLookControl().setLookAt(center.x, center.y, center.z);
        entity.inventory().equipBestTool(state);
        ItemStack tool = entity.getMainHandItem();

        float hardness = state.getDestroySpeed(level, pos);
        boolean correct = !state.requiresCorrectToolForDrops() || tool.isCorrectToolForDrops(state);
        float speed = Math.max(1.0F, tool.getDestroySpeed(state));
        float perTick = hardness <= 0.0F ? 1.0F : speed / hardness / (correct ? 30.0F : 100.0F);
        progress += perTick * elapsed;

        swingTimer += elapsed;
        if (swingTimer >= 6) {
            swingTimer = 0;
            entity.swing(InteractionHand.MAIN_HAND);
            level.playSound(null, pos, state.getSoundType().getHitSound(), SoundSource.BLOCKS, 0.6F, 0.75F);
        }

        int newStage = Math.max(0, Math.min(9, (int) (progress * 10.0F)));
        if (newStage != stage) {
            stage = newStage;
            level.destroyBlockProgress(entity.getId(), pos, stage);
        }

        if (progress >= 1.0F) {
            finish(level, pos, state, tool, correct);
            return Result.DONE;
        }
        return Result.RUNNING;
    }

    private void finish(ServerLevel level, BlockPos pos, BlockState state, ItemStack tool, boolean correct) {
        List<ItemStack> drops = correct
                ? Block.getDrops(state, level, pos, null, entity, tool)
                : List.of();
        level.destroyBlockProgress(entity.getId(), pos, -1);
        level.destroyBlock(pos, false, entity);
        for (ItemStack drop : drops) {
            entity.inventory().add(drop);
        }
        tool.hurtAndBreak(1, entity, e -> e.broadcastBreakEvent(EquipmentSlot.MAINHAND));
        entity.noteBlockBroken(level.getGameTime());
        target = null;
        progress = 0.0F;
        stage = -1;
    }
}
