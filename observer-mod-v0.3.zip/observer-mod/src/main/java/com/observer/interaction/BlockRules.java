package com.observer.interaction;

import com.observer.config.ObserverConfig;
import com.observer.entity.ObserverEntity;
import com.observer.memory.ObserverMemoryData;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.ForgeEventFactory;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.List;

/** Every safety rule for breaking blocks lives here. */
public final class BlockRules {
    private BlockRules() {
    }

    public static boolean canBreak(ObserverEntity entity, ServerLevel level, BlockPos pos, BlockState state) {
        if (!ObserverConfig.ALLOW_BLOCK_BREAKING.get()) {
            return false;
        }
        if (state.isAir() || !state.getFluidState().isEmpty()) {
            return false;
        }
        if (state.getDestroySpeed(level, pos) < 0.0F) {
            return false; // unbreakable
        }
        if (level.getBlockEntity(pos) != null) {
            return false; // chests, furnaces, signs... are never broken
        }
        ResourceLocation id = ForgeRegistries.BLOCKS.getKey(state.getBlock());
        if (id == null) {
            return false;
        }
        String name = id.toString();
        if (ObserverConfig.BLOCK_BLACKLIST.get().contains(name)) {
            return false;
        }
        List<? extends String> whitelist = ObserverConfig.BLOCK_WHITELIST.get();
        if (!whitelist.isEmpty() && !whitelist.contains(name)) {
            return false;
        }
        if (ObserverConfig.RESPECT_MOB_GRIEFING.get() && !ForgeEventFactory.getMobGriefingEvent(level, entity)) {
            return false;
        }
        if (ObserverConfig.PROTECT_PLAYER_BUILDS.get() && level.dimension() == Level.OVERWORLD
                && ObserverMemoryData.get(level.getServer()).isPlayerPlaced(pos)) {
            return false;
        }
        return entity.canBreakMoreBlocks(level.getGameTime());
    }
}
