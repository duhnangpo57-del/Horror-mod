package com.observer.interaction;

import com.observer.entity.ObserverEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;

import javax.annotation.Nullable;
import java.util.function.Predicate;

public final class ItemCollector {
    private ItemCollector() {
    }

    /** Picks up item entities touching the Observer. */
    public static void pickup(ObserverEntity entity, ServerLevel level) {
        AABB box = entity.getBoundingBox().inflate(1.6D, 0.6D, 1.6D);
        for (ItemEntity item : level.getEntitiesOfClass(ItemEntity.class, box, i -> i.isAlive() && !i.hasPickUpDelay())) {
            ItemStack stack = item.getItem();
            if (stack.isEmpty()) {
                continue;
            }
            entity.inventory().add(stack.copy());
            item.discard();
            level.playSound(null, entity.blockPosition(), SoundEvents.ITEM_PICKUP, SoundSource.NEUTRAL,
                    0.2F, 1.0F + level.random.nextFloat() * 0.5F);
        }
    }

    @Nullable
    public static ItemEntity nearest(ObserverEntity entity, ServerLevel level, double radius, Predicate<ItemStack> wanted) {
        ItemEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (ItemEntity item : level.getEntitiesOfClass(ItemEntity.class, entity.getBoundingBox().inflate(radius),
                i -> i.isAlive() && wanted.test(i.getItem()))) {
            double d = entity.distanceToSqr(item);
            if (d < bestDist) {
                bestDist = d;
                best = item;
            }
        }
        return best;
    }
}
