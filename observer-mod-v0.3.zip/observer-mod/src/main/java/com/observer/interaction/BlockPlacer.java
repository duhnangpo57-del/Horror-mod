package com.observer.interaction;

import com.observer.config.ObserverConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Places a block through the normal BlockItem pipeline, so block states, support rules,
 * sounds and multi-block items (doors, beds) behave exactly like vanilla.
 */
public final class BlockPlacer {
    private BlockPlacer() {
    }

    /** @param stack the REAL stack to consume one item from. */
    public static boolean place(Mob mob, ServerLevel level, BlockPos target, ItemStack stack) {
        if (!ObserverConfig.ALLOW_BLOCK_PLACING.get()) {
            return false;
        }
        if (stack.isEmpty() || !(stack.getItem() instanceof BlockItem blockItem)) {
            return false;
        }
        if (!level.isInWorldBounds(target) || !level.getWorldBorder().isWithinBounds(target)) {
            return false;
        }
        if (!level.getBlockState(target).canBeReplaced()) {
            return false;
        }
        BlockHitResult hit = new BlockHitResult(Vec3.atCenterOf(target), Direction.UP, target, false);
        BlockPlaceContext context = new BlockPlaceContext(level, null, InteractionHand.MAIN_HAND, stack, hit);
        if (!context.canPlace()) {
            return false;
        }
        InteractionResult result = blockItem.place(context);
        if (result.consumesAction()) {
            mob.swing(InteractionHand.MAIN_HAND);
            return true;
        }
        return false;
    }
}
