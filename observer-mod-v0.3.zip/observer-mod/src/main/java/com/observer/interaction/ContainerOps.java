package com.observer.interaction;

import com.observer.config.ObserverConfig;
import com.observer.entity.ObserverEntity;
import com.observer.memory.ObserverMemoryData;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;

import javax.annotation.Nullable;
import java.util.function.Predicate;

/** Looting of containers that no player has used or placed. */
public final class ContainerOps {
    private ContainerOps() {
    }

    /** Nearest untouched container holding something wanted. */
    @Nullable
    public static BlockPos findLootable(ObserverEntity entity, ServerLevel level, int radius, Predicate<ItemStack> wanted) {
        if (!ObserverConfig.ALLOW_CONTAINER_LOOTING.get()) {
            return null;
        }
        BlockPos origin = entity.blockPosition();
        ObserverMemoryData memory = ObserverMemoryData.get(level.getServer());
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        int minCx = (origin.getX() - radius) >> 4;
        int maxCx = (origin.getX() + radius) >> 4;
        int minCz = (origin.getZ() - radius) >> 4;
        int maxCz = (origin.getZ() + radius) >> 4;
        for (int cx = minCx; cx <= maxCx; cx++) {
            for (int cz = minCz; cz <= maxCz; cz++) {
                LevelChunk chunk = level.getChunkSource().getChunkNow(cx, cz);
                if (chunk == null) {
                    continue;
                }
                for (BlockPos pos : chunk.getBlockEntitiesPos()) {
                    double d = origin.distSqr(pos);
                    if (d > (double) radius * radius || d >= bestDist) {
                        continue;
                    }
                    BlockEntity be = level.getBlockEntity(pos);
                    if (!(be instanceof Container container)) {
                        continue;
                    }
                    if (level.dimension() == Level.OVERWORLD && memory.isPlayerContainer(pos)) {
                        continue;
                    }
                    if (containsWanted(container, wanted)) {
                        best = pos.immutable();
                        bestDist = d;
                    }
                }
            }
        }
        return best;
    }

    private static boolean containsWanted(Container container, Predicate<ItemStack> wanted) {
        for (int i = 0; i < container.getContainerSize(); i++) {
            ItemStack s = container.getItem(i);
            if (!s.isEmpty() && wanted.test(s)) {
                return true;
            }
        }
        return false;
    }

    /** Takes up to maxItems wanted items. Returns how many were taken. */
    public static int loot(ObserverEntity entity, ServerLevel level, BlockPos pos, Predicate<ItemStack> wanted, int maxItems) {
        if (!(level.getBlockEntity(pos) instanceof Container container)) {
            return 0;
        }
        level.playSound(null, pos, SoundEvents.CHEST_OPEN, SoundSource.BLOCKS, 0.6F, 0.9F);
        int taken = 0;
        for (int i = 0; i < container.getContainerSize() && taken < maxItems; i++) {
            ItemStack s = container.getItem(i);
            if (s.isEmpty() || !wanted.test(s)) {
                continue;
            }
            int n = Math.min(s.getCount(), maxItems - taken);
            entity.inventory().add(s.split(n));
            taken += n;
        }
        container.setChanged();
        level.playSound(null, pos, SoundEvents.CHEST_CLOSE, SoundSource.BLOCKS, 0.5F, 0.9F);
        return taken;
    }
}
