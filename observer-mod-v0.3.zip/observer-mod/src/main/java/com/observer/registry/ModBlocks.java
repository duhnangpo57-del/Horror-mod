package com.observer.registry;

import com.observer.ObserverMod;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, ObserverMod.MODID);

    public static final RegistryObject<Block> DOMAIN_GATE = BLOCKS.register("domain_gate", () ->
            new DomainGateBlock(BlockBehaviour.Properties.of()
                    .strength(-1.0F, 3600000.0F)
                    .lightLevel(state -> 9)
                    .sound(SoundType.AMETHYST)
                    .noLootTable()));

    private ModBlocks() {
    }
}
