package com.observer.registry;

import com.observer.ObserverMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Custom sound events; the actual audio is mapped in assets/observer/sounds.json. */
public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, ObserverMod.MODID);

    public static final RegistryObject<SoundEvent> DOMAIN_AMBIENT = register("ambient.domain");
    public static final RegistryObject<SoundEvent> HEARTBEAT = register("ambient.heartbeat");
    public static final RegistryObject<SoundEvent> BOSS_PHASE = register("boss.phase");

    private ModSounds() {
    }

    private static RegistryObject<SoundEvent> register(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(ObserverMod.MODID, name)));
    }
}
