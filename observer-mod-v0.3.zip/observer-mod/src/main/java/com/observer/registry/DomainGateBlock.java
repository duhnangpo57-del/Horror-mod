package com.observer.registry;

import com.observer.dimension.DomainManager;
import com.observer.dimension.ModDimensions;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/** A monolith that opens the way into observer:the_domain (and back out, once the fight is over). */
public class DomainGateBlock extends Block {
    public DomainGateBlock(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (!level.isClientSide && player instanceof ServerPlayer serverPlayer) {
            if (level.dimension() == ModDimensions.DOMAIN) {
                DomainManager.leaveIfAllowed(serverPlayer);
            } else {
                DomainManager.enter(serverPlayer);
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
