package com.observer.ai;

import com.observer.building.Blueprint;
import com.observer.building.BlueprintAnalyzer;
import com.observer.building.BlueprintLibrary;
import com.observer.building.BuildSites;
import com.observer.building.ConstructionTask;
import com.observer.entity.ObserverEntity;
import com.observer.memory.HabitSummary;
import com.observer.memory.PlayerProfile;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.ChunkPos;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/** Building: a survival shelter, and a replica inspired by what the player built. */
final class BuildActions {
    private BuildActions() {
    }

    static List<GoapAction> createAll() {
        List<GoapAction> list = new ArrayList<>();
        list.add(new BuildShelter());
        list.add(new BuildReplica());
        return list;
    }

    private abstract static class BuildAction extends GoapAction {
        private final String taskName;
        private long startedAt;
        private boolean failed;

        BuildAction(String name, String taskName, int pre, int effect) {
            super(name, pre, effect, 0, 4.0F);
            this.taskName = taskName;
        }

        @Nullable
        abstract ConstructionTask createTask(ObserverBrain brain, ObserverContext ctx);

        abstract void onDone(ObserverBrain brain, ConstructionTask task);

        @Override
        public void start(ObserverBrain brain, ObserverContext ctx) {
            startedAt = ctx.gameTime();
            failed = false;
            ConstructionTask existing = brain.task();
            if (existing == null || !taskName.equals(existing.name())) {
                ConstructionTask created = createTask(brain, ctx);
                if (created == null) {
                    failed = true;
                }
                brain.setTask(created);
            }
        }

        @Override
        public NodeStatus tick(ObserverBrain brain, ObserverContext ctx) {
            ConstructionTask task = brain.task();
            if (failed || task == null || ctx.gameTime() - startedAt > 8000L) {
                return NodeStatus.FAILURE;
            }
            ConstructionTask.Status status = task.tick(brain.entity(), ctx.level(), brain.interval());
            switch (status) {
                case NEED_MATERIALS:
                    return NodeStatus.FAILURE; // the planner will go and gather more, then resume this task
                case DONE:
                    onDone(brain, task);
                    brain.setTask(null);
                    return NodeStatus.SUCCESS;
                default:
                    return NodeStatus.RUNNING;
            }
        }

        @Override
        public void stop(ObserverBrain brain) {
            brain.entity().breaker().cancel();
        }
    }

    private static final class BuildShelter extends BuildAction {
        BuildShelter() {
            super("build_shelter", "shelter", Facts.HAS_BLOCKS, Facts.SHELTER_BUILT);
        }

        @Override
        @Nullable
        ConstructionTask createTask(ObserverBrain brain, ObserverContext ctx) {
            ObserverEntity entity = brain.entity();
            Blueprint blueprint = BlueprintLibrary.shelter();
            BlockPos origin = BuildSites.findFlat(ctx.level(), entity.blockPosition(),
                    blueprint.sizeX(), blueprint.sizeZ(), 2, 16, entity.getRandom());
            return origin == null ? null : ConstructionTask.create(blueprint, origin);
        }

        @Override
        void onDone(ObserverBrain brain, ConstructionTask task) {
            brain.setShelterPos(task.origin());
        }
    }

    private static final class BuildReplica extends BuildAction {
        BuildReplica() {
            super("build_replica", "player_build", Facts.HAS_BLOCKS | Facts.SHELTER_BUILT, Facts.REPLICA_BUILT);
        }

        @Override
        @Nullable
        ConstructionTask createTask(ObserverBrain brain, ObserverContext ctx) {
            PlayerProfile profile = ctx.profile();
            if (profile == null) {
                return null;
            }
            Blueprint blueprint = BlueprintAnalyzer.analyze(profile, 80);
            if (blueprint == null) {
                return null;
            }
            ObserverEntity entity = brain.entity();
            ServerLevel level = ctx.level();
            BlockPos around = entity.blockPosition();
            HabitSummary habits = ctx.habits();
            if (habits.hasHome()) {
                ChunkPos home = habits.homeChunk();
                BlockPos candidate = new BlockPos(home.getMiddleBlockX() + 24, entity.getBlockY(), home.getMiddleBlockZ() + 24);
                if (level.hasChunkAt(candidate)) {
                    around = candidate;
                }
            }
            BlockPos origin = BuildSites.findFlat(level, around, blueprint.sizeX(), blueprint.sizeZ(), 3, 20, entity.getRandom());
            return origin == null ? null : ConstructionTask.create(blueprint, origin);
        }

        @Override
        void onDone(ObserverBrain brain, ConstructionTask task) {
            brain.setReplicaBuilt(true);
        }
    }
}
