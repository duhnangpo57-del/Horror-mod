package com.observer.ai;

/** High-level intentions chosen by Utility AI; each is a GOAP goal mask. */
public enum ObserverGoal {
    STALK(Facts.OBSERVING),
    INVESTIGATE(Facts.SCANNED),
    WANDER(Facts.WANDERED),
    GEAR_UP(Facts.HAS_STONE_TOOLS),
    FEED(Facts.HAS_FOOD),
    SHELTER(Facts.SHELTER_BUILT),
    REPLICA(Facts.REPLICA_BUILT);

    private final int mask;

    ObserverGoal(int mask) {
        this.mask = mask;
    }

    public int mask() {
        return mask;
    }
}
