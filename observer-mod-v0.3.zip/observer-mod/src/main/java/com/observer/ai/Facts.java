package com.observer.ai;

/** World-state bit flags used by the GOAP planner. */
public final class Facts {
    // watching
    public static final int KNOWS_TARGET = 1;
    public static final int IN_WATCH_RANGE = 1 << 1;
    public static final int HIDDEN = 1 << 2;
    public static final int OBSERVING = 1 << 3;
    public static final int HAS_SITE = 1 << 4;
    public static final int AT_SITE = 1 << 5;
    public static final int SCANNED = 1 << 6;
    public static final int WANDERED = 1 << 7;
    // survival (derived from the real inventory every time a plan is made)
    public static final int HAS_LOGS = 1 << 8;
    public static final int HAS_WOOD_TOOLS = 1 << 9;
    public static final int HAS_STONE = 1 << 10;
    public static final int HAS_STONE_TOOLS = 1 << 11;
    public static final int HAS_FOOD = 1 << 12;
    public static final int HAS_BLOCKS = 1 << 13;
    public static final int SHELTER_BUILT = 1 << 14;
    public static final int REPLICA_BUILT = 1 << 15;

    private Facts() {
    }
}
