package com.observer.ai;

import com.observer.config.ObserverConfig;
import com.observer.entity.ObserverEntity;
import com.observer.interaction.BlockBreaker;
import com.observer.interaction.ContainerOps;
import com.observer.interaction.ItemCollector;
import com.observer.survival.Crafter;
import com.observer.survival.ObserverInventory;
import com.observer.survival.ResourceScanner;
import com.observer.survival.SurvivalPlanner;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.Chicken;
import net.minecraft.world.entity.animal.Cow;
import net.minecraft.world.entity.animal.Pig;
import net.minecraft.world.entity.animal.Rabbit;
import net.minecraft.world.entity.animal.Sheep;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;

/** Gathering, crafting and feeding. Every step really mines, crafts or hunts. */
final class SurvivalActions {
    private SurvivalActions() {
    }

    static List<GoapAction> createAll() {
        List<GoapAction> list = new ArrayList<>();
        list.add(new Gather("gather_logs", 0, Facts.HAS_LOGS, 4.0F, 3000L,
                s -> s.is(BlockTags.LOGS),
                b -> SurvivalPlanner.woodUnits(b.entity().inventory()) >= 14));
        list.add(new CraftWoodTools());
        list.add(new Gather("gather_stone", Facts.HAS_WOOD_TOOLS, Facts.HAS_STONE, 4.0F, 3000L,
                SurvivalActions::isStone,
                b -> b.entity().inventory().count(SurvivalPlanner::isStoneMaterial) >= 24));
        list.add(new CraftStoneTools());
        list.add(new HuntFood());
        list.add(new Gather("gather_blocks", Facts.HAS_WOOD_TOOLS, Facts.HAS_BLOCKS, 4.0F, 4000L,
                s -> isStone(s) || s.is(BlockTags.DIRT),
                b -> b.entity().inventory().count(SurvivalPlanner::isBuildMaterial) >= b.blockQuota() + 8));
        return list;
    }

    private static boolean isStone(BlockState s) {
        return s.is(Blocks.STONE) || s.is(Blocks.COBBLESTONE) || s.is(Blocks.DEEPSLATE);
    }

    static void explore(ObserverEntity entity) {
        PathNavigation nav = entity.getNavigation();
        if (nav.isDone()) {
            Vec3 target = DefaultRandomPos.getPos(entity, 16, 6);
            if (target != null) {
                nav.moveTo(target.x, target.y, target.z, 1.0D);
            }
        }
    }

    // ------------------------------------------------------------------ gathering

    private static final class Gather extends GoapAction {
        private final long timeout;
        private final Predicate<BlockState> targets;
        private final Predicate<ObserverBrain> done;
        private final Set<Long> ignored = new HashSet<>();
        private long startedAt;
        private int searchFails;

        Gather(String name, int pre, int effect, float cost, long timeout,
               Predicate<BlockState> targets, Predicate<ObserverBrain> done) {
            super(name, pre, effect, 0, cost);
            this.timeout = timeout;
            this.targets = targets;
            this.done = done;
        }

        @Override
        public void start(ObserverBrain brain, ObserverContext ctx) {
            startedAt = ctx.gameTime();
            searchFails = 0;
            ignored.clear();
            brain.entity().breaker().cancel();
        }

        @Override
        public NodeStatus tick(ObserverBrain brain, ObserverContext ctx) {
            ObserverEntity entity = brain.entity();
            if (done.test(brain)) {
                entity.breaker().cancel();
                return NodeStatus.SUCCESS;
            }
            if (ctx.gameTime() - startedAt > timeout) {
                entity.breaker().cancel();
                return NodeStatus.FAILURE;
            }
            if (!entity.breaker().isActive()) {
                BlockPos found = ResourceScanner.find(ctx.level(), entity, ObserverConfig.SCAN_RADIUS.get(), targets, ignored);
                if (found == null) {
                    explore(entity);
                    return ++searchFails > 80 ? NodeStatus.FAILURE : NodeStatus.RUNNING;
                }
                searchFails = 0;
                entity.breaker().begin(found);
            }
            BlockPos current = entity.breaker().target();
            BlockBreaker.Result result = entity.breaker().tick(ctx.level(), brain.interval());
            if (result == BlockBreaker.Result.FAILED && current != null) {
                ignored.add(current.asLong());
            }
            return NodeStatus.RUNNING;
        }

        @Override
        public void stop(ObserverBrain brain) {
            brain.entity().breaker().cancel();
        }
    }

    // ------------------------------------------------------------------ crafting

    private static final class CraftWoodTools extends GoapAction {
        CraftWoodTools() {
            super("craft_wood_tools", Facts.HAS_LOGS, Facts.HAS_WOOD_TOOLS, 0, 2.0F);
        }

        @Override
        public NodeStatus tick(ObserverBrain brain, ObserverContext ctx) {
            ObserverEntity entity = brain.entity();
            ObserverInventory inv = entity.inventory();
            ServerLevel level = ctx.level();
            if (!SurvivalPlanner.hasPickaxe(inv, 0) && !Crafter.craft(entity, level, Items.WOODEN_PICKAXE)) {
                return NodeStatus.FAILURE;
            }
            if (!SurvivalPlanner.hasAxe(inv, 0) && !Crafter.craft(entity, level, Items.WOODEN_AXE)) {
                return NodeStatus.FAILURE;
            }
            if (!SurvivalPlanner.hasSword(inv, 0)) {
                Crafter.craft(entity, level, Items.WOODEN_SWORD); // nice to have
            }
            return NodeStatus.SUCCESS;
        }
    }

    private static final class CraftStoneTools extends GoapAction {
        CraftStoneTools() {
            super("craft_stone_tools", Facts.HAS_LOGS | Facts.HAS_STONE | Facts.HAS_WOOD_TOOLS,
                    Facts.HAS_STONE_TOOLS, 0, 2.0F);
        }

        @Override
        public NodeStatus tick(ObserverBrain brain, ObserverContext ctx) {
            ObserverEntity entity = brain.entity();
            ObserverInventory inv = entity.inventory();
            ServerLevel level = ctx.level();
            if (!SurvivalPlanner.hasPickaxe(inv, 1) && !Crafter.craft(entity, level, Items.STONE_PICKAXE)) {
                return NodeStatus.FAILURE;
            }
            if (!SurvivalPlanner.hasSword(inv, 1) && !Crafter.craft(entity, level, Items.STONE_SWORD)) {
                return NodeStatus.FAILURE;
            }
            if (!SurvivalPlanner.hasAxe(inv, 1)) {
                Crafter.craft(entity, level, Items.STONE_AXE); // nice to have
            }
            entity.inventory().equipBestArmor();
            return NodeStatus.SUCCESS;
        }
    }

    // ------------------------------------------------------------------ food

    private static final class HuntFood extends GoapAction {
        private long startedAt;
        private int attackCooldown;
        private int searchFails;
        private boolean looted;
        @Nullable
        private Animal prey;
        @Nullable
        private BlockPos lootSite;

        HuntFood() {
            super("hunt_food", 0, Facts.HAS_FOOD, 0, 3.0F);
        }

        @Override
        public void start(ObserverBrain brain, ObserverContext ctx) {
            startedAt = ctx.gameTime();
            attackCooldown = 0;
            searchFails = 0;
            looted = false;
            prey = null;
            lootSite = null;
        }

        @Override
        public NodeStatus tick(ObserverBrain brain, ObserverContext ctx) {
            ObserverEntity entity = brain.entity();
            ServerLevel level = ctx.level();
            if (entity.inventory().count(SurvivalPlanner::isFood) >= 4) {
                return NodeStatus.SUCCESS;
            }
            if (ctx.gameTime() - startedAt > 3000L) {
                return NodeStatus.FAILURE;
            }
            PathNavigation nav = entity.getNavigation();

            // 1. food lying on the ground (drops from a kill)
            ItemEntity drop = ItemCollector.nearest(entity, level, 12.0D, SurvivalPlanner::isFood);
            if (drop != null) {
                if (nav.isDone()) {
                    nav.moveTo(drop, 1.1D);
                }
                return NodeStatus.RUNNING;
            }

            // 2. a container nobody has touched
            if (!looted) {
                if (lootSite == null) {
                    lootSite = ContainerOps.findLootable(entity, level, 16, SurvivalPlanner::isFood);
                    if (lootSite == null) {
                        looted = true;
                    }
                }
                if (lootSite != null) {
                    if (entity.distanceToSqr(Vec3.atCenterOf(lootSite)) > 9.0D) {
                        if (nav.isDone()) {
                            nav.moveTo(lootSite.getX() + 0.5D, lootSite.getY(), lootSite.getZ() + 0.5D, 1.0D);
                        }
                        return NodeStatus.RUNNING;
                    }
                    ContainerOps.loot(entity, level, lootSite, SurvivalPlanner::isFood, 8);
                    looted = true;
                    lootSite = null;
                    return NodeStatus.RUNNING;
                }
            }

            // 3. hunt
            if (prey == null || !prey.isAlive() || entity.distanceToSqr(prey) > 32.0D * 32.0D) {
                prey = nearestPrey(entity, level);
            }
            if (prey == null) {
                explore(entity);
                return ++searchFails > 80 ? NodeStatus.FAILURE : NodeStatus.RUNNING;
            }
            searchFails = 0;
            double distance = entity.distanceTo(prey);
            if (distance > 2.4D) {
                if (nav.isDone() || ctx.gameTime() % 10L < brain.interval()) {
                    nav.moveTo(prey, 1.2D);
                }
                return NodeStatus.RUNNING;
            }
            entity.inventory().equipBestWeapon();
            entity.getLookControl().setLookAt(prey, 30.0F, 30.0F);
            if (attackCooldown <= 0) {
                entity.swing(InteractionHand.MAIN_HAND);
                entity.doHurtTarget(prey);
                attackCooldown = 10;
            } else {
                attackCooldown -= brain.interval();
            }
            return NodeStatus.RUNNING;
        }

        @Nullable
        private static Animal nearestPrey(ObserverEntity entity, ServerLevel level) {
            Animal best = null;
            double bestDist = Double.MAX_VALUE;
            for (Animal a : level.getEntitiesOfClass(Animal.class, entity.getBoundingBox().inflate(24.0D),
                    a -> a.isAlive() && !a.isBaby() && !a.hasCustomName() && a.getLeashHolder() == null
                            && (a instanceof Cow || a instanceof Pig || a instanceof Sheep
                            || a instanceof Chicken || a instanceof Rabbit))) {
                double d = entity.distanceToSqr(a);
                if (d < bestDist) {
                    bestDist = d;
                    best = a;
                }
            }
            return best;
        }
    }
}
