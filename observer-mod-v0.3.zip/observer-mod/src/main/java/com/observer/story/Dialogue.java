package com.observer.story;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

/** All player-facing story text goes through translation keys, so every line can be rewritten in the lang files. */
public final class Dialogue {
    private Dialogue() {
    }

    public static void say(ServerPlayer player, String key) {
        player.sendSystemMessage(Component.translatable(key).withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC));
        player.playNotifySound(SoundEvents.ENDERMAN_STARE, SoundSource.AMBIENT, 0.25F, 0.5F);
    }

    public static void title(ServerPlayer player, String titleKey, String subtitleKey) {
        player.connection.send(new ClientboundSetTitlesAnimationPacket(20, 90, 40));
        player.connection.send(new ClientboundSetTitleTextPacket(Component.translatable(titleKey)));
        player.connection.send(new ClientboundSetSubtitleTextPacket(Component.translatable(subtitleKey)));
    }

    /** A clickable line that runs /observer_choice <id>. */
    public static void choice(ServerPlayer player, String labelKey, String id) {
        MutableComponent line = Component.literal("> ").withStyle(ChatFormatting.GOLD)
                .append(Component.translatable(labelKey).withStyle(Style.EMPTY
                        .withColor(ChatFormatting.GOLD)
                        .withUnderlined(true)
                        .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/observer_choice " + id))));
        player.sendSystemMessage(line);
    }
}
