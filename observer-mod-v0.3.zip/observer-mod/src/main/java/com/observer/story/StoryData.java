package com.observer.story;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** World-level story state: chapter, choices, ending and per-player return points. */
public class StoryData extends SavedData {
    public static final String DATA_NAME = "observer_story";

    public record ReturnPoint(String dim, BlockPos pos) {
    }

    private int chapter;
    private String ending = "";
    private int observerHits;
    @Nullable
    private BlockPos gatePos;
    private boolean arenaBuilt;
    private boolean retired;
    private boolean peaceful;
    private boolean echo;
    private final Map<UUID, ReturnPoint> returns = new HashMap<>();

    public static StoryData get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(StoryData::load, StoryData::new, DATA_NAME);
    }

    public int getChapter() {
        return chapter;
    }

    public void setChapter(int chapter) {
        this.chapter = Math.max(0, chapter);
        setDirty();
    }

    public String getEnding() {
        return ending;
    }

    public void setEnding(String ending) {
        this.ending = ending;
        setDirty();
    }

    public int getObserverHits() {
        return observerHits;
    }

    public void addObserverHit() {
        observerHits++;
        setDirty();
    }

    @Nullable
    public BlockPos getGatePos() {
        return gatePos;
    }

    public void setGatePos(@Nullable BlockPos pos) {
        this.gatePos = pos;
        setDirty();
    }

    public boolean isArenaBuilt() {
        return arenaBuilt;
    }

    public void setArenaBuilt(boolean built) {
        this.arenaBuilt = built;
        setDirty();
    }

    public boolean isRetired() {
        return retired;
    }

    public void setRetired(boolean retired) {
        this.retired = retired;
        setDirty();
    }

    public boolean isPeaceful() {
        return peaceful;
    }

    public void setPeaceful(boolean peaceful) {
        this.peaceful = peaceful;
        setDirty();
    }

    public boolean isEcho() {
        return echo;
    }

    public void setEcho(boolean echo) {
        this.echo = echo;
        setDirty();
    }

    public void setReturn(UUID player, String dim, BlockPos pos) {
        returns.put(player, new ReturnPoint(dim, pos.immutable()));
        setDirty();
    }

    @Nullable
    public ReturnPoint getReturn(UUID player) {
        return returns.get(player);
    }

    /** Wipes every story flag (admin reset). Player memory is untouched. */
    public void reset() {
        chapter = 0;
        ending = "";
        observerHits = 0;
        gatePos = null;
        arenaBuilt = false;
        retired = false;
        peaceful = false;
        echo = false;
        returns.clear();
        setDirty();
    }

    public static StoryData load(CompoundTag tag) {
        StoryData d = new StoryData();
        d.chapter = Math.max(0, tag.getInt("Chapter"));
        d.ending = tag.getString("Ending");
        d.observerHits = Math.max(0, tag.getInt("Hits"));
        d.gatePos = tag.contains("Gate") ? BlockPos.of(tag.getLong("Gate")) : null;
        d.arenaBuilt = tag.getBoolean("ArenaBuilt");
        d.retired = tag.getBoolean("Retired");
        d.peaceful = tag.getBoolean("Peaceful");
        d.echo = tag.getBoolean("Echo");
        ListTag list = tag.getList("Returns", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag e = list.getCompound(i);
            if (e.hasUUID("Id")) {
                d.returns.put(e.getUUID("Id"), new ReturnPoint(e.getString("Dim"), BlockPos.of(e.getLong("Pos"))));
            }
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putInt("Chapter", chapter);
        tag.putString("Ending", ending);
        tag.putInt("Hits", observerHits);
        if (gatePos != null) {
            tag.putLong("Gate", gatePos.asLong());
        }
        tag.putBoolean("ArenaBuilt", arenaBuilt);
        tag.putBoolean("Retired", retired);
        tag.putBoolean("Peaceful", peaceful);
        tag.putBoolean("Echo", echo);
        ListTag list = new ListTag();
        for (Map.Entry<UUID, ReturnPoint> e : returns.entrySet()) {
            CompoundTag c = new CompoundTag();
            c.putUUID("Id", e.getKey());
            c.putString("Dim", e.getValue().dim());
            c.putLong("Pos", e.getValue().pos().asLong());
            list.add(c);
        }
        tag.put("Returns", list);
        return tag;
    }
}
