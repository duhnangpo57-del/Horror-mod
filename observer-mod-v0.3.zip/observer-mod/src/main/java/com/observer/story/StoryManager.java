package com.observer.story;

import com.observer.ObserverMod;
import com.observer.boss.ObserverBossEntity;
import com.observer.config.ObserverConfig;
import com.observer.dimension.ArenaGenerator;
import com.observer.dimension.DomainManager;
import com.observer.dimension.ModDimensions;
import com.observer.entity.ObserverEntity;
import com.observer.entity.ObserverLocator;
import com.observer.memory.ObserverMemoryData;
import com.observer.memory.ObserverWorldData;
import com.observer.memory.PlayerProfile;
import com.observer.registry.ModBlocks;
import com.observer.registry.ModEntities;
import com.observer.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/**
 * Chapters, dialogue, the boss encounter and the endings.
 * All wording lives in the lang files under story.observer.* and ending.observer.*.
 */
@Mod.EventBusSubscriber(modid = ObserverMod.MODID)
public final class StoryManager {
    private record Scheduled(int dueTick, Runnable action) {
    }

    private static final List<Scheduled> QUEUE = new ArrayList<>();

    private StoryManager() {
    }

    // ------------------------------------------------------------------ scheduling

    public static void schedule(MinecraftServer server, int delayTicks, Runnable action) {
        if (QUEUE.size() < 128) {
            QUEUE.add(new Scheduled(server.getTickCount() + delayTicks, action));
        }
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) {
            return;
        }
        int now = server.getTickCount();
        if (!QUEUE.isEmpty()) {
            List<Runnable> due = new ArrayList<>();
            Iterator<Scheduled> it = QUEUE.iterator();
            while (it.hasNext()) {
                Scheduled s = it.next();
                if (now >= s.dueTick()) {
                    due.add(s.action());
                    it.remove();
                }
            }
            for (Runnable r : due) {
                r.run();
            }
        }
        if (now % 20 == 0) {
            tick(server);
        }
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        QUEUE.clear();
    }

    @SubscribeEvent
    public static void onLivingHurt(LivingHurtEvent event) {
        if (event.getEntity() instanceof ObserverEntity && event.getSource().getEntity() instanceof ServerPlayer
                && !(event.getSource().getEntity() instanceof FakePlayer)) {
            MinecraftServer server = event.getEntity().getServer();
            if (server != null) {
                StoryData.get(server).addObserverHit();
            }
        }
    }

    // ------------------------------------------------------------------ chapter progression

    private static void tick(MinecraftServer server) {
        if (!ObserverConfig.STORY_ENABLED.get()) {
            return;
        }
        if (ObserverWorldData.get(server).getObserverId() == null) {
            return;
        }
        StoryData story = StoryData.get(server);
        if (story.isRetired()) {
            return;
        }
        ServerPlayer lead = leadPlayer(server);
        if (lead == null) {
            return;
        }
        PlayerProfile profile = ObserverMemoryData.get(server).peek(lead.getUUID());
        if (profile == null) {
            return;
        }
        double pace = ObserverConfig.STORY_PACE.get();
        long observed = profile.getObservedTicks();
        switch (story.getChapter()) {
            case 0 -> {
                if (observed >= 6000L * pace) {
                    advance(server, story, lead, 1);
                }
            }
            case 1 -> {
                if (observed >= 24000L * pace) {
                    advance(server, story, lead, 2);
                }
            }
            case 2 -> {
                if (observed >= 48000L * pace) {
                    advance(server, story, lead, 3);
                }
            }
            default -> {
            }
        }
    }

    @Nullable
    private static ServerPlayer leadPlayer(MinecraftServer server) {
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (!p.isSpectator() && !(p instanceof FakePlayer) && p.level().dimension() != ModDimensions.DOMAIN) {
                return p;
            }
        }
        return null;
    }

    public static void advance(MinecraftServer server, StoryData story, ServerPlayer lead, int chapter) {
        story.setChapter(chapter);
        Dialogue.say(lead, "story.observer.ch" + chapter + ".line1");
        UUID id = lead.getUUID();
        schedule(server, 160, () -> {
            ServerPlayer p = server.getPlayerList().getPlayer(id);
            if (p != null) {
                Dialogue.say(p, "story.observer.ch" + chapter + ".line2");
            }
        });
        if (chapter == 2) {
            ObserverEntity observer = ObserverLocator.find(server);
            if (observer != null) {
                observer.setSkinOf(lead.getUUID()); // it starts to look like you
            }
        }
        if (chapter == 3) {
            placeGate(story, lead);
        }
    }

    private static void placeGate(StoryData story, ServerPlayer lead) {
        if (!(lead.level() instanceof ServerLevel level)) {
            return;
        }
        RandomSource random = lead.getRandom();
        BlockState gate = ModBlocks.DOMAIN_GATE.get().defaultBlockState();
        for (int i = 0; i < 24; i++) {
            double angle = random.nextDouble() * Math.PI * 2.0D;
            double distance = 9.0D + random.nextInt(5);
            int x = (int) Math.floor(lead.getX() + Math.cos(angle) * distance);
            int z = (int) Math.floor(lead.getZ() + Math.sin(angle) * distance);
            BlockPos column = new BlockPos(x, 0, z);
            if (!level.hasChunkAt(column)) {
                continue;
            }
            BlockPos ground = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, column);
            if (!level.getBlockState(ground.below()).getFluidState().isEmpty() || !level.getBlockState(ground).isAir()) {
                continue;
            }
            for (int h = 0; h < 3; h++) {
                level.setBlock(ground.above(h), gate, 3);
            }
            story.setGatePos(ground);
            level.sendParticles(ParticleTypes.REVERSE_PORTAL, ground.getX() + 0.5D, ground.getY() + 1.5D,
                    ground.getZ() + 0.5D, 60, 0.4D, 1.2D, 0.4D, 0.05D);
            level.playSound(null, ground, SoundEvents.END_PORTAL_SPAWN, SoundSource.AMBIENT, 0.6F, 0.6F);
            return;
        }
    }

    // ------------------------------------------------------------------ boss encounter

    public static void scheduleBoss(MinecraftServer server, UUID playerId, int delayTicks) {
        schedule(server, delayTicks, () -> {
            ServerPlayer player = server.getPlayerList().getPlayer(playerId);
            ServerLevel domain = server.getLevel(ModDimensions.DOMAIN);
            if (player == null || domain == null || player.level().dimension() != ModDimensions.DOMAIN) {
                return;
            }
            if (StoryData.get(server).getChapter() >= 5) {
                return;
            }
            if (!domain.getEntities(ModEntities.THE_COPY.get(), e -> e.isAlive()).isEmpty()) {
                return;
            }
            spawnBoss(domain, player, 0.5D, ArenaGenerator.FLOOR_Y + 1.0D, -12.5D);
        });
    }

    public static void spawnBoss(ServerLevel level, ServerPlayer player, double x, double y, double z) {
        MinecraftServer server = level.getServer();
        ObserverBossEntity boss = ModEntities.THE_COPY.get().create(level);
        if (boss == null) {
            return;
        }
        boss.moveTo(x, y, z, 0.0F, 0.0F);
        PlayerProfile profile = ObserverMemoryData.get(server).peek(player.getUUID());
        boss.copyFrom(player, profile);
        boss.applyDifficulty();
        boss.setTarget(player);
        level.addFreshEntity(boss);
        Dialogue.say(player, "story.observer.boss.spawn");
    }

    public static void onBossDefeated(ServerLevel level) {
        MinecraftServer server = level.getServer();
        StoryData story = StoryData.get(server);
        story.setChapter(5);

        BlockState gate = ModBlocks.DOMAIN_GATE.get().defaultBlockState();
        BlockPos center = new BlockPos(0, ArenaGenerator.FLOOR_Y + 1, 0);
        for (int h = 0; h < 3; h++) {
            level.setBlock(center.above(h), gate, 3);
        }

        for (Player p : new ArrayList<>(level.players())) {
            if (p instanceof ServerPlayer sp) {
                UUID id = sp.getUUID();
                Dialogue.say(sp, "story.observer.ch5.line1");
                schedule(server, 120, () -> {
                    ServerPlayer later = server.getPlayerList().getPlayer(id);
                    if (later != null) {
                        Dialogue.say(later, "story.observer.ch5.line2");
                        Dialogue.choice(later, "story.observer.choice.accept", "accept");
                        Dialogue.choice(later, "story.observer.choice.refuse", "refuse");
                        Dialogue.choice(later, "story.observer.choice.spare", "spare");
                    }
                });
            }
        }
    }

    // ------------------------------------------------------------------ endings

    public static void choose(ServerPlayer player, String id) {
        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }
        StoryData story = StoryData.get(server);
        if (story.getChapter() != 5 || !story.getEnding().isEmpty()) {
            return;
        }
        String ending;
        switch (id) {
            case "accept" -> ending = "become";
            case "refuse" -> ending = "release";
            case "spare" -> ending = story.getObserverHits() == 0 ? "secret" : "echo";
            default -> {
                return;
            }
        }
        applyEnding(server, story, player, ending);
    }

    public static void applyEnding(MinecraftServer server, StoryData story, ServerPlayer player, String ending) {
        story.setEnding(ending);
        story.setChapter(6);
        ObserverEntity observer = ObserverLocator.find(server);

        switch (ending) {
            case "become" -> {
                if (observer != null) {
                    observer.setSkinOf(player.getUUID());
                }
                story.setPeaceful(true);
            }
            case "release" -> {
                if (observer != null && observer.level() instanceof ServerLevel level) {
                    level.sendParticles(ParticleTypes.SOUL, observer.getX(), observer.getY() + 1.0D, observer.getZ(),
                            50, 0.5D, 1.0D, 0.5D, 0.05D);
                    observer.discard();
                }
                ObserverWorldData.get(server).forceRelease();
                story.setRetired(true);
            }
            case "echo" -> story.setEcho(true);
            case "secret" -> {
                story.setPeaceful(true);
                if (observer != null) {
                    observer.setSkinOf(player.getUUID());
                }
                player.addItem(new ItemStack(ModItems.MEMORY_SHARD.get(), 3));
            }
            default -> {
            }
        }

        Dialogue.title(player, "ending.observer." + ending + ".title", "ending.observer." + ending + ".subtitle");
        Dialogue.say(player, "ending.observer." + ending + ".text");

        UUID id = player.getUUID();
        schedule(server, 200, () -> {
            ServerPlayer p = server.getPlayerList().getPlayer(id);
            if (p != null && p.level().dimension() == ModDimensions.DOMAIN) {
                DomainManager.leave(p);
            }
        });
    }
}
