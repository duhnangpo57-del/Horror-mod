package com.observer.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.resources.ResourceLocation;

import javax.annotation.Nullable;
import java.util.UUID;

/** Looks up a connected player's skin texture. Client only. */
public final class ClientSkins {
    private ClientSkins() {
    }

    @Nullable
    public static ResourceLocation skinOf(@Nullable UUID uuid) {
        if (uuid == null) {
            return null;
        }
        ClientPacketListener connection = Minecraft.getInstance().getConnection();
        if (connection == null) {
            return null;
        }
        var info = connection.getPlayerInfo(uuid);
        return info == null ? null : info.getSkinLocation();
    }
}
