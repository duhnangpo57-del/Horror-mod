package com.observer.client;

import com.observer.ObserverMod;
import com.observer.boss.ObserverBossEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;

/** The boss looks exactly like the player it copied: same skin, same armor, same weapon in hand. */
public class CopyRenderer extends HumanoidMobRenderer<ObserverBossEntity, HumanoidModel<ObserverBossEntity>> {
    private static final ResourceLocation FALLBACK =
            new ResourceLocation(ObserverMod.MODID, "textures/entity/the_observer.png");

    public CopyRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER)), 0.5F);
        this.addLayer(new HumanoidArmorLayer<>(this,
                new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
                new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)),
                context.getModelManager()));
    }

    @Override
    public ResourceLocation getTextureLocation(ObserverBossEntity entity) {
        ResourceLocation skin = ClientSkins.skinOf(entity.getCopyOf());
        return skin != null ? skin : FALLBACK;
    }
}
