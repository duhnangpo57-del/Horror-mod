package com.observer.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.observer.ObserverMod;
import com.observer.entity.ObserverEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;

/** Tall and thin, wearing a hood. Once it has started to copy a player it wears that player's skin. */
public class ObserverRenderer extends HumanoidMobRenderer<ObserverEntity, HumanoidModel<ObserverEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(ObserverMod.MODID, "textures/entity/the_observer.png");

    public ObserverRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER)), 0.5F);
        this.addLayer(new HumanoidArmorLayer<>(this,
                new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
                new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)),
                context.getModelManager()));
        this.addLayer(new ObserverEyesLayer(this));
    }

    @Override
    protected void scale(ObserverEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(0.94F, 1.14F, 0.94F);
    }

    @Override
    public ResourceLocation getTextureLocation(ObserverEntity entity) {
        ResourceLocation skin = ClientSkins.skinOf(entity.getSkinOf());
        return skin != null ? skin : TEXTURE;
    }
}
